# Mercadinho Aliança — Sistema Web Completo de Supermercado

Sistema comercial full-stack de e-commerce, vendas em atacado e varejo, delivery inteligente com taxas por zona, controle de estoque, painel administrativo multicargo (RBAC) e inteligência artificial alimentada pelo **Google Gemini API** (`@google/genai`).

---

## 🏛️ Identidade Visual & Conceito (BJORN PRO)
- **Cores Predominantes:** Preto Absoluto (`#050505`, `#0B0B0B`, `#111111`, `#181818`), Dourado Nobre (`#C9A227`, `#D4AF37`, `#F2D675`), Branco Puro (`#FFFFFF`) e Cinza (`#777777`, `#BDBDBD`).
- **Suporte a Logotipo:** Arquivo `/public/logo.png` e vetor `/public/logo.svg` renderizado no cabeçalho, tela inicial, login, checkout, recibos térmicos de 80mm e rodapé.
- **PWA Ready:** Instalável em celular (iOS/Android), computador e navegador de Smart TV.

---

## 🚀 1. Como Instalar
Certifique-se de possuir o Node.js v18+ e npm instalados.

```bash
# Instalar todas as dependências
npm install
```

---

## ⚡ 2. Como Executar
O projeto adota arquitetura full-stack recomendada com servidor Express e middlewares Vite unificados:

```bash
# Executar em modo desenvolvimento (Porta 3000)
npm run dev

# Executar build de produção
npm run build

# Iniciar servidor em produção
npm start
```
Acesse a aplicação no navegador em `http://localhost:3000`.

---

## 🗄️ 3. Como Configurar Banco de Dados
Por padrão, o sistema inicializa uma camada de persistência em memória pré-populada com todos os produtos de demonstração solicitados (Arroz 5kg, Feijão 1kg, Carnes Nobres, Hortifrúti, Laticínios, Bebidas, Limpeza e Higiene).

Para conectar ao PostgreSQL / Supabase / Neon:
1. Abra o arquivo `.env`.
2. Configure a variável:
   ```env
   DATABASE_URL="postgres://usuario:senha@seu-host:5432/alianca_db"
   ```

---

## 🤖 4. Como Configurar o Gemini AI
O sistema utiliza o SDK oficial `@google/genai` no backend para garantir segurança (chave nunca exposta no frontend).

1. Obtenha sua chave no [Google AI Studio](https://aistudio.google.com/).
2. Insira no arquivo `.env`:
   ```env
   GEMINI_API_KEY="AIzaSy..."
   ```
3. O modelo padrão é `gemini-3.8-flash`.
4. O assistente conta com **Function Calling** ativo para:
   - `search_products`: Busca produtos no catálogo em tempo real.
   - `get_low_stock`: Alerta produtos em estoque baixo no painel admin.
   - `get_sales_report`: Consulta faturamento e métricas.
   - `create_coupon`: Gera cupons promocionais.
   - `calculate_cart`: Calcula descontos automáticos de atacado.
   - `identifyProductFromImage`: Identificação de embalagem por foto (visão computacional sem inventar preços).

---

## 💳 5. Como Configurar Pagamento (Gateways & PIX)
A arquitetura desacoplada `PaymentProvider` suporta:
- **PIX:** Gera payload oficial Banco Central (BR Code EMV) e QR Code dinâmico em base64.
- **Mercado Pago:** Configurar `MERCADOPAGO_ACCESS_TOKEN` no `.env`.
- **Stripe:** Configurar `STRIPE_SECRET_KEY` no `.env`.
- **Modos de Operação:**
  - **Modo DEMO:** Simula autorização imediata e exibe avisos quando as credenciais não estiverem preenchidas.
  - **Modo PRODUÇÃO:** Realiza chamadas seguras com webhooks para `payment.approved`, `payment.pending` e `payment.rejected`.

---

## 📱 6. Como Configurar WhatsApp
No Painel Administrativo em **Configurações**:
1. Acesse `/admin` -> **Configurações**.
2. Altere o número do WhatsApp de atendimento (formato internacional sem caracteres especiais, ex: `5511999887766`).
3. O botão **"Pedir pelo WhatsApp"** na tela final gera automaticamente a mensagem com a lista de itens, quantidades, valores e endereço de entrega.

---

## 🚚 7. Como Configurar Delivery
No Painel Administrativo em **Delivery & Zonas**:
1. Configure as zonas de atendimento:
   - **Zona 1 (Centro & Bairros Próximos):** Taxa R$ 5,00 (Previsão: 35 min).
   - **Zona 2 (Bairros Médios):** Taxa R$ 8,00 (Previsão: 50 min).
   - **Zona 3 (Metropolitana):** Taxa R$ 12,00 (Previsão: 75 min).
2. Configure o valor mínimo para **Frete Grátis** (padrão: R$ 180,00).

---

## 👥 8. Como Criar Administrador & Perfis (RBAC)
O sistema possui controle de acesso baseado em papéis (RBAC):
- `ADMIN`: Acesso irrestrito a configurações, gateways, relatórios e IA.
- `GERENTE`: Acesso a produtos, pedidos, estoque e promoções.
- `ESTOQUE`: Gestão de entradas, saídas e reposições.
- `CAIXA`: Atendimento de balcão e emissão de cupons térmicos.
- `ENTREGA`: Painel de despacho e rotas de motoboy.
- `ATENDIMENTO`: SAC e suporte ao cliente.

Usuários de demonstração já configurados:
- `admin@mercadinhoalianca.com.br` (ADMIN)
- `gerente@mercadinhoalianca.com.br` (GERENTE)
- `estoque@mercadinhoalianca.com.br` (ESTOQUE)

---

## 🌐 9. Como Publicar (Deploy)
```bash
# 1. Compilação dos assets
npm run build

# 2. Executar em container ou servidor Node
npm start
```
A porta padrão utilizada é a `3000` (ou a definida em `process.env.PORT`).

---

## 🧪 10. Como Testar as Funcionalidades

### Teste 1: Regra de Atacado x Varejo
1. Vá para a página inicial ou produtos.
2. Adicione **Arroz Branco 5kg** ao carrinho.
   - De 1 a 4 unidades: Preço unitário de varejo (R$ 29,90).
   - Ao adicionar a 5ª unidade: Um alerta dourado surge avisando: *"🎉 Você atingiu o preço de atacado!"* e o preço cai para R$ 27,90 cada.

### Teste 2: Checkout em 5 Etapas
1. Abra o carrinho lateral e clique em **Finalizar**.
2. Preencha os dados do cliente -> selecione entrega -> escolha a zona -> escolha PIX -> Conclua.
3. Visualize o código PIX Copia e Cola, o QR Code dinâmico e clique em **Imprimir Comprovante Térmico (80mm)**.

### Teste 3: Leitor de Código de Barras
1. No menu superior ou no painel `/admin`, abra **Produtos** -> **Scanear Barras**.
2. Utilize a câmera do celular ou teste com um dos botões de simulação rápida.

### Teste 4: Assistente Aliança AI com Function Calling
1. Clique no botão flutuante **"Fale com o Aliança AI"**.
2. Pergunte: *"Tem arroz?"* ou *"Quanto custa o quilo do contra filé?"*.
3. O assistente pesquisa os dados no catálogo e disponibiliza botão de adicionar à cesta.
