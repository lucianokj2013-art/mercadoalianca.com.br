import React, { useState, useEffect } from 'react';
import { ListChecks, Plus, ShoppingBag, Trash2, CheckCircle2, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { Product } from '../../shared/types.ts';
import { api } from '../services/api.ts';

interface PrebuiltList {
  id: string;
  name: string;
  description: string;
  badge: string;
  items: { productName: string; quantity: number }[];
}

export const ShoppingListsPage: React.FC = () => {
  const { addToCart, showToast, navigate } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [customLists, setCustomLists] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('alianca_custom_lists');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [newListName, setNewListName] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.getProducts();
        setProducts(data);
      } catch (err) {
        console.error(err);
      }
    };
    load();
  }, []);

  const prebuiltLists: PrebuiltList[] = [
    {
      id: 'list-churrasco',
      name: 'Churrasco Completo de Fim de Semana',
      description: 'Cortes nobres, costela em tiras, queijo fatiado e refrigerante para 6 a 8 pessoas.',
      badge: 'TOP VENDAS',
      items: [
        { productName: 'Contra Filé Bovino Premium kg', quantity: 2 },
        { productName: 'Costela Bovina em Tiras para Churrasco kg', quantity: 2 },
        { productName: 'Refrigerante Coca-Cola Original 2L', quantity: 4 },
        { productName: 'Queijo Mussarela Fatiado 500g', quantity: 2 }
      ]
    },
    {
      id: 'list-compra-mes',
      name: 'Compra do Mês Essencial (Família)',
      description: 'Arroz 5kg, feijão, café forte, óleo, leite integral e itens básicos de limpeza.',
      badge: 'ATACADO RECOMENDADO',
      items: [
        { productName: 'Arroz Branco Nobre Tipo 1 5kg', quantity: 5 },
        { productName: 'Feijão Carioca Especial 1kg', quantity: 6 },
        { productName: 'Café Tradicional Torrado e Moído 500g', quantity: 4 },
        { productName: 'Leite Integral UHT 1L', quantity: 12 },
        { productName: 'Óleo de Soja Refinado 900ml', quantity: 6 },
        { productName: 'Sabão em Pó Concentrado Lavagem Perfeita 1.6kg', quantity: 3 }
      ]
    },
    {
      id: 'list-semanal-hortifruti',
      name: 'Mercado Semanal & Hortifrúti Fresco',
      description: 'Frutas doces, legumes selecionados, tomates e batatas para a semana inteira.',
      badge: 'DIRETO DO PRODUTOR',
      items: [
        { productName: 'Banana Prata Selecionada kg', quantity: 2 },
        { productName: 'Tomate Italiano Especial kg', quantity: 2 },
        { productName: 'Batata Inglesa Lavada kg', quantity: 3 },
        { productName: 'Cebola Amarela Nacional kg', quantity: 2 },
        { productName: 'Filé de Peito de Frango Congelado 1kg', quantity: 3 }
      ]
    }
  ];

  const handleAddListToCart = (items: { productName: string; quantity: number }[]) => {
    let count = 0;
    items.forEach((item) => {
      const match = products.find(
        (p) => p.name.toLowerCase() === item.productName.toLowerCase()
      );
      if (match) {
        addToCart(match, item.quantity);
        count += item.quantity;
      }
    });

    if (count > 0) {
      showToast('Lista Adicionada!', `${count} itens foram inseridos na sua cesta com preços de atacado calculados!`, 'wholesale');
    } else {
      showToast('Itens indisponíveis', 'Não foi possível encontrar os itens no estoque.', 'error');
    }
  };

  const handleCreateCustomList = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newListName.trim()) return;
    const newList = {
      id: `list-${Date.now()}`,
      name: newListName.trim(),
      items: [
        { productName: 'Arroz Branco Nobre Tipo 1 5kg', quantity: 1 },
        { productName: 'Feijão Carioca Especial 1kg', quantity: 1 }
      ]
    };
    const updated = [...customLists, newList];
    setCustomLists(updated);
    localStorage.setItem('alianca_custom_lists', JSON.stringify(updated));
    setNewListName('');
    setIsCreating(false);
    showToast('Lista criada!', `Sua lista "${newList.name}" foi criada com sucesso.`, 'success');
  };

  const handleDeleteCustomList = (id: string) => {
    const updated = customLists.filter((l) => l.id !== id);
    setCustomLists(updated);
    localStorage.setItem('alianca_custom_lists', JSON.stringify(updated));
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-10">
      <div className="max-w-5xl mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-[#1E1E1E]">
          <div>
            <h1 className="text-white font-serif-luxury font-black text-2xl sm:text-3xl uppercase tracking-wider flex items-center gap-2">
              <ListChecks className="w-6 h-6 text-[#D4AF37]" />
              Listas de Compras Prontas
            </h1>
            <p className="text-xs text-[#888888] mt-1">
              Adicione cestas inteiras ao seu carrinho com um único clique e economize tempo e dinheiro
            </p>
          </div>

          <button
            onClick={() => setIsCreating(true)}
            className="px-4 py-2 bg-[#161616] hover:bg-[#222222] border border-[#D4AF37]/50 text-[#F2D675] font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Criar Minha Lista
          </button>
        </div>

        {/* Modal/Form create custom list */}
        {isCreating && (
          <form onSubmit={handleCreateCustomList} className="bg-[#0E0E0E] border border-[#D4AF37]/40 rounded-2xl p-5 mb-8 flex gap-3 items-center">
            <input
              type="text"
              value={newListName}
              onChange={(e) => setNewListName(e.target.value)}
              placeholder="Nome da lista (ex: Churrasco de Domingo, Casa de Praia)..."
              className="flex-1 bg-[#161616] border border-[#262626] rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#D4AF37]"
              autoFocus
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs uppercase rounded-xl transition-colors cursor-pointer"
            >
              Salvar
            </button>
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-3 py-2.5 text-xs text-[#888888] hover:text-white"
            >
              Cancelar
            </button>
          </form>
        )}

        {/* Prebuilt Lists Grid */}
        <div className="space-y-6 mb-12">
          <h2 className="text-white font-bold text-sm uppercase tracking-wider">
            Listas Inteligentes Recomendadas
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {prebuiltLists.map((list) => (
              <div
                key={list.id}
                className="bg-[#0B0B0B] border border-[#1E1E1E] hover:border-[#D4AF37]/50 rounded-3xl p-6 transition-all shadow-xl flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/30 px-2 py-0.5 rounded-full inline-block mb-3">
                    {list.badge}
                  </span>

                  <h3 className="text-white font-bold text-base mb-2">{list.name}</h3>
                  <p className="text-xs text-[#888888] leading-relaxed mb-4">{list.description}</p>

                  <div className="space-y-1.5 border-t border-[#1C1C1C] pt-3 mb-6">
                    <span className="text-[10px] font-bold uppercase text-[#666666] block mb-1">
                      Itens inclusos:
                    </span>
                    {list.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between text-xs text-[#CCCCCC]">
                        <span className="truncate pr-2">• {it.productName}</span>
                        <strong className="text-[#F2D675] shrink-0 font-mono">x{it.quantity}</strong>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => handleAddListToCart(list.items)}
                  className="w-full py-3 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/10 transition-all cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  Adicionar Lista à Cesta
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Custom Lists if any */}
        {customLists.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-white font-bold text-sm uppercase tracking-wider">
              Minhas Listas Personalizadas
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {customLists.map((cl) => (
                <div key={cl.id} className="bg-[#0B0B0B] border border-[#222] rounded-2xl p-4 flex items-center justify-between">
                  <div>
                    <h4 className="text-white font-bold text-sm">{cl.name}</h4>
                    <span className="text-xs text-[#777]">{cl.items.length} itens salvos</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleAddListToCart(cl.items)}
                      className="px-3 py-1.5 bg-[#D4AF37] text-black text-xs font-bold rounded-lg cursor-pointer"
                    >
                      Adicionar
                    </button>
                    <button
                      onClick={() => handleDeleteCustomList(cl.id)}
                      className="p-1.5 text-[#666] hover:text-red-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
