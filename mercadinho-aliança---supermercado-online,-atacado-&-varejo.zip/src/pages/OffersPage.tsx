import React, { useState, useEffect } from 'react';
import { Flame, Clock, Tag, Percent, ArrowRight } from 'lucide-react';
import { ProductCard } from '../components/ProductCard.tsx';
import { Product, Coupon } from '../../shared/types.ts';
import { api } from '../services/api.ts';
import { useApp } from '../context/AppContext.tsx';

export const OffersPage: React.FC = () => {
  const { applyCoupon, navigate } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);

  useEffect(() => {
    const load = async () => {
      try {
        const [prods, coups] = await Promise.all([
          api.getProducts({ onSale: true }),
          api.getCoupons()
        ]);
        setProducts(prods);
        setCoupons(coups);
      } catch (err) {
        console.error('Failed to load offers:', err);
      }
    };
    load();
  }, []);

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-10">
      <div className="max-w-7xl mx-auto px-4">
        {/* Title */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Flame className="w-4 h-4 text-red-500" /> Preços Arrasadores
          </div>
          <h1 className="font-serif-luxury font-black text-3xl sm:text-4xl uppercase tracking-wider text-white">
            Ofertas & <span className="gold-gradient-text">Promoções do Dia</span>
          </h1>
          <p className="text-xs sm:text-sm text-[#888888] mt-1">
            Aproveite os melhores descontos do Mercadinho Aliança com estoque limitado
          </p>
        </div>

        {/* Coupons Strip */}
        <div className="mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-[#A0A0A0] block mb-3">
            Cupons Disponíveis para Ativação:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {coupons.map((c) => (
              <div
                key={c.id}
                className="bg-[#0B0B0B] border border-[#222222] hover:border-[#D4AF37]/50 rounded-2xl p-4 flex items-center justify-between gap-3 transition-all"
              >
                <div>
                  <div className="flex items-center gap-1.5 text-[#D4AF37] font-black text-sm font-mono">
                    <Tag className="w-3.5 h-3.5" /> {c.code}
                  </div>
                  <div className="text-xs text-white font-bold mt-0.5">
                    {c.type === 'PERCENTAGE' ? `${c.value}% OFF` : `R$ ${c.value.toFixed(2)} OFF`}
                  </div>
                  <div className="text-[10px] text-[#777777]">
                    Pedido mín: R$ {c.minOrderValue.toFixed(2)}
                  </div>
                </div>

                <button
                  onClick={() => applyCoupon(c.code)}
                  className="px-3 py-1.5 bg-[#181818] hover:bg-[#D4AF37] hover:text-black text-white text-xs font-bold rounded-xl border border-[#333333] transition-colors cursor-pointer"
                >
                  Usar Cupom
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Products */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {products.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </div>
    </div>
  );
};
