import React, { useState, useEffect } from 'react';
import {
  CheckCircle,
  Truck,
  MapPin,
  CreditCard,
  QrCode,
  Banknote,
  Clock,
  ArrowRight,
  ArrowLeft,
  ShoppingBag,
  MessageCircle,
  Printer,
  Copy,
  Check,
  AlertCircle,
  Sparkles,
  Building,
  Calendar,
  DollarSign,
  FileText,
  ShieldAlert,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { Order, PaymentMethod, DeliveryType, Address, BankAccount, PaymentMethodConfig } from '../../shared/types.ts';
import { api } from '../services/api.ts';
import { ThermalReceipt } from '../components/ThermalReceipt.tsx';

export const CheckoutPage: React.FC = () => {
  const {
    orderItems,
    cartSubtotal,
    cartTotalSavings,
    couponDiscount,
    appliedCoupon,
    cartFinalTotal,
    currentCustomer,
    updateCustomerProfile,
    clearCart,
    navigate,
    settings,
    showToast
  } = useApp();

  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1);
  const [deliveryType, setDeliveryType] = useState<DeliveryType>('DELIVERY');
  const [selectedZoneId, setSelectedZoneId] = useState<string>('zone-1');
  const [deliveryFee, setDeliveryFee] = useState<number>(5.00);

  // Customer state
  const [name, setName] = useState(currentCustomer.name || '');
  const [cpf, setCpf] = useState(currentCustomer.cpf || '');
  const [phone, setPhone] = useState(currentCustomer.phone || '');
  const [whatsapp, setWhatsapp] = useState(currentCustomer.whatsapp || '');
  const [email, setEmail] = useState(currentCustomer.email || '');

  // Address state
  const defaultAddr = currentCustomer.addresses[0] || {
    id: 'addr-1',
    street: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: 'São Paulo',
    state: 'SP',
    cep: '',
    reference: ''
  };

  const [street, setStreet] = useState(defaultAddr.street);
  const [number, setNumber] = useState(defaultAddr.number);
  const [complement, setComplement] = useState(defaultAddr.complement || '');
  const [neighborhood, setNeighborhood] = useState(defaultAddr.neighborhood);
  const [city, setCity] = useState(defaultAddr.city);
  const [state, setState] = useState(defaultAddr.state);
  const [cep, setCep] = useState(defaultAddr.cep);
  const [reference, setReference] = useState(defaultAddr.reference || '');
  const [orderNotes, setOrderNotes] = useState('');

  // Payment state
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('PIX');
  const [cashChangeFor, setCashChangeFor] = useState<string>('');
  const [selectedBankId, setSelectedBankId] = useState<string>('');
  const [copiedBankData, setCopiedBankData] = useState(false);
  const [cardName, setCardName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [installments, setInstallments] = useState(1);

  // Created Order state
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedPix, setCopiedPix] = useState(false);
  const [showThermalReceipt, setShowThermalReceipt] = useState(false);
  const [zones, setZones] = useState<any[]>([]);

  useEffect(() => {
    if (settings?.bankAccounts && settings.bankAccounts.length > 0 && !selectedBankId) {
      const activeBank = settings.bankAccounts.find(b => b.active) || settings.bankAccounts[0];
      if (activeBank) setSelectedBankId(activeBank.id);
    }
  }, [settings, selectedBankId]);

  useEffect(() => {
    if (settings?.deliveryActive === false && settings?.pickupActive !== false) {
      setDeliveryType('PICKUP');
    }
  }, [settings]);

  useEffect(() => {
    const fetchZones = async () => {
      try {
        const data = await api.getDeliveryZones();
        setZones(data);
      } catch (err) {
        console.warn('Could not load zones:', err);
      }
    };
    fetchZones();
  }, []);

  // Update delivery fee according to selection
  useEffect(() => {
    if (deliveryType === 'PICKUP') {
      setDeliveryFee(0);
    } else {
      const z = zones.find(item => item.id === selectedZoneId);
      const isFree = settings?.freeShippingThreshold ? cartSubtotal >= settings.freeShippingThreshold : false;
      setDeliveryFee(isFree ? 0 : (z ? z.fee : 5.00));
    }
  }, [deliveryType, selectedZoneId, zones, cartSubtotal, settings]);

  if (orderItems.length === 0 && !completedOrder) {
    return (
      <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-20 px-4 flex flex-col items-center justify-center text-center">
        <div className="w-16 h-16 rounded-full bg-[#111111] border border-[#222222] flex items-center justify-center mb-4 text-[#777777]">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="text-white font-bold text-lg mb-2">Sua cesta de compras está vazia</h2>
        <p className="text-xs text-[#888888] max-w-sm mb-6">
          Adicione produtos no carrinho antes de prosseguir para a finalização do pedido.
        </p>
        <button
          onClick={() => navigate('products')}
          className="px-6 py-3 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer"
        >
          Ver Produtos
        </button>
      </div>
    );
  }

  const effectiveTotal = Number(
    Math.max(0, cartSubtotal - couponDiscount + deliveryFee).toFixed(2)
  );

  const handleFinishOrder = async () => {
    setIsSubmitting(true);
    try {
      const selectedBank = settings?.bankAccounts?.find(b => b.id === selectedBankId);

      const deliveryAddress: Address = {
        id: `addr-${Date.now()}`,
        street,
        number,
        complement,
        neighborhood,
        city,
        state,
        cep,
        reference
      };

      let finalNotes = orderNotes;
      if (paymentMethod === 'CASH') {
        finalNotes += ` [Pagto: Dinheiro no Ato da Entrega - Sujeito a Aprovação${cashChangeFor ? ' - Troco p/ R$ ' + cashChangeFor : ''}]`;
      } else if (paymentMethod === 'A_PRAZO') {
        finalNotes += ' [Pagto: A Prazo - Sujeito a Aprovação Cadastral / Crediário Aliança]';
      } else if (paymentMethod === 'BANK_TRANSFER') {
        finalNotes += ` [Pagto: Transferência Bancária - ${selectedBank?.bankName || 'Outros Bancos'}]`;
      } else if (paymentMethod === 'DELIVERY_CARD') {
        finalNotes += ' [Pagto: Cartão na Maquininha (Entrega)]';
      } else if (paymentMethod === 'CREDIT_CARD') {
        finalNotes += ' [Pagto: Cartão de Crédito Online]';
      }

      const orderPayload: Partial<Order> = {
        customerId: currentCustomer.id,
        customerName: name,
        customerCpf: cpf,
        customerPhone: phone || whatsapp,
        customerEmail: email,
        items: orderItems,
        subtotal: cartSubtotal,
        discount: couponDiscount,
        shippingFee: deliveryFee,
        total: effectiveTotal,
        totalSavings: cartTotalSavings,
        paymentMethod,
        paymentStatus: paymentMethod === 'PIX' ? 'PENDING' : 'APPROVED',
        deliveryType,
        deliveryAddress: deliveryType === 'DELIVERY' ? deliveryAddress : undefined,
        deliveryZoneId: deliveryType === 'DELIVERY' ? selectedZoneId : undefined,
        notes: finalNotes.trim()
      };

      const order = await api.createOrder(orderPayload);
      setCompletedOrder(order);
      clearCart();
      setStep(5);
      showToast('Pedido Confirmado!', `Pedido ${order.id} registrado com sucesso.`, 'success');
    } catch (err: any) {
      showToast('Erro no pedido', 'Não foi possível concluir seu pedido.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // WhatsApp order generator
  const getWhatsAppMessage = (order: Order) => {
    const selectedBank = settings?.bankAccounts?.find(b => b.id === selectedBankId);

    const itemsList = order.items
      .map(
        i =>
          `• ${i.quantity}x ${i.productName} (${i.isWholesale ? 'Atacado' : 'Varejo'}) - R$ ${i.subtotal.toFixed(2)}`
      )
      .join('\n');

    const addressText = order.deliveryAddress
      ? `${order.deliveryAddress.street}, ${order.deliveryAddress.number} - ${order.deliveryAddress.neighborhood}, ${order.deliveryAddress.city}`
      : 'Retirada na Loja física (Balcão Aliança)';

    let paymentMethodDisplay: string = order.paymentMethod;
    if (order.paymentMethod === 'A_PRAZO') {
      paymentMethodDisplay = 'A Prazo (Sujeito a Aprovação Cadastral)';
    } else if (order.paymentMethod === 'CASH') {
      paymentMethodDisplay = `Em Dinheiro no Ato da Entrega (Sujeito a Aprovação)${cashChangeFor ? ' - Troco p/ ' + cashChangeFor : ''}`;
    } else if (order.paymentMethod === 'BANK_TRANSFER') {
      paymentMethodDisplay = `Transferência Bancária (${selectedBank?.bankName || 'Outros Bancos'})`;
    } else if (order.paymentMethod === 'DELIVERY_CARD') {
      paymentMethodDisplay = 'Cartão na Maquininha (Entrega)';
    } else if (order.paymentMethod === 'CREDIT_CARD') {
      paymentMethodDisplay = 'Cartão de Crédito Online';
    } else if (order.paymentMethod === 'PIX') {
      paymentMethodDisplay = 'PIX';
    }

    return encodeURIComponent(
      `🛒 *PEDIDO ${order.id} - MERCADINHO ALIANÇA*\n\n` +
      `👤 *Cliente:* ${order.customerName}\n` +
      `📱 *Telefone:* ${order.customerPhone}\n` +
      `📄 *CPF:* ${order.customerCpf || 'Não informado'}\n\n` +
      `📦 *Itens do Pedido:*\n${itemsList}\n\n` +
      `💰 *Subtotal:* R$ ${order.subtotal.toFixed(2)}\n` +
      `🏷️ *Desconto:* R$ ${order.discount.toFixed(2)}\n` +
      `🚚 *Frete:* R$ ${order.shippingFee.toFixed(2)}\n` +
      `⭐ *TOTAL:* R$ ${order.total.toFixed(2)}\n\n` +
      `📍 *Endereço:* ${addressText}\n` +
      `💳 *Forma de Pagamento:* ${paymentMethodDisplay}\n` +
      (order.notes ? `📝 *Observações:* ${order.notes}\n\n` : '\n') +
      `Por favor, confirmem o recebimento do pedido!`
    );
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-10">
      <div className="max-w-4xl mx-auto px-4">
        {/* Step Indicator Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
              Checkout <span className="gold-gradient-text">Aliança</span>
            </h1>
            <span className="text-xs text-[#D4AF37] font-bold">
              Etapa {step} de 5
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {[
              { num: 1, label: 'Identificação' },
              { num: 2, label: 'Endereço' },
              { num: 3, label: 'Entrega' },
              { num: 4, label: 'Pagamento' },
              { num: 5, label: 'Confirmação' }
            ].map((s) => (
              <div key={s.num} className="text-center">
                <div
                  className={`h-1.5 rounded-full transition-all ${
                    step >= s.num
                      ? 'bg-gradient-to-r from-[#D4AF37] to-[#F2D675]'
                      : 'bg-[#1C1C1C]'
                  }`}
                />
                <span
                  className={`text-[10px] hidden sm:block mt-1 font-bold ${
                    step >= s.num ? 'text-[#F2D675]' : 'text-[#555555]'
                  }`}
                >
                  {s.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* STEP 1: DADOS DO CLIENTE */}
        {step === 1 && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6">
            <div>
              <h2 className="text-white font-bold text-lg uppercase tracking-wider mb-1">
                Etapa 1: Dados do Cliente
              </h2>
              <p className="text-xs text-[#888888]">
                Informe seus dados para contato, nota e rastreamento da entrega
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Seu nome completo"
                  className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                  CPF (para nota fiscal) *
                </label>
                <input
                  type="text"
                  value={cpf}
                  onChange={(e) => setCpf(e.target.value)}
                  placeholder="000.000.000-00"
                  className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                  Telefone / Celular *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(74) 99959-8143"
                  className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                  WhatsApp (para avisos do pedido)
                </label>
                <input
                  type="tel"
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  placeholder="(74) 99959-8143"
                  className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                  E-mail *
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seuemail@exemplo.com"
                  className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                  required
                />
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-[#1C1C1C]">
              <button
                onClick={() => {
                  if (!name.trim() || !phone.trim()) {
                    showToast('Campos obrigatórios', 'Por favor preencha nome e telefone.', 'error');
                    return;
                  }
                  updateCustomerProfile({ name, cpf, phone, whatsapp, email });
                  setStep(2);
                }}
                className="px-6 py-3 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer"
              >
                Avançar para Endereço <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: ENDEREÇO & MODALIDADE */}
        {step === 2 && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6">
            <div>
              <h2 className="text-white font-bold text-lg uppercase tracking-wider mb-1">
                Etapa 2: Como Deseja Receber?
              </h2>
              <p className="text-xs text-[#888888]">
                Escolha entrega expressa em domicílio ou retirada rápida na loja física
              </p>
            </div>

            {/* Delivery mode selection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setDeliveryType('DELIVERY')}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                  deliveryType === 'DELIVERY'
                    ? 'bg-[#181818] border-[#D4AF37] text-white shadow-lg shadow-[#D4AF37]/10'
                    : 'bg-[#111111] border-[#222222] text-[#888888] hover:border-[#333333]'
                }`}
              >
                <div className={`p-3 rounded-xl ${deliveryType === 'DELIVERY' ? 'bg-[#D4AF37] text-black' : 'bg-[#1C1C1C]'}`}>
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white">Entrega em Domicílio</div>
                  <div className="text-xs text-[#A0A0A0]">Receba no conforto da sua casa em até 45 min</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setDeliveryType('PICKUP')}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                  deliveryType === 'PICKUP'
                    ? 'bg-[#181818] border-[#D4AF37] text-white shadow-lg shadow-[#D4AF37]/10'
                    : 'bg-[#111111] border-[#222222] text-[#888888] hover:border-[#333333]'
                }`}
              >
                <div className={`p-3 rounded-xl ${deliveryType === 'PICKUP' ? 'bg-[#D4AF37] text-black' : 'bg-[#1C1C1C]'}`}>
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white">Retirada na Loja (Grátis)</div>
                  <div className="text-xs text-[#A0A0A0]">Pronto em 30 min no balcão de atendimento</div>
                </div>
              </button>
            </div>

            {/* Address fields if delivery */}
            {deliveryType === 'DELIVERY' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-[#1C1C1C]">
                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    CEP *
                  </label>
                  <input
                    type="text"
                    value={cep}
                    onChange={(e) => setCep(e.target.value)}
                    placeholder="00000-000"
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    Rua / Avenida *
                  </label>
                  <input
                    type="text"
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    placeholder="Ex: Rua Principal"
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    Número *
                  </label>
                  <input
                    type="text"
                    value={number}
                    onChange={(e) => setNumber(e.target.value)}
                    placeholder="123"
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    Complemento
                  </label>
                  <input
                    type="text"
                    value={complement}
                    onChange={(e) => setComplement(e.target.value)}
                    placeholder="Apto 42, Bloco B"
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    Bairro *
                  </label>
                  <input
                    type="text"
                    value={neighborhood}
                    onChange={(e) => setNeighborhood(e.target.value)}
                    placeholder="Ex: Bela Vista"
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    Ponto de Referência
                  </label>
                  <input
                    type="text"
                    value={reference}
                    onChange={(e) => setReference(e.target.value)}
                    placeholder="Ex: Próximo à praça central"
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-sm text-white outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    Cidade / UF
                  </label>
                  <input
                    type="text"
                    value={`${city} - ${state}`}
                    disabled
                    className="w-full bg-[#161616] border border-[#222222] rounded-xl px-4 py-3 text-sm text-[#888888] outline-none"
                  />
                </div>
              </div>
            )}

            {/* Navigation buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-[#1C1C1C]">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2.5 text-xs text-[#888888] hover:text-white flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" /> Voltar
              </button>

              <button
                onClick={() => {
                  if (deliveryType === 'DELIVERY' && (!street.trim() || !number.trim() || !neighborhood.trim())) {
                    showToast('Endereço incompleto', 'Preencha rua, número e bairro para entrega.', 'error');
                    return;
                  }
                  setStep(3);
                }}
                className="px-6 py-3 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer"
              >
                Avançar para Opções de Entrega <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: ENTREGA & ZONAS */}
        {step === 3 && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6">
            <div>
              <h2 className="text-white font-bold text-lg uppercase tracking-wider mb-1">
                Etapa 3: Zonas de Entrega & Prazos
              </h2>
              <p className="text-xs text-[#888888]">
                Confira a taxa e o tempo estimado para seu endereço
              </p>
            </div>

            {deliveryType === 'DELIVERY' ? (
              <div className="space-y-3">
                {zones.map((zone) => {
                  const isSelected = selectedZoneId === zone.id;
                  const isFree = settings?.freeShippingThreshold ? cartSubtotal >= settings.freeShippingThreshold : false;
                  const feeToDisplay = isFree ? 0 : zone.fee;

                  return (
                    <div
                      key={zone.id}
                      onClick={() => setSelectedZoneId(zone.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-[#161616] border-[#D4AF37] text-white shadow-lg shadow-[#D4AF37]/10'
                          : 'bg-[#111111] border-[#222222] text-[#AAAAAA] hover:border-[#333333]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2.5 rounded-xl ${isSelected ? 'bg-[#D4AF37] text-black font-bold' : 'bg-[#1A1A1A]'}`}>
                          <Truck className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-bold text-sm text-white">{zone.name}</div>
                          <div className="text-xs text-[#888888]">
                            Até {zone.distanceKm} km • Previsão: {zone.estimatedTimeMin} minutos
                          </div>
                          <div className="text-[10px] text-[#666666] mt-0.5">
                            Bairros atendidos: {zone.neighborhoods?.join(', ')}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="font-black text-sm text-[#D4AF37]">
                          {feeToDisplay === 0 ? 'GRÁTIS' : `R$ ${feeToDisplay.toFixed(2)}`}
                        </span>
                        {isFree && <span className="text-[9px] text-emerald-400 block font-bold">Frete Grátis Ativado</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-5 bg-[#141414] border border-[#242424] rounded-2xl flex items-center gap-3 text-white">
                <CheckCircle className="w-6 h-6 text-emerald-400 shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">Retirada Expressa no Balcão Aliança</h4>
                  <p className="text-xs text-[#888888]">
                    Seu pedido estará separado e higienizado em até 30 minutos na nossa loja física. Sem custo adicional de entrega.
                  </p>
                </div>
              </div>
            )}

            {/* Order notes */}
            <div>
              <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                Instruções especiais ou ponto de referência (opcional)
              </label>
              <textarea
                value={orderNotes}
                onChange={(e) => setOrderNotes(e.target.value)}
                placeholder="Ex: Tocar interfone 42, deixar na portaria, campainha alta..."
                rows={2}
                className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
              />
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-[#1C1C1C]">
              <button
                onClick={() => setStep(2)}
                className="px-4 py-2.5 text-xs text-[#888888] hover:text-white flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" /> Voltar
              </button>

              <button
                onClick={() => setStep(4)}
                className="px-6 py-3 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer"
              >
                Avançar para Pagamento <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: PAGAMENTO */}
        {step === 4 && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6">
            <div>
              <h2 className="text-white font-bold text-lg uppercase tracking-wider mb-1">
                Etapa 4: Forma de Pagamento
              </h2>
              <p className="text-xs text-[#888888]">
                Selecione o meio de pagamento seguro e tokenizado
              </p>
            </div>

            {/* Payment Method Selector */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { id: 'PIX', label: 'PIX Dinâmico', desc: 'Aprovação instantânea', badge: 'Instantâneo', icon: QrCode },
                { id: 'A_PRAZO', label: 'A Prazo (Crediário)', desc: 'Carnê ou fatura Aliança', badge: 'Sujeito a Aprovação', icon: Calendar },
                { id: 'CASH', label: 'Em Dinheiro na Entrega', desc: 'Pague ao motoboy com troco', badge: 'Sujeito a Aprovação', icon: Banknote },
                { id: 'BANK_TRANSFER', label: 'Outros Bancos', desc: 'BB, Bradesco, Caixa, Nubank', badge: 'Transferência / TED', icon: Building },
                { id: 'DELIVERY_CARD', label: 'Cartão na Maquininha', desc: 'Débito ou Crédito na entrega', badge: 'Maquininha Móvel', icon: CreditCard },
                { id: 'CREDIT_CARD', label: 'Cartão de Crédito Online', desc: 'Gateway Mercado Pago/Stripe', badge: '100% Seguro', icon: CreditCard }
              ].map((m) => {
                const Icon = m.icon;
                const isSelected = paymentMethod === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaymentMethod(m.id as any)}
                    className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#181818] border-[#D4AF37] text-white shadow-lg shadow-[#D4AF37]/15 ring-1 ring-[#D4AF37]/50'
                        : 'bg-[#111111] border-[#222222] text-[#888888] hover:border-[#333333]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <Icon className={`w-5 h-5 ${isSelected ? 'text-[#D4AF37]' : 'text-[#666666]'}`} />
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        m.badge === 'Sujeito a Aprovação'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-[#D4AF37]/20 text-[#F2D675] border border-[#D4AF37]/30'
                      }`}>
                        {m.badge}
                      </span>
                    </div>
                    <div>
                      <div className="font-bold text-xs text-white">{m.label}</div>
                      <div className="text-[10px] text-[#A0A0A0] mt-0.5">{m.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Payment specifics: PIX */}
            {paymentMethod === 'PIX' && (
              <div className="p-5 bg-[#141414] border border-[#D4AF37]/30 rounded-2xl flex items-center gap-3">
                <QrCode className="w-8 h-8 text-[#D4AF37] shrink-0" />
                <div className="text-xs text-[#BDBDBD]">
                  <strong className="text-white block font-bold mb-1">PIX Copia e Cola & QR Code Dinâmico</strong>
                  O QR Code oficial do Banco Central e o código Pix Copia e Cola serão gerados na próxima tela para pagamento instantâneo com baixa automática.
                </div>
              </div>
            )}

            {/* Payment specifics: A PRAZO (Sujeito a Aprovação) */}
            {paymentMethod === 'A_PRAZO' && (
              <div className="p-5 bg-[#161208] border border-amber-500/40 rounded-2xl space-y-3">
                <div className="flex items-start gap-3">
                  <ShieldAlert className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
                  <div className="space-y-1 text-xs">
                    <div className="flex items-center gap-2">
                      <strong className="text-white font-bold text-sm">Modalidade A Prazo (Sujeito a Aprovação Cadastral)</strong>
                      <span className="text-[9px] font-black uppercase px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded border border-amber-500/30">
                        Crediário Aliança
                      </span>
                    </div>
                    <p className="text-amber-200/90 leading-relaxed">
                      {settings?.creditTermsText || 'Sujeito a aprovação cadastral e análise de limite financeiro pelo Mercadinho Aliança.'}
                    </p>
                    <p className="text-[#AAAAAA] text-[11px] leading-relaxed pt-1">
                      ℹ️ O pedido será recebido e enviado à gerência financeira. Nossa equipe confirmará seu limite de crédito via WhatsApp no número <strong>{phone || whatsapp}</strong> antes de despachar as compras.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Payment specifics: DINHEIRO NA ENTREGA (Sujeito a Aprovação) */}
            {paymentMethod === 'CASH' && (
              <div className="p-5 bg-[#141414] border border-[#2A2A2A] rounded-2xl space-y-4">
                <div className="p-3 bg-amber-950/20 border border-amber-500/30 rounded-xl flex items-start gap-2.5 text-xs">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white font-bold block mb-0.5">Pagamento em Dinheiro no Ato da Entrega (Sujeito a Aprovação)</strong>
                    <span className="text-[#BDBDBD] text-[11px]">
                      {settings?.cashTermsText || 'Pagamento em espécie no ato da entrega, sujeito a conferência de troco e validação prévia.'}
                    </span>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-white uppercase block mb-1">
                    Precisa de troco para quanto? *
                  </label>
                  <input
                    type="text"
                    value={cashChangeFor}
                    onChange={(e) => setCashChangeFor(e.target.value)}
                    placeholder="Ex: Troco para R$ 100,00 ou Não preciso de troco"
                    className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none font-bold"
                  />
                  <span className="text-[10px] text-[#777] mt-1 block">
                    Informar o valor exato para troco agiliza a saída e a entrega com o motoboy.
                  </span>
                </div>
              </div>
            )}

            {/* Payment specifics: OUTROS BANCOS / TRANSFERÊNCIA BANCÁRIA */}
            {paymentMethod === 'BANK_TRANSFER' && (
              <div className="p-5 bg-[#121212] border border-[#2B2B2B] rounded-2xl space-y-4">
                <div>
                  <h4 className="text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2">
                    <Building className="w-4 h-4 text-[#D4AF37]" />
                    Selecione o Banco para Transferência / TED:
                  </h4>
                  <p className="text-[11px] text-[#888] mt-0.5">
                    Escolha em qual de nossas contas bancárias oficiais você deseja transferir o valor.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(settings?.bankAccounts && settings.bankAccounts.length > 0
                    ? settings.bankAccounts.filter(b => b.active)
                    : [
                        { id: 'bank-bb', bankName: 'Banco do Brasil', agency: '1234-5', account: '98765-4', accountType: 'CORRENTE', holderName: 'Mercadinho Aliança LTDA', document: '12.345.678/0001-90', pixKey: '12.345.678/0001-90', active: true },
                        { id: 'bank-bradesco', bankName: 'Bradesco', agency: '0456', account: '12345-6', accountType: 'CORRENTE', holderName: 'Mercadinho Aliança LTDA', document: '12.345.678/0001-90', pixKey: 'contato@mercadinhoalianca.com.br', active: true },
                        { id: 'bank-caixa', bankName: 'Caixa Econômica', agency: '0890', account: '003.00054321-0', accountType: 'CORRENTE', holderName: 'Mercadinho Aliança LTDA', document: '12.345.678/0001-90', pixKey: '74999598143', active: true },
                        { id: 'bank-nubank', bankName: 'Nubank (260)', agency: '0001', account: '8765432-1', accountType: 'CORRENTE', holderName: 'Mercadinho Aliança LTDA', document: '12.345.678/0001-90', pixKey: '74998008283', active: true }
                      ]
                  ).map((b) => {
                    const isSelected = (selectedBankId || 'bank-bb') === b.id;
                    return (
                      <div
                        key={b.id}
                        onClick={() => setSelectedBankId(b.id)}
                        className={`p-3.5 rounded-xl border text-xs cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-[#1C1808] border-[#D4AF37] text-white shadow-md'
                            : 'bg-[#161616] border-[#262626] text-[#AAAAAA] hover:border-[#383838]'
                        }`}
                      >
                        <div className="flex items-center justify-between font-bold mb-1">
                          <span className="text-white">{b.bankName}</span>
                          <span className="text-[10px] text-[#D4AF37]">{b.accountType}</span>
                        </div>
                        <div className="text-[11px] font-mono text-[#CCCCCC]">
                          Agência: <strong>{b.agency}</strong> • Conta: <strong>{b.account}</strong>
                        </div>
                        <div className="text-[10px] text-[#777777] mt-0.5 truncate">
                          {b.holderName} • {b.document}
                        </div>
                        {b.pixKey && (
                          <div className="mt-2 pt-1.5 border-t border-[#222] flex items-center justify-between text-[10px]">
                            <span className="text-[#888]">Chave Pix do banco:</span>
                            <span className="text-[#F2D675] font-mono truncate max-w-[140px]">{b.pixKey}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="p-3 bg-[#181818] border border-[#282828] rounded-xl text-[11px] text-[#999999] flex items-center gap-2">
                  <Info className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>
                    Após concluir o pedido, você receberá a confirmação e poderá anexar o comprovante de transferência diretamente no WhatsApp da loja.
                  </span>
                </div>
              </div>
            )}

            {/* Payment specifics: CARTÃO NA MAQUININHA */}
            {paymentMethod === 'DELIVERY_CARD' && (
              <div className="p-5 bg-[#141414] border border-[#2B2B2B] rounded-2xl flex items-center gap-3.5">
                <CreditCard className="w-8 h-8 text-[#D4AF37] shrink-0" />
                <div className="text-xs text-[#BDBDBD] space-y-1">
                  <strong className="text-white font-bold block">Maquininha Sem Fio Levada pelo Entregador</strong>
                  <p>
                    O entregador levará a máquina portátil com suporte a aproximação (NFC), chip, tarja, Pix bancário e cartões de débito/crédito (Visa, Mastercard, Elo, Hipercard, Vale Alimentação).
                  </p>
                </div>
              </div>
            )}

            {/* Payment specifics: CARTÃO DE CRÉDITO ONLINE */}
            {paymentMethod === 'CREDIT_CARD' && (
              <div className="p-5 bg-[#121212] border border-[#242424] rounded-2xl space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-[#1E1E1E]">
                  <span className="text-xs font-bold text-white uppercase">Dados do Cartão (Tokenização Segura)</span>
                  <span className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">SSL 256-bit</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="sm:col-span-2">
                    <label className="text-[11px] font-bold text-[#888888] uppercase block mb-1">Nome impresso no cartão</label>
                    <input
                      type="text"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      placeholder="Ex: ROBERTO LIMA"
                      className="w-full bg-[#181818] border border-[#2A2A2A] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="text-[11px] font-bold text-[#888888] uppercase block mb-1">Número do Cartão</label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="4000 0000 0000 0000"
                      className="w-full bg-[#181818] border border-[#2A2A2A] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-[#888888] uppercase block mb-1">Validade (MM/AA)</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      placeholder="12/28"
                      className="w-full bg-[#181818] border border-[#2A2A2A] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-[#888888] uppercase block mb-1">CVV</label>
                    <input
                      type="password"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      placeholder="123"
                      maxLength={4}
                      className="w-full bg-[#181818] border border-[#2A2A2A] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Financial summary before confirming */}
            <div className="p-4 bg-[#080808] border border-[#1C1C1C] rounded-2xl space-y-2 text-xs">
              <div className="flex justify-between text-[#888888]">
                <span>Subtotal dos Produtos:</span>
                <span className="text-white font-bold">R$ {cartSubtotal.toFixed(2)}</span>
              </div>
              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Desconto de Cupom:</span>
                  <span className="font-bold">- R$ {couponDiscount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-[#888888]">
                <span>Taxa de Entrega:</span>
                <span className="text-white font-bold">{deliveryFee === 0 ? 'GRÁTIS' : `R$ ${deliveryFee.toFixed(2)}`}</span>
              </div>
              {cartTotalSavings > 0 && (
                <div className="flex justify-between text-[#F2D675] font-bold">
                  <span>Economia no Atacado Obtida:</span>
                  <span>R$ {cartTotalSavings.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-black text-white pt-2 border-t border-[#1C1C1C]">
                <span>Total a Pagar:</span>
                <span className="text-[#F2D675] font-serif-luxury text-xl">R$ {effectiveTotal.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-[#1C1C1C]">
              <button
                onClick={() => setStep(3)}
                className="px-4 py-2.5 text-xs text-[#888888] hover:text-white flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" /> Voltar
              </button>

              <button
                onClick={handleFinishOrder}
                disabled={isSubmitting}
                className="px-8 py-3.5 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all shadow-xl shadow-[#D4AF37]/20 cursor-pointer"
              >
                {isSubmitting ? 'Gerando Pedido...' : 'Confirmar Pedido'}
                <Check className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: CONFIRMAÇÃO & STATUS TIMELINE */}
        {step === 5 && completedOrder && (
          <div className="space-y-6 animate-in fade-in zoom-in-95">
            {/* Success card */}
            <div className="bg-[#0B0B0B] border border-[#D4AF37]/50 rounded-3xl p-6 sm:p-10 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37] text-[#D4AF37] mx-auto flex items-center justify-center">
                <CheckCircle className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4AF37]">
                  Pedido Recebido com Sucesso!
                </span>
                <h2 className="text-2xl sm:text-3xl font-serif-luxury font-black text-white mt-1">
                  {completedOrder.id}
                </h2>
                <p className="text-xs text-[#999999] max-w-md mx-auto mt-1">
                  Obrigado por comprar no Mercadinho Aliança! Seu pedido já está sendo preparado com todo o carinho.
                </p>
              </div>

              {/* PIX QR CODE & Copia e Cola if PIX */}
              {completedOrder.paymentMethod === 'PIX' && (
                <div className="max-w-md mx-auto p-6 bg-[#111111] border border-[#2B2B2B] rounded-2xl text-center space-y-4 my-4">
                  <span className="text-xs font-bold text-white uppercase tracking-wider block">
                    Pagamento via PIX (Aprovação Instantânea)
                  </span>

                  {completedOrder.pixQrCodeBase64 ? (
                    <div className="p-3 bg-white rounded-xl inline-block shadow-lg mx-auto">
                      <img
                        src={completedOrder.pixQrCodeBase64}
                        alt="QR Code PIX"
                        className="w-48 h-48 object-contain"
                      />
                    </div>
                  ) : (
                    <div className="w-48 h-48 bg-white/10 rounded-xl mx-auto flex items-center justify-center text-xs">
                      Gerando QR Code...
                    </div>
                  )}

                  {completedOrder.pixCode && (
                    <div className="space-y-2">
                      <div className="p-2.5 bg-[#080808] border border-[#222222] rounded-xl text-[10px] font-mono text-[#CCCCCC] break-all max-h-16 overflow-y-auto">
                        {completedOrder.pixCode}
                      </div>

                      <button
                        onClick={() => {
                          if (completedOrder.pixCode) {
                            navigator.clipboard.writeText(completedOrder.pixCode);
                            setCopiedPix(true);
                            setTimeout(() => setCopiedPix(false), 3000);
                          }
                        }}
                        className="px-4 py-2 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 mx-auto cursor-pointer"
                      >
                        {copiedPix ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedPix ? 'Código Copiado!' : 'Copiar Código PIX'}
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* A PRAZO Notice in Confirmation */}
              {completedOrder.paymentMethod === 'A_PRAZO' && (
                <div className="max-w-md mx-auto p-5 bg-amber-950/20 border border-amber-500/40 rounded-2xl text-center space-y-2 my-4">
                  <div className="flex items-center justify-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                    <Calendar className="w-4 h-4" /> Pagamento A Prazo / Crediário Aliança
                  </div>
                  <p className="text-xs text-amber-200/90 leading-relaxed">
                    Seu pedido foi registrado e encaminhado para o setor de crédito. O atendimento entrará em contato via WhatsApp para confirmar a aprovação do seu limite e a data de vencimento.
                  </p>
                </div>
              )}

              {/* CASH Notice in Confirmation */}
              {completedOrder.paymentMethod === 'CASH' && (
                <div className="max-w-md mx-auto p-5 bg-[#141414] border border-[#2B2B2B] rounded-2xl text-center space-y-2 my-4">
                  <div className="flex items-center justify-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
                    <Banknote className="w-4 h-4" /> Pagamento em Dinheiro no Ato da Entrega
                  </div>
                  <p className="text-xs text-[#CCCCCC] leading-relaxed">
                    O entregador levará suas compras e receberá o valor em espécie na entrega.
                    {cashChangeFor && <span className="block mt-1 text-[#F2D675] font-bold">Anotado: {cashChangeFor}</span>}
                  </p>
                </div>
              )}

              {/* BANK TRANSFER Notice in Confirmation */}
              {completedOrder.paymentMethod === 'BANK_TRANSFER' && (
                <div className="max-w-md mx-auto p-5 bg-[#141414] border border-[#D4AF37]/30 rounded-2xl text-center space-y-3 my-4">
                  <div className="flex items-center justify-center gap-2 text-[#D4AF37] font-bold text-xs uppercase tracking-wider">
                    <Building className="w-4 h-4" /> Transferência Bancária / TED
                  </div>
                  <p className="text-xs text-[#BDBDBD] leading-relaxed">
                    Transfira o valor total de <strong>R$ {completedOrder.total.toFixed(2)}</strong> e envie o comprovante para nosso WhatsApp clicando em um dos botões abaixo.
                  </p>
                </div>
              )}

              {/* Order Actions: WhatsApp & Print */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-4 border-t border-[#1C1C1C]">
                <a
                  href={`https://wa.me/${settings?.whatsapp || '5574999598143'}?text=${getWhatsAppMessage(completedOrder)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 shadow-lg transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  Acompanhar no WhatsApp 1 ((74) 99959-8143)
                </a>

                <a
                  href={`https://wa.me/${settings?.whatsapp2 || '5574998008283'}?text=${getWhatsAppMessage(completedOrder)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-6 py-3 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 shadow-lg transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp 2 ((74) 99800-8283)
                </a>

                <button
                  onClick={() => setShowThermalReceipt(true)}
                  className="px-5 py-3 bg-[#181818] hover:bg-[#222222] text-[#D4AF37] border border-[#D4AF37]/40 font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  Imprimir Comprovante Térmico
                </button>
              </div>
            </div>

            {/* TIMELINE DO PEDIDO */}
            <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6">
              <h3 className="text-white font-bold text-sm uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#D4AF37]" />
                Linha do Tempo do Pedido
              </h3>

              <div className="space-y-4">
                {[
                  { title: 'PEDIDO RECEBIDO', desc: 'Registrado no sistema Aliança', done: true },
                  { title: 'PAGAMENTO CONFIRMADO', desc: 'Processado via gateway seguro', done: completedOrder.paymentStatus === 'APPROVED' },
                  { title: 'SEPARANDO PRODUTOS', desc: 'Separador selecionando itens frescos', done: false },
                  { title: 'EM PREPARAÇÃO', desc: 'Embalagem e conferência no balcão', done: false },
                  { title: 'SAIU PARA ENTREGA', desc: 'Motoboy a caminho do seu endereço', done: false },
                  { title: 'ENTREGUE', desc: 'Finalizado com sucesso', done: false }
                ].map((s, idx) => (
                  <div key={idx} className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          s.done ? 'bg-[#D4AF37] text-black' : 'bg-[#1C1C1C] text-[#555555] border border-[#2D2D2D]'
                        }`}
                      >
                        {s.done ? <Check className="w-3.5 h-3.5" /> : idx + 1}
                      </div>
                      {idx < 5 && <div className="w-0.5 h-8 bg-[#1E1E1E] my-1" />}
                    </div>

                    <div className="pt-0.5">
                      <div className={`text-xs font-bold uppercase ${s.done ? 'text-white' : 'text-[#666666]'}`}>
                        {s.title}
                      </div>
                      <div className="text-[11px] text-[#888888]">{s.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Modal Thermal Print */}
        {showThermalReceipt && completedOrder && (
          <ThermalReceipt
            order={completedOrder}
            settings={settings}
            onClose={() => setShowThermalReceipt(false)}
          />
        )}
      </div>
    </div>
  );
};
