import React, { useState } from 'react';
import { User, MapPin, Plus, Save, Phone, Mail, FileText, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { Address } from '../../shared/types.ts';

export const AccountPage: React.FC = () => {
  const { currentCustomer, updateCustomerProfile, saveNewAddress, showToast } = useApp();

  const [name, setName] = useState(currentCustomer.name);
  const [cpf, setCpf] = useState(currentCustomer.cpf);
  const [phone, setPhone] = useState(currentCustomer.phone);
  const [whatsapp, setWhatsapp] = useState(currentCustomer.whatsapp);
  const [email, setEmail] = useState(currentCustomer.email);
  const [birthDate, setBirthDate] = useState(currentCustomer.birthDate || '');

  // New Address modal state
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [newStreet, setNewStreet] = useState('');
  const [newNumber, setNewNumber] = useState('');
  const [newComplement, setNewComplement] = useState('');
  const [newNeighborhood, setNewNeighborhood] = useState('');
  const [newCity, setNewCity] = useState('Bahia');
  const [newState, setNewState] = useState('BA');
  const [newCep, setNewCep] = useState('');
  const [newRef, setNewRef] = useState('');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateCustomerProfile({
      name,
      cpf,
      phone,
      whatsapp,
      email,
      birthDate
    });
  };

  const handleSaveNewAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStreet.trim() || !newNumber.trim() || !newNeighborhood.trim()) {
      showToast('Campos obrigatórios', 'Preencha rua, número e bairro.', 'error');
      return;
    }

    const addr: Address = {
      id: `addr-${Date.now()}`,
      street: newStreet,
      number: newNumber,
      complement: newComplement,
      neighborhood: newNeighborhood,
      city: newCity,
      state: newState,
      cep: newCep,
      reference: newRef,
      isDefault: false
    };

    saveNewAddress(addr);
    setIsAddingAddress(false);
    setNewStreet('');
    setNewNumber('');
    setNewComplement('');
    setNewNeighborhood('');
    setNewCep('');
    setNewRef('');
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-10">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8 pb-4 border-b border-[#1E1E1E]">
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl uppercase tracking-wider text-white flex items-center gap-2">
            <User className="w-6 h-6 text-[#D4AF37]" />
            Minha Conta & Meus Endereços
          </h1>
          <p className="text-xs text-[#888888] mt-1">
            Gerencie seus dados cadastrais, múltiplos endereços de entrega e preferências
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Profile Form */}
          <div className="md:col-span-7 bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6">
            <h2 className="text-white font-bold text-sm uppercase tracking-wider">
              Dados Cadastrais
            </h2>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                  Nome Completo
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    CPF
                  </label>
                  <input
                    type="text"
                    value={cpf}
                    onChange={(e) => setCpf(e.target.value)}
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    Data de Nascimento
                  </label>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                    WhatsApp
                  </label>
                  <input
                    type="tel"
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1">
                  E-mail
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" />
                Salvar Alterações
              </button>
            </form>
          </div>

          {/* Addresses list */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-white font-bold text-sm uppercase tracking-wider">
                Endereços de Entrega
              </h2>
              <button
                onClick={() => setIsAddingAddress(true)}
                className="text-xs text-[#D4AF37] hover:underline font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Adicionar
              </button>
            </div>

            {/* List addresses */}
            <div className="space-y-3">
              {currentCustomer.addresses.map((addr) => (
                <div
                  key={addr.id}
                  className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-4 relative text-xs text-[#CCCCCC] space-y-1"
                >
                  {addr.isDefault && (
                    <span className="text-[9px] font-black uppercase text-[#D4AF37] bg-[#D4AF37]/10 px-2 py-0.5 rounded border border-[#D4AF37]/30 absolute top-3 right-3">
                      Principal
                    </span>
                  )}
                  <div className="font-bold text-white text-sm">
                    {addr.street}, {addr.number}
                  </div>
                  {addr.complement && <div>Complemento: {addr.complement}</div>}
                  <div>Bairro: {addr.neighborhood}</div>
                  <div>{addr.city} - {addr.state} | CEP: {addr.cep}</div>
                  {addr.reference && <div className="text-[10px] text-[#777]">Ref: {addr.reference}</div>}
                </div>
              ))}
            </div>

            {/* Add address modal/drawer */}
            {isAddingAddress && (
              <form onSubmit={handleSaveNewAddress} className="bg-[#111] border border-[#D4AF37]/40 rounded-2xl p-5 space-y-3 animate-in fade-in">
                <h4 className="text-white font-bold text-xs uppercase">Novo Endereço</h4>
                <input
                  type="text"
                  value={newStreet}
                  onChange={(e) => setNewStreet(e.target.value)}
                  placeholder="Rua / Avenida *"
                  className="w-full bg-[#181818] border border-[#2D2D2D] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  required
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={newNumber}
                    onChange={(e) => setNewNumber(e.target.value)}
                    placeholder="Número *"
                    className="w-full bg-[#181818] border border-[#2D2D2D] rounded-xl px-3 py-2 text-xs text-white outline-none"
                    required
                  />
                  <input
                    type="text"
                    value={newComplement}
                    onChange={(e) => setNewComplement(e.target.value)}
                    placeholder="Apto/Bloco"
                    className="w-full bg-[#181818] border border-[#2D2D2D] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={newNeighborhood}
                    onChange={(e) => setNewNeighborhood(e.target.value)}
                    placeholder="Bairro *"
                    className="w-full bg-[#181818] border border-[#2D2D2D] rounded-xl px-3 py-2 text-xs text-white outline-none"
                    required
                  />
                  <input
                    type="text"
                    value={newCep}
                    onChange={(e) => setNewCep(e.target.value)}
                    placeholder="CEP"
                    className="w-full bg-[#181818] border border-[#2D2D2D] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    type="submit"
                    className="flex-1 py-2 bg-[#D4AF37] text-black font-bold text-xs rounded-xl"
                  >
                    Salvar Endereço
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingAddress(false)}
                    className="px-3 py-2 text-xs text-[#888] hover:text-white"
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
