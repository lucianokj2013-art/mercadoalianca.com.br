import React, { useState, useEffect } from 'react';
import { Package, Search, Clock, CheckCircle2, ChevronRight, Printer, AlertCircle } from 'lucide-react';
import { Order } from '../../shared/types.ts';
import { api } from '../services/api.ts';
import { useApp } from '../context/AppContext.tsx';
import { ThermalReceipt } from '../components/ThermalReceipt.tsx';

export const OrdersPage: React.FC = () => {
  const { currentCustomer, settings } = useApp();
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchCode, setSearchCode] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const data = await api.getOrders();
        setOrders(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const filteredOrders = orders.filter((o) => {
    if (!searchCode.trim()) return true;
    return o.id.toLowerCase().includes(searchCode.toLowerCase()) ||
           o.customerName.toLowerCase().includes(searchCode.toLowerCase());
  });

  const getStatusBadge = (status: Order['status']) => {
    const map: Record<string, { label: string; color: string }> = {
      'NOVO': { label: 'Novo', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
      'PAGAMENTO_PENDENTE': { label: 'Pagto Pendente', color: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
      'PAGO': { label: 'Pago', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
      'SEPARANDO': { label: 'Separando Itens', color: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
      'EM_PREPARACAO': { label: 'Em Preparação', color: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30' },
      'SAIU_PARA_ENTREGA': { label: 'Saiu para Entrega', color: 'bg-[#D4AF37]/20 text-[#F2D675] border-[#D4AF37]/30' },
      'ENTREGUE': { label: 'Entregue', color: 'bg-green-500/20 text-green-400 border-green-500/30' },
      'CANCELADO': { label: 'Cancelado', color: 'bg-red-500/20 text-red-400 border-red-500/30' }
    };
    const s = map[status] || { label: status, color: 'bg-gray-500/20 text-gray-300' };
    return (
      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase border ${s.color}`}>
        {s.label}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-10">
      <div className="max-w-5xl mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-[#1E1E1E]">
          <div>
            <h1 className="text-white font-serif-luxury font-black text-2xl sm:text-3xl uppercase tracking-wider flex items-center gap-2">
              <Package className="w-6 h-6 text-[#D4AF37]" />
              Meus Pedidos & Rastreamento
            </h1>
            <p className="text-xs text-[#888888] mt-1">
              Acompanhe o status em tempo real da separação e entrega do seu pedido
            </p>
          </div>

          {/* Search order code */}
          <div className="relative max-w-xs w-full">
            <input
              type="text"
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              placeholder="Buscar por #ALN-000001..."
              className="w-full bg-[#111111] border border-[#262626] focus:border-[#D4AF37] text-xs text-white rounded-xl pl-9 pr-3 py-2 outline-none"
            />
            <Search className="w-4 h-4 text-[#666666] absolute left-3 top-2.5" />
          </div>
        </div>

        {/* Orders List */}
        {filteredOrders.length === 0 ? (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-12 text-center text-[#777777]">
            <Package className="w-12 h-12 text-[#333333] mx-auto mb-3" />
            <h3 className="text-white font-bold text-base mb-1">Nenhum pedido encontrado</h3>
            <p className="text-xs text-[#888888]">
              Você ainda não realizou compras com este código de rastreamento.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <div
                key={order.id}
                className="bg-[#0B0B0B] border border-[#1E1E1E] hover:border-[#D4AF37]/40 rounded-2xl p-5 transition-all shadow-md"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#181818]">
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-sm text-[#F2D675]">
                      {order.id}
                    </span>
                    {getStatusBadge(order.status)}
                  </div>

                  <div className="text-xs text-[#888888] flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                      {new Date(order.createdAt).toLocaleString('pt-BR')}
                    </span>
                    <button
                      onClick={() => {
                        setSelectedOrder(order);
                        setShowReceipt(true);
                      }}
                      className="px-2.5 py-1 bg-[#181818] hover:bg-[#252525] border border-[#333333] rounded-lg text-white font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Printer className="w-3 h-3 text-[#D4AF37]" /> Recibo
                    </button>
                  </div>
                </div>

                {/* Items preview */}
                <div className="py-3 flex flex-wrap gap-2 items-center">
                  {order.items.slice(0, 4).map((i, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 bg-[#121212] border border-[#222222] rounded-xl px-2.5 py-1 text-xs text-white"
                    >
                      <img src={i.image} alt={i.productName} className="w-5 h-5 rounded object-cover" />
                      <span className="truncate max-w-[140px] font-medium">{i.productName}</span>
                      <span className="text-[#888888]">x{i.quantity}</span>
                    </div>
                  ))}
                  {order.items.length > 4 && (
                    <span className="text-xs text-[#777777]">
                      +{order.items.length - 4} outros itens
                    </span>
                  )}
                </div>

                {/* Footer info: Total, Delivery address */}
                <div className="pt-3 border-t border-[#181818] flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div className="text-[#888888]">
                    Destino: <strong className="text-white">{order.deliveryAddress ? `${order.deliveryAddress.neighborhood}, ${order.deliveryAddress.city}` : 'Retirada na Loja'}</strong>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[#777777]">
                      Forma: <strong className="text-white">{order.paymentMethod}</strong>
                    </span>
                    <span className="font-serif-luxury font-black text-sm text-[#F2D675]">
                      Total: R$ {order.total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal Thermal Print */}
        {showReceipt && selectedOrder && (
          <ThermalReceipt
            order={selectedOrder}
            settings={settings}
            onClose={() => setShowReceipt(false)}
          />
        )}
      </div>
    </div>
  );
};
