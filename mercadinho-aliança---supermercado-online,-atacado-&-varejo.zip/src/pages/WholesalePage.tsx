import React, { useState, useEffect } from 'react';
import { TrendingDown, Sparkles, Building2, ShoppingBag, CheckCircle, Package } from 'lucide-react';
import { ProductCard } from '../components/ProductCard.tsx';
import { Product } from '../../shared/types.ts';
import { api } from '../services/api.ts';
import { useApp } from '../context/AppContext.tsx';

export const WholesalePage: React.FC = () => {
  const { navigate } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const data = await api.getProducts({ wholesale: true });
        setProducts(data);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-10">
      <div className="max-w-7xl mx-auto px-4">
        {/* Banner */}
        <div className="bg-gradient-to-r from-[#141414] via-[#0F0F0F] to-[#141414] border border-[#2B2B2B] rounded-3xl p-6 sm:p-10 mb-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="max-w-2xl relative z-10 space-y-4">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#F2D675] text-xs font-bold uppercase tracking-wider">
              <TrendingDown className="w-4 h-4" /> Compre Mais, Pague Menos
            </div>
            <h1 className="font-serif-luxury font-black text-3xl sm:text-4xl lg:text-5xl uppercase tracking-wider text-white">
              Atacado <span className="gold-gradient-text">Aliança</span>
            </h1>
            <p className="text-sm text-[#BDBDBD] leading-relaxed">
              Condições especiais e preços reduzidos para padarias, restaurantes, lanchonetes, conveniências e famílias que desejam abastecer o mês economizando até 25% em cada produto.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3 bg-[#0A0A0A] border border-[#222222] rounded-xl flex items-center gap-2.5">
                <CheckCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="text-xs text-[#CCCCCC] font-semibold">Sem CNPJ obrigatório</span>
              </div>
              <div className="p-3 bg-[#0A0A0A] border border-[#222222] rounded-xl flex items-center gap-2.5">
                <CheckCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="text-xs text-[#CCCCCC] font-semibold">Desconto automático no carrinho</span>
              </div>
              <div className="p-3 bg-[#0A0A0A] border border-[#222222] rounded-xl flex items-center gap-2.5">
                <CheckCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="text-xs text-[#CCCCCC] font-semibold">Entrega rápida paletizada</span>
              </div>
            </div>
          </div>
        </div>

        {/* Product Grid */}
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-white font-bold text-lg uppercase tracking-wider flex items-center gap-2">
            <Package className="w-5 h-5 text-[#D4AF37]" />
            Produtos com Tabela de Atacado ({products.length})
          </h2>
          <span className="text-xs text-[#777777]">
            O desconto é aplicado automaticamente ao atingir a quantidade mínima de cada item
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {products.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </div>
    </div>
  );
};
