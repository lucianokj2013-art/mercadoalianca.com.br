import React from 'react';
import { ShieldCheck, FileText, Building2, CheckCircle2, MapPin, Phone, MessageCircle, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

interface AboutTermsPagesProps {
  view: 'about' | 'terms' | 'privacy';
}

export const AboutTermsPages: React.FC<AboutTermsPagesProps> = ({ view }) => {
  const { navigate, settings } = useApp();

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-12">
      <div className="max-w-4xl mx-auto px-4">
        {view === 'about' && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-8 sm:p-12 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#F2D675] text-xs font-bold uppercase tracking-wider">
              <Building2 className="w-4 h-4" /> Nossa História & Tradição
            </div>

            <h1 className="font-serif-luxury font-black text-3xl sm:text-4xl uppercase tracking-wider text-white">
              Sobre o <span className="gold-gradient-text">Mercadinho Aliança</span>
            </h1>

            <p className="text-sm text-[#CCCCCC] leading-relaxed">
              O <strong>Mercadinho Aliança</strong> nasceu com a missão de unir a tradição do acolhimento do comércio de bairro à eficiência e tecnologia do e-commerce moderno de ponta.
            </p>

            <p className="text-sm text-[#AAAAAA] leading-relaxed">
              Diferente de supermercados convencionais, criamos uma estrutura híbrida onde o cliente compra no varejo com entrega rápida em até 45 minutos ou aproveita os mesmos preços de atacado direto para sua despensa ou comércio.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-[#1C1C1C]">
              <div className="p-4 bg-[#111111] rounded-2xl border border-[#222222]">
                <h3 className="font-bold text-sm text-[#D4AF37] mb-1">Qualidade Máxima</h3>
                <p className="text-xs text-[#888888]">Carnes nobres, cortes especiais e hortifrúti fresco diariamente.</p>
              </div>
              <div className="p-4 bg-[#111111] rounded-2xl border border-[#222222]">
                <h3 className="font-bold text-sm text-[#D4AF37] mb-1">Logística Ágil</h3>
                <p className="text-xs text-[#888888]">Frota própria equipada com caixas térmicas e motoristas treinados.</p>
              </div>
              <div className="p-4 bg-[#111111] rounded-2xl border border-[#222222]">
                <h3 className="font-bold text-sm text-[#D4AF37] mb-1">Preço Justo</h3>
                <p className="text-xs text-[#888888]">Preços de atacado automáticos por volume sem burocracia.</p>
              </div>
            </div>

            {/* Store Location & Official Contacts Card */}
            <div className="pt-6 border-t border-[#1C1C1C] space-y-4">
              <h3 className="font-serif-luxury font-bold text-lg text-white uppercase tracking-wider flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#D4AF37]" />
                Nossa Loja Física & Atendimento
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-4 bg-[#141414] rounded-2xl border border-[#262626] space-y-2">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-bold">Endereço da Loja:</strong>
                      <span className="text-[#AAAAAA]">
                        {settings?.address || 'Rua Principal'}{settings?.streetNumber ? `, ${settings.streetNumber}` : ', 100'} - {settings?.neighborhood || 'Centro'}
                        <br />
                        {settings?.city || 'Bahia'} - {settings?.state || 'BA'}, CEP {settings?.cep || '48900-000'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2 pt-2 border-t border-[#222]">
                    <Clock className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-bold">Horário de Funcionamento:</strong>
                      <span className="text-[#AAAAAA]">
                        {settings?.businessHours || 'Segunda a Sábado: 07h às 22h | Domingos e Feriados: 08h às 20h'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-[#141414] rounded-2xl border border-[#262626] space-y-3">
                  <strong className="text-white block font-bold">Telefones Oficiais (DDD 74):</strong>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[#CCCCCC]">Telefone 1:</span>
                      <a href={`tel:${settings?.phone || '74999598143'}`} className="font-mono font-bold text-[#F2D675] hover:underline">
                        {settings?.phone || '(74) 99959-8143'}
                      </a>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#CCCCCC]">Telefone 2:</span>
                      <a href={`tel:${settings?.phone2 || '74998008283'}`} className="font-mono font-bold text-[#F2D675] hover:underline">
                        {settings?.phone2 || '(74) 99800-8283'}
                      </a>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#222] flex gap-2">
                    <a
                      href={`https://wa.me/${settings?.whatsapp || '5574999598143'}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> WhatsApp 1
                    </a>
                    <a
                      href={`https://wa.me/${settings?.whatsapp2 || '5574998008283'}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-2 px-3 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> WhatsApp 2
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'terms' && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-8 sm:p-12 space-y-6">
            <h1 className="font-serif-luxury font-black text-3xl uppercase tracking-wider text-white">
              Termos e Condições de Uso
            </h1>
            <div className="space-y-4 text-xs text-[#AAAAAA] leading-relaxed">
              <p>
                1. <strong>Preços e Estoque:</strong> Os preços de varejo e atacado exibidos são atualizados em tempo real conforme as regras de negócio do Mercadinho Aliança. Produtos com peso variável (como carnes e frutas no quilo) são pesados com tolerância legal de pesagem de precisão.
              </p>
              <p>
                2. <strong>Regra de Atacado:</strong> A concessão do preço de atacado ocorre automaticamente no carrinho assim que o cliente atinge ou ultrapassa a quantidade mínima estipulada para cada produto.
              </p>
              <p>
                3. <strong>Prazos de Entrega:</strong> As entregas em domicílio são realizadas no raio de atuação cadastrado nas zonas de entrega. O prazo médio estimado varia entre 35 a 75 minutos dependendo da distância e trânsito da região.
              </p>
              <p>
                4. <strong>Formas de Pagamento:</strong> Aceitamos PIX com chave e QR Code estático/dinâmico, cartões de crédito e débito via gateways homologados e pagamento na entrega em dinheiro com troco previamente informado.
              </p>
            </div>
          </div>
        )}

        {view === 'privacy' && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-8 sm:p-12 space-y-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" /> LGPD Compliant
            </div>

            <h1 className="font-serif-luxury font-black text-3xl uppercase tracking-wider text-white">
              Política de Privacidade e Proteção de Dados
            </h1>

            <div className="space-y-4 text-xs text-[#AAAAAA] leading-relaxed">
              <p>
                No Mercadinho Aliança, levamos a sério a segurança dos seus dados pessoais. Seus dados de cadastro (nome, CPF, endereço e telefone) são utilizados única e exclusivamente para a emissão de nota fiscal, faturamento e logística de entrega do seu pedido.
              </p>
              <p>
                <strong>Nunca armazenamos dados de cartão de crédito:</strong> Todas as transações digitais são processadas por parceiros de pagamento certificados (Mercado Pago / Stripe) com criptografia ponta a ponta e tokenização.
              </p>
              <p>
                Você pode a qualquer momento consultar, alterar ou solicitar a exclusão dos seus dados entrando em contato pelo e-mail <strong>privacidade@mercadinhoalianca.com.br</strong>.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
