import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  SlidersHorizontal,
  Grid,
  List,
  Sparkles,
  TrendingDown,
  X,
  ChevronDown
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { ProductCard } from '../components/ProductCard.tsx';
import { Product, ProductCategory } from '../../shared/types.ts';
import { api } from '../services/api.ts';

export const ProductsPage: React.FC = () => {
  const { viewParam } = useApp();

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState(viewParam || '');
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');
  const [selectedBrand, setSelectedBrand] = useState<string>('Todas');
  const [onlyOnSale, setOnlyOnSale] = useState(false);
  const [onlyWholesale, setOnlyWholesale] = useState(false);
  const [maxPrice, setMaxPrice] = useState<number>(100);
  const [sortBy, setSortBy] = useState<'featured' | 'priceAsc' | 'priceDesc' | 'name'>('featured');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  useEffect(() => {
    if (viewParam) {
      // Check if viewParam matches a category or search
      const cats = [
        'Mercearia', 'Bebidas', 'Carnes', 'Frutas', 'Verduras', 'Legumes',
        'Laticínios', 'Frios', 'Padaria', 'Congelados', 'Higiene', 'Limpeza',
        'Bebês', 'Pet', 'Utilidades', 'Outros'
      ];
      if (cats.includes(viewParam)) {
        setSelectedCategory(viewParam);
        setSearch('');
      } else {
        setSearch(viewParam);
      }
    }
  }, [viewParam]);

  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true);
        const data = await api.getProducts();
        setProducts(data);
      } catch (err) {
        console.error('Failed to load products:', err);
      } finally {
        setLoading(false);
      }
    };
    loadProducts();
  }, []);

  const categories: string[] = [
    'Todas',
    'Mercearia', 'Bebidas', 'Carnes', 'Frutas', 'Verduras', 'Legumes',
    'Laticínios', 'Frios', 'Padaria', 'Congelados', 'Higiene', 'Limpeza',
    'Bebês', 'Pet', 'Utilidades', 'Outros'
  ];

  const uniqueBrands = ['Todas', ...Array.from(new Set(products.map(p => p.brand))).filter(Boolean)];

  // Apply filters
  let filtered = products.filter(p => {
    if (selectedCategory !== 'Todas' && p.category !== selectedCategory) return false;
    if (selectedBrand !== 'Todas' && p.brand !== selectedBrand) return false;
    if (onlyOnSale && !p.onSale) return false;
    if (onlyWholesale && p.wholesalePrice >= p.retailPrice) return false;

    const effectivePrice = p.onSale && p.salePrice ? p.salePrice : p.retailPrice;
    if (effectivePrice > maxPrice) return false;

    if (search.trim()) {
      const q = search.toLowerCase();
      const match =
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.barcode.includes(q) ||
        p.ean.includes(q);
      if (!match) return false;
    }

    return true;
  });

  // Sorting
  filtered.sort((a, b) => {
    const priceA = a.onSale && a.salePrice ? a.salePrice : a.retailPrice;
    const priceB = b.onSale && b.salePrice ? b.salePrice : b.retailPrice;

    if (sortBy === 'priceAsc') return priceA - priceB;
    if (sortBy === 'priceDesc') return priceB - priceA;
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
  });

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Page Title & Breadcrumb */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-[#1E1E1E]">
          <div>
            <h1 className="text-white font-serif-luxury font-black text-2xl sm:text-3xl uppercase tracking-wider flex items-center gap-2">
              <span className="w-2 h-6 bg-[#D4AF37] rounded-sm" />
              Catálogo de Produtos
            </h1>
            <p className="text-xs text-[#888888] mt-1">
              {filtered.length} {filtered.length === 1 ? 'produto encontrado' : 'produtos encontrados'}
            </p>
          </div>

          {/* View mode & mobile filter button */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
              className="lg:hidden px-3 py-2 bg-[#141414] border border-[#2B2B2B] rounded-xl text-xs font-bold text-white flex items-center gap-2"
            >
              <SlidersHorizontal className="w-4 h-4 text-[#D4AF37]" />
              Filtros
            </button>

            <div className="flex items-center bg-[#111111] border border-[#222222] rounded-xl p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'grid' ? 'bg-[#D4AF37] text-black font-bold' : 'text-[#777777] hover:text-white'
                }`}
                title="Grade"
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'list' ? 'bg-[#D4AF37] text-black font-bold' : 'text-[#777777] hover:text-white'
                }`}
                title="Lista"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* SIDEBAR FILTERS (Desktop) */}
          <div className="hidden lg:block space-y-6 bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-5 h-fit sticky top-24">
            <div className="flex items-center justify-between pb-3 border-b border-[#1E1E1E]">
              <span className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2">
                <Filter className="w-4 h-4 text-[#D4AF37]" />
                Filtrar Resultados
              </span>
              {(selectedCategory !== 'Todas' || selectedBrand !== 'Todas' || onlyOnSale || onlyWholesale || search) && (
                <button
                  onClick={() => {
                    setSelectedCategory('Todas');
                    setSelectedBrand('Todas');
                    setOnlyOnSale(false);
                    setOnlyWholesale(false);
                    setSearch('');
                    setMaxPrice(100);
                  }}
                  className="text-[10px] text-[#D4AF37] hover:underline cursor-pointer"
                >
                  Limpar
                </button>
              )}
            </div>

            {/* Search Input */}
            <div>
              <label className="text-[11px] font-bold uppercase text-[#888888] block mb-2">
                Buscar por texto ou código
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Nome, marca, EAN, SKU..."
                  className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none pl-8"
                />
                <Search className="w-3.5 h-3.5 text-[#666666] absolute left-2.5 top-3" />
              </div>
            </div>

            {/* Quick check boxes */}
            <div className="space-y-2 pt-2 border-t border-[#1A1A1A]">
              <label className="flex items-center gap-2.5 text-xs text-[#CCCCCC] cursor-pointer hover:text-white">
                <input
                  type="checkbox"
                  checked={onlyOnSale}
                  onChange={(e) => setOnlyOnSale(e.target.checked)}
                  className="accent-[#D4AF37] w-4 h-4 rounded"
                />
                <span>Apenas Ofertas do Dia</span>
              </label>

              <label className="flex items-center gap-2.5 text-xs text-[#CCCCCC] cursor-pointer hover:text-white">
                <input
                  type="checkbox"
                  checked={onlyWholesale}
                  onChange={(e) => setOnlyWholesale(e.target.checked)}
                  className="accent-[#D4AF37] w-4 h-4 rounded"
                />
                <span>Apenas Preços com Atacado</span>
              </label>
            </div>

            {/* Categories */}
            <div className="pt-2 border-t border-[#1A1A1A]">
              <label className="text-[11px] font-bold uppercase text-[#888888] block mb-2">
                Departamento
              </label>
              <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`w-full text-left text-xs py-1.5 px-2 rounded-lg transition-colors flex items-center justify-between ${
                      selectedCategory === cat
                        ? 'bg-[#D4AF37] text-black font-bold'
                        : 'text-[#A0A0A0] hover:text-white hover:bg-[#141414]'
                    }`}
                  >
                    <span>{cat}</span>
                    <span className="text-[10px] opacity-70">
                      {cat === 'Todas' ? products.length : products.filter(p => p.category === cat).length}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Brands */}
            <div className="pt-2 border-t border-[#1A1A1A]">
              <label className="text-[11px] font-bold uppercase text-[#888888] block mb-2">
                Marca
              </label>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none"
              >
                {uniqueBrands.map((b) => (
                  <option key={b} value={b} className="bg-[#111111]">
                    {b}
                  </option>
                ))}
              </select>
            </div>

            {/* Max Price Slider */}
            <div className="pt-2 border-t border-[#1A1A1A]">
              <div className="flex justify-between text-xs mb-1">
                <span className="font-bold text-[#888888] uppercase text-[11px]">Preço Máximo:</span>
                <span className="font-bold text-[#D4AF37]">R$ {maxPrice.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="3"
                max="100"
                step="1"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[#D4AF37]"
              />
            </div>
          </div>

          {/* MAIN CONTENT AREA */}
          <div className="lg:col-span-3 space-y-4">
            {/* Sort toolbar */}
            <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-[#888888]">Ordenar por:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-[#141414] border border-[#262626] rounded-lg px-2.5 py-1 text-xs text-white outline-none"
                >
                  <option value="featured">Destaques Aliança</option>
                  <option value="priceAsc">Menor Preço</option>
                  <option value="priceDesc">Maior Preço</option>
                  <option value="name">Nome (A - Z)</option>
                </select>
              </div>

              {/* Active filters pill list */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {selectedCategory !== 'Todas' && (
                  <span className="bg-[#161616] text-[#D4AF37] border border-[#D4AF37]/30 px-2 py-0.5 rounded-full text-[10px] flex items-center gap-1">
                    {selectedCategory}
                    <X className="w-3 h-3 cursor-pointer" onClick={() => setSelectedCategory('Todas')} />
                  </span>
                )}
                {search && (
                  <span className="bg-[#161616] text-white border border-[#333] px-2 py-0.5 rounded-full text-[10px] flex items-center gap-1">
                    "{search}"
                    <X className="w-3 h-3 cursor-pointer" onClick={() => setSearch('')} />
                  </span>
                )}
              </div>
            </div>

            {/* Products Grid / List */}
            {filtered.length === 0 ? (
              <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-12 text-center text-[#777777]">
                <Search className="w-12 h-12 mx-auto text-[#444444] mb-3" />
                <h3 className="text-white font-bold text-base mb-1">Nenhum produto encontrado</h3>
                <p className="text-xs text-[#888888] max-w-sm mx-auto mb-4">
                  Tente alterar seus filtros de pesquisa, categoria ou faixa de preço.
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('Todas');
                    setSelectedBrand('Todas');
                    setOnlyOnSale(false);
                    setOnlyWholesale(false);
                    setSearch('');
                    setMaxPrice(100);
                  }}
                  className="px-4 py-2 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs uppercase rounded-xl transition-all cursor-pointer"
                >
                  Ver Todos os Produtos
                </button>
              </div>
            ) : (
              <div
                className={
                  viewMode === 'grid'
                    ? 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5'
                    : 'space-y-4'
                }
              >
                {filtered.map((prod) => (
                  <ProductCard key={prod.id} product={prod} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
