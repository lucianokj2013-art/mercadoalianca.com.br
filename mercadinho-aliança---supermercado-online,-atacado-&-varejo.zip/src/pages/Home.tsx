import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ArrowRight,
  TrendingDown,
  ShoppingBag,
  Clock,
  ShieldCheck,
  Truck,
  MessageCircle,
  Tag,
  Flame,
  CheckCircle2,
  Package
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { ProductCard } from '../components/ProductCard.tsx';
import { Product, ProductCategory } from '../../shared/types.ts';
import { api } from '../services/api.ts';

export const Home: React.FC = () => {
  const { navigate, settings } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<{ name: string; count: number }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [prods, cats] = await Promise.all([
          api.getProducts(),
          api.getCategories()
        ]);
        setProducts(prods);
        setCategories(cats);
      } catch (err) {
        console.error('Error fetching home data:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const offers = products.filter((p) => p.onSale).slice(0, 6);
  const wholesaleHighlights = products.filter((p) => p.wholesalePrice < p.retailPrice).slice(0, 6);
  const featured = products.filter((p) => p.featured).slice(0, 6);

  // Category icons mapping
  const categoryBadges: Record<string, string> = {
    'Mercearia': '🌾',
    'Bebidas': '🍷',
    'Carnes': '🥩',
    'Frutas': '🍎',
    'Verduras': '🥬',
    'Legumes': '🥕',
    'Laticínios': '🧀',
    'Frios': '🥓',
    'Padaria': '🥖',
    'Congelados': '🧊',
    'Higiene': '🧼',
    'Limpeza': '✨',
    'Bebês': '🍼',
    'Pet': '🐾',
    'Utilidades': '🍳',
    'Outros': '🛒'
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] pb-16">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden border-b border-[#1A1A1A] bg-gradient-to-b from-[#0B0B0B] via-[#080808] to-[#050505] pt-12 pb-20">
        {/* Subtle background glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Headlines & CTA */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#161616] border border-[#D4AF37]/40 shadow-inner">
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span className="text-xs font-bold uppercase tracking-wider text-[#F2D675]">
                  Varejo & Atacado no mesmo lugar
                </span>
              </div>

              {/* Logo Oficial com Destaque Máximo */}
              <div className="flex items-center justify-center lg:justify-start pt-1 pb-1">
                <div className="logo-highlight-badge p-3 sm:p-4 bg-gradient-to-b from-[#1C1808] via-[#121008] to-[#080808] rounded-3xl border-2 border-[#D4AF37] shadow-2xl inline-flex items-center gap-4">
                  <img
                    src={settings?.logoUrl || '/logo.png'}
                    alt="Mercadinho Aliança - Logomarca Oficial"
                    className="h-16 sm:h-20 md:h-24 w-auto object-contain filter drop-shadow-[0_4px_16px_rgba(255,204,0,0.5)]"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/logo.svg';
                    }}
                  />
                  <div className="text-left pr-2 hidden sm:block">
                    <span className="text-[10px] text-[#D4AF37] font-black uppercase tracking-widest block">
                      ★ LOGOMARCA OFICIAL ★
                    </span>
                    <strong className="text-white font-serif-luxury font-black text-base md:text-lg block tracking-wider">
                      MERCADINHO ALIANÇA
                    </strong>
                    <span className="text-[11px] text-[#A0A0A0]">Supermercado Premium & Atacado</span>
                  </div>
                </div>
              </div>

              <h1 className="font-serif-luxury font-black text-4xl sm:text-5xl lg:text-6xl tracking-tight text-white leading-tight">
                MERCADINHO <span className="gold-gradient-text">ALIANÇA</span>
              </h1>

              <p className="text-lg sm:text-xl text-[#BDBDBD] max-w-2xl font-normal leading-relaxed">
                Seu supermercado completo, agora também online.
                Carnes nobres, hortifrúti fresco e mercearia selecionada com entrega expressa na sua porta.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
                <button
                  onClick={() => navigate('products')}
                  className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-[#050505] font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-[#D4AF37]/20 transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  Comprar Agora
                </button>

                <button
                  onClick={() => navigate('offers')}
                  className="px-6 py-3.5 rounded-xl bg-[#141414] hover:bg-[#1E1E1E] border border-[#D4AF37]/40 text-[#F2D675] font-black text-xs uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Flame className="w-4 h-4 text-red-500" />
                  Ver Ofertas
                </button>

                <button
                  onClick={() => navigate('wholesale')}
                  className="px-6 py-3.5 rounded-xl bg-[#141414] hover:bg-[#1E1E1E] border border-[#2B2B2B] text-white font-bold text-xs uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer"
                >
                  <TrendingDown className="w-4 h-4 text-[#D4AF37]" />
                  Compre no Atacado
                </button>
              </div>

              {/* Trust Badges */}
              <div className="pt-6 grid grid-cols-3 gap-4 border-t border-[#1C1C1C] max-w-lg mx-auto lg:mx-0 text-left">
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <div className="text-[11px] leading-tight text-[#999999]">
                    <strong className="text-white block font-bold">Entrega 45 min</strong>
                    Raio de até 15 km
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <TrendingDown className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <div className="text-[11px] leading-tight text-[#999999]">
                    <strong className="text-white block font-bold">Preço de Atacado</strong>
                    Economize comprando +
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <div className="text-[11px] leading-tight text-[#999999]">
                    <strong className="text-white block font-bold">100% Seguro</strong>
                    PIX ou Cartão
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Hero Showcase Card */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md bg-[#0F0F0F] border border-[#262626] rounded-3xl p-5 shadow-2xl overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/15 rounded-full blur-2xl" />

                <div className="flex items-center justify-between pb-4 border-b border-[#202020]">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                    <span className="text-xs font-black uppercase text-[#F2D675] tracking-wider">
                      Destaque do Dia
                    </span>
                  </div>
                  <span className="text-[11px] text-[#888888] font-mono">
                    #SUPER-OFERTA
                  </span>
                </div>

                {/* Big Highlight product */}
                <div className="my-4 relative rounded-2xl overflow-hidden bg-[#181818] h-48 border border-[#252525]">
                  <img
                    src="https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80"
                    alt="Contra Filé Bovino"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2.5 left-2.5 bg-red-600 text-white font-black text-xs px-2.5 py-0.5 rounded shadow">
                    -15% OFF
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-xs text-[#D4AF37] font-semibold uppercase tracking-wider">
                    Carnes Nobres • Açougue Aliança
                  </div>
                  <h3 className="text-white font-black text-lg">
                    Contra Filé Bovino Premium kg
                  </h3>
                  <div className="flex items-baseline justify-between pt-1">
                    <div>
                      <span className="text-xs text-[#666666] line-through block">R$ 64,90</span>
                      <span className="text-2xl font-black text-white">R$ 54,90 <span className="text-xs text-[#888888] font-normal">/kg</span></span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-[#A0A0A0] uppercase font-bold block">No Atacado:</span>
                      <span className="text-base font-black text-[#D4AF37]">R$ 49,90 <span className="text-[10px] text-[#888888]">/kg</span></span>
                      <span className="text-[9px] text-[#777777] block">a partir de 5 kg</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => navigate('products', 'contra filé')}
                  className="w-full mt-5 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  Aproveitar Oferta
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WHATSAPP INSTANT ORDER BANNER */}
      <section className="max-w-7xl mx-auto px-4 -mt-6 relative z-20">
        <div className="bg-gradient-to-r from-[#121212] via-[#161616] to-[#121212] border border-[#2B2B2B] hover:border-[#D4AF37]/50 rounded-2xl p-4 sm:p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
              <MessageCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm sm:text-base">
                Prefere pedir pelo WhatsApp?
              </h4>
              <p className="text-xs text-[#999999]">
                Envie sua lista de compras ou feche seu pedido com nossos atendentes: <strong>(74) 99959-8143</strong> ou <strong>(74) 99800-8283</strong>.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <a
              href={`https://wa.me/${settings?.whatsapp || '5574999598143'}?text=${encodeURIComponent('Olá! Gostaria de fazer um pedido no Mercadinho Aliança.')}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shrink-0"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp 1
            </a>
            <a
              href={`https://wa.me/${settings?.whatsapp2 || '5574998008283'}?text=${encodeURIComponent('Olá! Gostaria de fazer um pedido no Mercadinho Aliança.')}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shrink-0"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp 2
            </a>
          </div>
        </div>
      </section>

      {/* SECTION: CATEGORIES */}
      <section className="max-w-7xl mx-auto px-4 pt-16">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-white font-serif-luxury font-black text-xl sm:text-2xl uppercase tracking-wider flex items-center gap-2">
              <span className="w-2 h-6 bg-[#D4AF37] rounded-sm" />
              Departamentos
            </h2>
            <p className="text-xs text-[#888888] mt-1">
              Navegue pelas principais categorias do Mercadinho Aliança
            </p>
          </div>
          <button
            onClick={() => navigate('categories')}
            className="text-xs text-[#D4AF37] hover:text-[#F2D675] font-bold flex items-center gap-1 cursor-pointer"
          >
            Ver Todas <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
          {categories.map((cat) => (
            <button
              key={cat.name}
              onClick={() => navigate('products', cat.name)}
              className="bg-[#0B0B0B] hover:bg-[#141414] border border-[#1E1E1E] hover:border-[#D4AF37]/50 rounded-xl p-3.5 text-center transition-all group flex flex-col items-center justify-center gap-1.5 cursor-pointer"
            >
              <span className="text-2xl transform group-hover:scale-110 transition-transform">
                {categoryBadges[cat.name] || '🛒'}
              </span>
              <span className="text-xs font-bold text-white group-hover:text-[#F2D675] truncate w-full">
                {cat.name}
              </span>
              <span className="text-[10px] text-[#666666]">
                {cat.count} {cat.count === 1 ? 'item' : 'itens'}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* SECTION: OFERTAS DO DIA */}
      <section className="max-w-7xl mx-auto px-4 pt-16">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-red-600/20 text-red-400 border border-red-500/30 text-[10px] font-black uppercase tracking-wider">
                Economia Real
              </span>
              <span className="text-xs text-[#777777] flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#D4AF37]" /> Ofertas válidas hoje
              </span>
            </div>
            <h2 className="text-white font-serif-luxury font-black text-xl sm:text-2xl uppercase tracking-wider mt-1 flex items-center gap-2">
              <Flame className="w-6 h-6 text-red-500" />
              Ofertas do Dia
            </h2>
          </div>

          <button
            onClick={() => navigate('offers')}
            className="text-xs text-[#D4AF37] hover:text-[#F2D675] font-bold flex items-center gap-1 cursor-pointer"
          >
            Ver Todas ({offers.length}) <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {offers.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* SECTION: COMPRE NO ATACADO */}
      <section className="max-w-7xl mx-auto px-4 pt-16">
        <div className="bg-gradient-to-r from-[#121212] via-[#0E0E0E] to-[#121212] border border-[#2A2A2A] rounded-3xl p-6 sm:p-8 relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#F2D675] text-xs font-bold uppercase tracking-wider mb-2">
                <TrendingDown className="w-4 h-4" /> Descontos por Volume
              </div>
              <h2 className="text-white font-serif-luxury font-black text-2xl sm:text-3xl uppercase tracking-wider">
                Compre no Atacado
              </h2>
              <p className="text-xs sm:text-sm text-[#999999] max-w-xl mt-1">
                Compre em quantidade e pague preços de atacado. Perfeito para comércios, lanchonetes, famílias grandes e quem gosta de economizar!
              </p>
            </div>

            <button
              onClick={() => navigate('wholesale')}
              className="px-5 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all shrink-0 cursor-pointer"
            >
              Catálogo de Atacado Completo
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-5">
            {wholesaleHighlights.slice(0, 3).map((prod) => (
              <ProductCard key={prod.id} product={prod} />
            ))}
          </div>
        </div>
      </section>

      {/* SECTION: INTELIGÊNCIA COMERCIAL & RECOMENDAÇÕES */}
      <section className="max-w-7xl mx-auto px-4 pt-16">
        <div className="mb-6">
          <div className="inline-flex items-center gap-1.5 text-xs text-[#D4AF37] font-bold uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            Inteligência Comercial Aliança
          </div>
          <h2 className="text-white font-serif-luxury font-black text-xl sm:text-2xl uppercase tracking-wider mt-1">
            Frequentemente Comprados Juntos
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Combinações perfeitas para sua despensa e refeições em família
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {featured.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>
    </div>
  );
};
