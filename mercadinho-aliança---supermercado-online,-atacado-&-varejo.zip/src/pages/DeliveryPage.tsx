import React, { useState, useEffect } from 'react';
import { Truck, MapPin, Clock, ShieldCheck, CheckCircle2, Search } from 'lucide-react';
import { DeliveryZone } from '../../shared/types.ts';
import { api } from '../services/api.ts';
import { useApp } from '../context/AppContext.tsx';

export const DeliveryPage: React.FC = () => {
  const { settings, navigate } = useApp();
  const [zones, setZones] = useState<DeliveryZone[]>([]);
  const [testNeighborhood, setTestNeighborhood] = useState('');
  const [calculatedZone, setCalculatedZone] = useState<DeliveryZone | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.getDeliveryZones();
        setZones(data);
      } catch (err) {
        console.error(err);
      }
    };
    load();
  }, []);

  const handleSimulate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testNeighborhood.trim()) return;
    const q = testNeighborhood.toLowerCase();
    const found = zones.find(z =>
      z.neighborhoods.some(n => n.toLowerCase().includes(q))
    );
    setCalculatedZone(found || zones[0] || null);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-10">
      <div className="max-w-5xl mx-auto px-4">
        {/* Title */}
        <div className="mb-10 text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#F2D675] text-xs font-bold uppercase tracking-wider mb-3">
            <Truck className="w-4 h-4" /> Logística Própria Mercadinho Aliança
          </div>
          <h1 className="font-serif-luxury font-black text-3xl sm:text-4xl uppercase tracking-wider text-white">
            Delivery & Zonas de Entrega
          </h1>
          <p className="text-xs sm:text-sm text-[#888888] mt-2">
            Entregamos carnes selecionadas, verduras frescas e compras de supermercado com embalagem térmica e motoboys próprios.
          </p>
        </div>

        {/* Neighborhood Simulator Form */}
        <div className="bg-[#0B0B0B] border border-[#222222] rounded-3xl p-6 sm:p-8 mb-12 shadow-xl max-w-xl mx-auto">
          <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-2 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#D4AF37]" />
            Simule a taxa para o seu bairro
          </h3>

          <form onSubmit={handleSimulate} className="flex gap-2 mb-4">
            <input
              type="text"
              value={testNeighborhood}
              onChange={(e) => setTestNeighborhood(e.target.value)}
              placeholder="Digite seu bairro (ex: Centro, Bela Vista, Jardins)..."
              className="flex-1 bg-[#141414] border border-[#2A2A2A] focus:border-[#D4AF37] text-xs text-white rounded-xl px-4 py-3 outline-none"
            />
            <button
              type="submit"
              className="px-5 py-3 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer"
            >
              Simular
            </button>
          </form>

          {calculatedZone && (
            <div className="p-4 bg-[#141414] border border-[#D4AF37]/40 rounded-2xl animate-in fade-in">
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-sm text-white">{calculatedZone.name}</span>
                <span className="font-serif-luxury font-black text-base text-[#F2D675]">
                  R$ {calculatedZone.fee.toFixed(2)}
                </span>
              </div>
              <p className="text-xs text-[#888888]">
                Tempo estimado: <strong>{calculatedZone.estimatedTimeMin} minutos</strong> • Raio de até {calculatedZone.distanceKm} km
              </p>
              <div className="text-[10px] text-[#666666] mt-2">
                Compras acima de R$ {settings?.freeShippingThreshold || 180},00 ganham <strong>Frete Grátis</strong>!
              </div>
            </div>
          )}
        </div>

        {/* Zones Table */}
        <div className="space-y-4 mb-12">
          <h2 className="text-white font-bold text-base uppercase tracking-wider mb-4">
            Tabela de Zonas e Prazos
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {zones.map((zone) => (
              <div
                key={zone.id}
                className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-5 hover:border-[#D4AF37]/40 transition-all shadow-md flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider">
                      Até {zone.distanceKm} km
                    </span>
                    <span className="font-serif-luxury font-black text-lg text-white">
                      R$ {zone.fee.toFixed(2)}
                    </span>
                  </div>

                  <h3 className="text-white font-bold text-sm mb-2">{zone.name}</h3>

                  <div className="space-y-2 text-xs text-[#888888] mb-4">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>Estimativa: <strong>{zone.estimatedTimeMin} min</strong></span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#666666] block font-semibold uppercase">Bairros principais:</span>
                      <span className="text-white text-[11px]">{zone.neighborhoods.join(', ')}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => navigate('products')}
                  className="w-full py-2 bg-[#141414] hover:bg-[#202020] border border-[#2B2B2B] text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors text-center cursor-pointer"
                >
                  Fazer Compras
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Benefits strip */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 p-6 bg-[#0B0B0B] border border-[#1A1A1A] rounded-2xl">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
            <div>
              <strong className="text-white text-xs block font-bold">Embalagem Térmica Gratuita</strong>
              <p className="text-[11px] text-[#888888]">Carnes, queijos e congelados chegam no ponto perfeito.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
            <div>
              <strong className="text-white text-xs block font-bold">Hortifrúti Selecionado na Hora</strong>
              <p className="text-[11px] text-[#888888]">Nossos separadores escolhem as melhores frutas e verduras.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
            <div>
              <strong className="text-white text-xs block font-bold">Rastreamento Passo a Passo</strong>
              <p className="text-[11px] text-[#888888]">Acompanhe desde a separação até o motoboy na sua porta.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
