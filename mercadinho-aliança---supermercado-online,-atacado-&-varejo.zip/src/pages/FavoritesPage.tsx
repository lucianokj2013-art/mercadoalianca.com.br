import React, { useState, useEffect } from 'react';
import { Heart, ShoppingBag, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { ProductCard } from '../components/ProductCard.tsx';
import { Product } from '../../shared/types.ts';
import { api } from '../services/api.ts';

export const FavoritesPage: React.FC = () => {
  const { favorites, navigate, addToCart } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const data = await api.getProducts();
        setProducts(data);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const favoriteProducts = products.filter(p => favorites.includes(p.id));

  const handleAddAllToCart = () => {
    favoriteProducts.forEach(p => addToCart(p, 1));
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] py-10">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-[#1E1E1E]">
          <div>
            <h1 className="text-white font-serif-luxury font-black text-2xl sm:text-3xl uppercase tracking-wider flex items-center gap-2">
              <Heart className="w-6 h-6 text-red-500 fill-red-500" />
              Meus Favoritos ({favoriteProducts.length})
            </h1>
            <p className="text-xs text-[#888888] mt-1">
              Produtos que você mais gosta, salvos para recompras rápidas
            </p>
          </div>

          {favoriteProducts.length > 0 && (
            <button
              onClick={handleAddAllToCart}
              className="px-5 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              Adicionar Todos à Cesta
            </button>
          )}
        </div>

        {favoriteProducts.length === 0 ? (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-12 text-center text-[#777777]">
            <Heart className="w-12 h-12 mx-auto text-[#333333] mb-3" />
            <h3 className="text-white font-bold text-base mb-1">Nenhum produto favoritado</h3>
            <p className="text-xs text-[#888888] max-w-sm mx-auto mb-4">
              Clique no ícone de coração nos produtos para guardá-los nesta lista para fácil acesso.
            </p>
            <button
              onClick={() => navigate('products')}
              className="px-4 py-2 bg-[#D4AF37] text-black font-bold text-xs uppercase rounded-xl"
            >
              Explorar Catálogo
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {favoriteProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
