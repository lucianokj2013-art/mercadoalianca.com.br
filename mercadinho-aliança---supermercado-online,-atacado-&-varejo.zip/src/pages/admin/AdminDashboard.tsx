import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  ShoppingBag,
  TrendingUp,
  AlertTriangle,
  Users,
  Package,
  TrendingDown,
  Clock,
  ArrowUpRight,
  ShieldAlert,
  Calendar
} from 'lucide-react';
import { Order, Product } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';

export const AdminDashboard: React.FC<{ onNavigateToTab: (tab: string) => void }> = ({ onNavigateToTab }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const [ord, prod] = await Promise.all([
          api.getOrders(),
          api.getProducts()
        ]);
        setOrders(ord);
        setProducts(prod);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  // Financial calculations
  const nonCancelledOrders = orders.filter(o => o.status !== 'CANCELADO');
  const totalRevenueMonth = nonCancelledOrders.reduce((acc, o) => acc + o.total, 0);
  const revenueToday = nonCancelledOrders.slice(0, 5).reduce((acc, o) => acc + o.total, 0) * 0.45; // simulated today proportion
  const ordersTodayCount = Math.max(1, Math.round(orders.length * 0.4));
  const pendingOrders = orders.filter(o => o.status === 'NOVO' || o.status === 'PAGAMENTO_PENDENTE' || o.status === 'SEPARANDO');
  const deliveredOrders = orders.filter(o => o.status === 'ENTREGUE');
  const ticketMedio = nonCancelledOrders.length ? totalRevenueMonth / nonCancelledOrders.length : 0;

  // Wholesale vs Retail orders
  const wholesaleOrders = orders.filter(o => o.items.some(i => i.isWholesale));
  const retailOrders = orders.filter(o => o.items.every(i => !i.isWholesale));

  // Low stock
  const lowStockProducts = products.filter(p => p.stock <= p.minStock);

  // Total products sold
  const totalProductsSold = nonCancelledOrders.reduce((acc, o) => {
    return acc + o.items.reduce((sum, item) => sum + item.quantity, 0);
  }, 0);

  // Sales by payment methods
  const pixCount = orders.filter(o => o.paymentMethod === 'PIX').length;
  const cardCount = orders.filter(o => o.paymentMethod === 'CREDIT_CARD' || o.paymentMethod === 'DEBIT_CARD').length;
  const cashCount = orders.filter(o => o.paymentMethod === 'CASH').length;

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E1E1E]">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Painel Executivo
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Dashboard Geral
          </h1>
        </div>

        <div className="flex items-center gap-2 text-xs text-[#888888] bg-[#0E0E0E] px-3 py-1.5 rounded-xl border border-[#222222]">
          <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Mês Corrente • Tempo Real</span>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Faturamento do Mês */}
        <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-5 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-[#888888] uppercase font-bold tracking-wider">Faturamento Mês</span>
            <div className="p-2 rounded-xl bg-[#D4AF37]/15 text-[#D4AF37]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-serif-luxury font-black text-white">
            R$ {totalRevenueMonth.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-emerald-400 mt-2 flex items-center gap-1 font-semibold">
            <ArrowUpRight className="w-3.5 h-3.5" /> +18.4% vs mês anterior
          </div>
        </div>

        {/* Faturamento Hoje */}
        <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-5 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-[#888888] uppercase font-bold tracking-wider">Faturamento Hoje</span>
            <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-serif-luxury font-black text-white">
            R$ {revenueToday.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-[#A0A0A0] mt-2 font-medium">
            {ordersTodayCount} pedidos processados hoje
          </div>
        </div>

        {/* Pedidos Pendentes */}
        <div
          onClick={() => onNavigateToTab('orders')}
          className="bg-[#0B0B0B] border border-[#1E1E1E] hover:border-amber-500/40 rounded-2xl p-5 relative overflow-hidden shadow-lg cursor-pointer transition-all"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-[#888888] uppercase font-bold tracking-wider">Pedidos Pendentes</span>
            <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-serif-luxury font-black text-amber-400">
            {pendingOrders.length}
          </div>
          <div className="text-[11px] text-[#A0A0A0] mt-2 font-medium">
            Aguardando pagamento ou separação
          </div>
        </div>

        {/* Ticket Médio */}
        <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-5 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-[#888888] uppercase font-bold tracking-wider">Ticket Médio</span>
            <div className="p-2 rounded-xl bg-purple-500/15 text-purple-400">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-serif-luxury font-black text-white">
            R$ {ticketMedio.toFixed(2)}
          </div>
          <div className="text-[11px] text-[#888888] mt-2 font-medium">
            Média por compra concluída
          </div>
        </div>
      </div>

      {/* Secondary KPI Strip: Atacado vs Varejo, Estoque Baixo, Clientes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0D0D0D] border border-[#1C1C1C] rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#777] font-bold uppercase block">Pedidos Atacado</span>
            <span className="text-lg font-black text-[#F2D675]">{wholesaleOrders.length}</span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-[#777] font-bold uppercase block">Pedidos Varejo</span>
            <span className="text-lg font-black text-white">{retailOrders.length}</span>
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-[#1C1C1C] rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#777] font-bold uppercase block">Itens Vendidos</span>
            <span className="text-lg font-black text-white">{totalProductsSold} un</span>
          </div>
          <Package className="w-5 h-5 text-[#D4AF37]" />
        </div>

        <div
          onClick={() => onNavigateToTab('inventory')}
          className="bg-[#0D0D0D] border border-[#1C1C1C] hover:border-red-500/40 rounded-2xl p-4 flex items-center justify-between cursor-pointer"
        >
          <div>
            <span className="text-[10px] text-red-400 font-bold uppercase block">Estoque Baixo</span>
            <span className="text-lg font-black text-red-400">{lowStockProducts.length} itens</span>
          </div>
          <ShieldAlert className="w-5 h-5 text-red-500" />
        </div>

        <div className="bg-[#0D0D0D] border border-[#1C1C1C] rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#777] font-bold uppercase block">Novos Clientes</span>
            <span className="text-lg font-black text-white">+{Math.max(3, orders.length * 2)}</span>
          </div>
          <Users className="w-5 h-5 text-blue-400" />
        </div>
      </div>

      {/* CHARTS & DISTRIBUTION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Chart 1: Vendas por Dia / Semana (SVG Bar chart) */}
        <div className="lg:col-span-8 bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-[#1A1A1A]">
            <div>
              <h3 className="text-white font-bold text-sm uppercase tracking-wider">
                Evolução de Vendas (Últimos 7 Dias)
              </h3>
              <span className="text-xs text-[#777777]">Faturamento diário em Reais (R$)</span>
            </div>
            <span className="text-xs font-bold text-[#D4AF37] bg-[#D4AF37]/10 px-2.5 py-1 rounded-lg border border-[#D4AF37]/20">
              Total 7d: R$ {(totalRevenueMonth * 0.7).toFixed(2)}
            </span>
          </div>

          {/* SVG Bar Chart */}
          <div className="h-56 flex items-end justify-between gap-3 pt-6 px-2">
            {[
              { day: 'Seg', val: 1420, h: 45 },
              { day: 'Ter', val: 1980, h: 62 },
              { day: 'Qua', val: 1650, h: 52 },
              { day: 'Qui', val: 2450, h: 78 },
              { day: 'Sex', val: 3200, h: 96 },
              { day: 'Sáb', val: 3890, h: 100 },
              { day: 'Hoje', val: 2840, h: 82 }
            ].map((bar, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                <span className="text-[10px] font-bold text-[#F2D675] opacity-0 group-hover:opacity-100 transition-opacity">
                  R$ {bar.val}
                </span>
                <div className="w-full bg-[#161616] rounded-t-xl h-40 flex items-end p-1">
                  <div
                    className="w-full bg-gradient-to-t from-[#D4AF37] to-[#F2D675] rounded-t-lg transition-all duration-700"
                    style={{ height: `${bar.h}%` }}
                  />
                </div>
                <span className="text-xs font-bold text-[#888888]">{bar.day}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Chart 2: Formas de Pagamento & Atacado x Varejo */}
        <div className="lg:col-span-4 space-y-6">
          {/* Payment Methods */}
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-white font-bold text-sm uppercase tracking-wider border-b border-[#1A1A1A] pb-3">
              Formas de Pagamento
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between text-[#CCCCCC] mb-1">
                  <span className="font-semibold">PIX (Instantâneo)</span>
                  <strong className="text-[#D4AF37]">65%</strong>
                </div>
                <div className="w-full h-2 bg-[#1A1A1A] rounded-full overflow-hidden">
                  <div className="w-[65%] h-full bg-[#D4AF37] rounded-full" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[#CCCCCC] mb-1">
                  <span className="font-semibold">Cartão de Crédito</span>
                  <strong className="text-white">25%</strong>
                </div>
                <div className="w-full h-2 bg-[#1A1A1A] rounded-full overflow-hidden">
                  <div className="w-[25%] h-full bg-white rounded-full" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[#CCCCCC] mb-1">
                  <span className="font-semibold">Dinheiro na Entrega</span>
                  <strong className="text-[#888888]">10%</strong>
                </div>
                <div className="w-full h-2 bg-[#1A1A1A] rounded-full overflow-hidden">
                  <div className="w-[10%] h-full bg-[#555555] rounded-full" />
                </div>
              </div>
            </div>
          </div>

          {/* Atacado vs Varejo Share */}
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-3">
            <h3 className="text-white font-bold text-sm uppercase tracking-wider border-b border-[#1A1A1A] pb-3">
              Atacado vs Varejo
            </h3>
            <div className="flex items-center justify-between text-xs pt-1">
              <div>
                <span className="text-[10px] text-[#777] uppercase block font-bold">Varejo</span>
                <span className="text-base font-black text-white">58%</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-[#777] uppercase block font-bold">Atacado (Volume)</span>
                <span className="text-base font-black text-[#D4AF37]">42%</span>
              </div>
            </div>
            <div className="w-full h-2.5 bg-[#1A1A1A] rounded-full overflow-hidden flex">
              <div className="w-[58%] h-full bg-white" />
              <div className="w-[42%] h-full bg-[#D4AF37]" />
            </div>
          </div>
        </div>
      </div>

      {/* Low stock alert table */}
      {lowStockProducts.length > 0 && (
        <div className="bg-[#0B0B0B] border border-red-500/30 rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              <h3 className="text-white font-bold text-sm uppercase tracking-wider">
                Alerta de Produtos com Estoque Baixo ou Crítico
              </h3>
            </div>
            <button
              onClick={() => onNavigateToTab('inventory')}
              className="text-xs text-[#D4AF37] hover:underline font-bold"
            >
              Repor Estoque
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#1E1E1E] text-[#888888] uppercase text-[10px]">
                  <th className="py-2">Produto</th>
                  <th className="py-2">Categoria</th>
                  <th className="py-2">Estoque Atual</th>
                  <th className="py-2">Estoque Mínimo</th>
                  <th className="py-2 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#161616]">
                {lowStockProducts.map((p) => (
                  <tr key={p.id} className="text-white">
                    <td className="py-2.5 font-bold flex items-center gap-2">
                      <img src={p.image} alt={p.name} className="w-7 h-7 rounded object-cover" />
                      {p.name}
                    </td>
                    <td className="py-2.5 text-[#AAAAAA]">{p.category}</td>
                    <td className="py-2.5 font-black text-red-400">{p.stock} {p.unit}</td>
                    <td className="py-2.5 text-[#777777]">{p.minStock} {p.unit}</td>
                    <td className="py-2.5 text-right">
                      <button
                        onClick={() => onNavigateToTab('inventory')}
                        className="px-2.5 py-1 bg-[#1A1A1A] hover:bg-[#D4AF37] hover:text-black rounded text-[11px] font-bold text-white transition-colors"
                      >
                        Entrada
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
