import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  User,
  Plus,
  Check,
  Key,
  Trash2,
  Edit2,
  Eye,
  EyeOff,
  Lock,
  Phone,
  Mail,
  AlertCircle,
  RefreshCw,
  Search,
  CheckCircle,
  X
} from 'lucide-react';
import { StaffUser, StaffRole } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';

export const AdminUsers: React.FC = () => {
  const { showToast, settings, refreshSettings } = useApp();
  const [staff, setStaff] = useState<StaffUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');

  // Modals state
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<StaffUser | null>(null);

  // Form state for adding/editing collaborator
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formRole, setFormRole] = useState<StaffRole>('CAIXA');
  const [formPassword, setFormPassword] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formActive, setFormActive] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Master Password Modal state
  const [isMasterModalOpen, setIsMasterModalOpen] = useState(false);
  const [currentMasterPass, setCurrentMasterPass] = useState('');
  const [newMasterPass, setNewMasterPass] = useState('');
  const [confirmMasterPass, setConfirmMasterPass] = useState('');
  const [showMasterPass, setShowMasterPass] = useState(false);
  const [savingMaster, setSavingMaster] = useState(false);

  // Delete modal state
  const [userToDelete, setUserToDelete] = useState<StaffUser | null>(null);
  const [deleting, setDeleting] = useState(false);

  // View password in table toggle
  const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>({});

  const togglePasswordVisibility = (id: string) => {
    setVisiblePasswords(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const loadStaff = async () => {
    try {
      setLoading(true);
      const data = await api.getStaff();
      setStaff(data);
    } catch (err) {
      console.error(err);
      showToast('Erro', 'Não foi possível carregar a equipe.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStaff();
  }, []);

  const roleDescriptions: Record<StaffRole, string> = {
    'ADMIN': 'Acesso irrestrito a todos os módulos, configurações, chaves, IA e relatórios.',
    'GERENTE': 'Acesso a produtos, pedidos, controle de estoque, relatórios e promoções.',
    'ESTOQUE': 'Focado no inventário, entradas de notas, baixas e contagem de mercadorias.',
    'CAIXA': 'Atendimento a pedidos de balcão, recebimentos e emissão de comprovantes.',
    'ENTREGA': 'Módulo de expedição, roteirização e despacho com motoboys.',
    'ATENDIMENTO': 'SAC, suporte a clientes via WhatsApp e consulta de pedidos.'
  };

  const roleBadges: Record<StaffRole, { bg: string; text: string; border: string }> = {
    'ADMIN': { bg: 'bg-[#D4AF37]/20', text: 'text-[#F2D675]', border: 'border-[#D4AF37]/40' },
    'GERENTE': { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-500/40' },
    'ESTOQUE': { bg: 'bg-blue-500/20', text: 'text-blue-300', border: 'border-blue-500/40' },
    'CAIXA': { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/40' },
    'ENTREGA': { bg: 'bg-amber-500/20', text: 'text-amber-300', border: 'border-amber-500/40' },
    'ATENDIMENTO': { bg: 'bg-pink-500/20', text: 'text-pink-300', border: 'border-pink-500/40' }
  };

  const openAddModal = () => {
    setEditingUser(null);
    setFormName('');
    setFormEmail('');
    setFormRole('CAIXA');
    setFormPassword('');
    setFormPhone('');
    setFormActive(true);
    setShowPassword(false);
    setIsAddEditModalOpen(true);
  };

  const openEditModal = (user: StaffUser) => {
    setEditingUser(user);
    setFormName(user.name);
    setFormEmail(user.email);
    setFormRole(user.role);
    setFormPassword(user.password || '');
    setFormPhone(user.phone || '');
    setFormActive(user.active);
    setShowPassword(false);
    setIsAddEditModalOpen(true);
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formEmail.trim()) {
      showToast('Campos obrigatórios', 'Preencha o nome e e-mail do colaborador.', 'error');
      return;
    }

    if (!formPassword.trim()) {
      showToast('Senha obrigatória', 'Defina a senha de acesso deste colaborador.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingUser) {
        // Update existing user
        await api.updateStaff(editingUser.id, {
          name: formName,
          email: formEmail,
          role: formRole,
          password: formPassword,
          phone: formPhone,
          active: formActive
        });
        showToast('Colaborador Atualizado', `Dados de ${formName} atualizados com sucesso.`, 'success');
      } else {
        // Create new user
        await api.createStaff({
          name: formName,
          email: formEmail,
          role: formRole,
          password: formPassword,
          phone: formPhone,
          active: formActive
        });
        showToast('Colaborador Adicionado', `Novo colaborador ${formName} cadastrado com sucesso.`, 'success');
      }
      setIsAddEditModalOpen(false);
      loadStaff();
    } catch (err: any) {
      showToast('Erro ao salvar', err?.message || 'Não foi possível salvar o colaborador.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;
    setDeleting(true);
    try {
      await api.deleteStaff(userToDelete.id);
      showToast('Colaborador Removido', `${userToDelete.name} foi removido da equipe.`, 'info');
      setUserToDelete(null);
      loadStaff();
    } catch {
      showToast('Erro', 'Não foi possível remover o colaborador.', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const handleChangeMasterPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentMasterPass || !newMasterPass) {
      showToast('Campos obrigatórios', 'Preencha a senha atual e a nova senha.', 'error');
      return;
    }

    if (newMasterPass !== confirmMasterPass) {
      showToast('Senhas não conferem', 'A nova senha e a confirmação devem ser idênticas.', 'error');
      return;
    }

    setSavingMaster(true);
    try {
      await api.changeMasterPassword(currentMasterPass, newMasterPass);
      await refreshSettings();
      showToast('Senha Mestre Alterada', 'Sua nova senha mestre foi atualizada com sucesso!', 'success');
      setIsMasterModalOpen(false);
      setCurrentMasterPass('');
      setNewMasterPass('');
      setConfirmMasterPass('');
    } catch (err: any) {
      showToast('Erro', err?.message || 'Senha mestre atual incorreta.', 'error');
    } finally {
      setSavingMaster(false);
    }
  };

  const handleQuickToggleActive = async (user: StaffUser) => {
    try {
      await api.updateStaff(user.id, { active: !user.active });
      showToast(
        user.active ? 'Colaborador Desativado' : 'Colaborador Ativado',
        `${user.name} agora está ${!user.active ? 'ativo' : 'inativo'}.`,
        'info'
      );
      loadStaff();
    } catch {
      showToast('Erro', 'Falha ao alterar status.', 'error');
    }
  };

  const filteredStaff = staff.filter(u => {
    const matchesSearch =
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase());
    const matchesRole = roleFilter === 'ALL' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Top Header & Master Password Info */}
      <div className="pb-4 border-b border-[#1E1E1E] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Gestão de Equipe & Controle Total
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Colaboradores, Cargos & Senhas
          </h1>
          <p className="text-xs text-[#888888] mt-1">
            Adicione e remova funcionários, altere cargos e defina senhas individuais personalizadas.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Change Master Password Button */}
          <button
            onClick={() => setIsMasterModalOpen(true)}
            className="px-4 py-2.5 bg-[#161616] hover:bg-[#222222] border border-[#D4AF37]/50 hover:border-[#D4AF37] text-[#F2D675] font-bold text-xs rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-lg"
            title="Alterar a senha mestre do Administrador (Padrão inicial: 12345)"
          >
            <Key className="w-4 h-4 text-[#D4AF37]" />
            <span>Senha Mestre (12345)</span>
          </button>

          {/* Add Collaborator Button */}
          <button
            onClick={openAddModal}
            className="px-5 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-xl shadow-[#D4AF37]/20"
          >
            <Plus className="w-4 h-4" />
            Novo Colaborador
          </button>
        </div>
      </div>

      {/* Master Password Reminder Strip */}
      <div className="p-4 bg-gradient-to-r from-[#141414] to-[#0A0A0A] border border-[#D4AF37]/30 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-white font-bold flex items-center gap-2">
              <span>Sua Senha Mestre de Administrador está Ativa</span>
              <span className="bg-[#D4AF37]/20 text-[#F2D675] text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-[#D4AF37]/40">
                Padrão: 12345
              </span>
            </div>
            <p className="text-[#888888] text-[11px] mt-0.5">
              Com ela você pode desbloquear qualquer área ou redefinir acessos. As senhas dos seus colaboradores você define abaixo ao cadastrá-los.
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsMasterModalOpen(true)}
          className="text-xs text-[#D4AF37] hover:text-[#F2D675] font-bold underline flex items-center gap-1 cursor-pointer shrink-0"
        >
          Alterar Senha Mestre
        </button>
      </div>

      {/* Filters & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nome ou e-mail..."
            className="w-full bg-[#111111] border border-[#262626] focus:border-[#D4AF37] text-white rounded-xl pl-9 pr-3 py-2.5 outline-none"
          />
          <Search className="w-4 h-4 text-[#777] absolute left-3 top-3 pointer-events-none" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-[#888] text-xs font-bold whitespace-nowrap">Filtrar Cargo:</span>
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="bg-[#111111] border border-[#262626] text-white rounded-xl px-3 py-2 text-xs outline-none cursor-pointer flex-1 sm:flex-initial"
          >
            <option value="ALL">Todos os Cargos ({staff.length})</option>
            <option value="ADMIN">ADMIN</option>
            <option value="GERENTE">GERENTE</option>
            <option value="ESTOQUE">ESTOQUE</option>
            <option value="CAIXA">CAIXA</option>
            <option value="ENTREGA">ENTREGA</option>
            <option value="ATENDIMENTO">ATENDIMENTO</option>
          </select>
        </div>
      </div>

      {/* Staff Table */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#121212] border-b border-[#1E1E1E] text-[#777] uppercase text-[10px] tracking-wider">
                <th className="py-3.5 px-4">Colaborador</th>
                <th className="py-3.5 px-4">E-mail de Login</th>
                <th className="py-3.5 px-4">Cargo / Função</th>
                <th className="py-3.5 px-4">Senha Cadastrada</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161616]">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-[#777]">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#D4AF37]" />
                    Carregando colaboradores...
                  </td>
                </tr>
              ) : filteredStaff.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-[#777]">
                    Nenhum colaborador encontrado com os filtros aplicados.
                  </td>
                </tr>
              ) : (
                filteredStaff.map((u) => {
                  const badge = roleBadges[u.role] || { bg: 'bg-[#222]', text: 'text-white', border: 'border-[#444]' };
                  const isPassVisible = Boolean(visiblePasswords[u.id]);

                  return (
                    <tr key={u.id} className="text-white hover:bg-[#121212] transition-colors">
                      {/* Name & Phone */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-[#181818] border border-[#2B2B2B] flex items-center justify-center text-[#D4AF37] font-bold shrink-0">
                            {u.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <span className="font-bold text-white block text-sm">{u.name}</span>
                            {u.phone && (
                              <span className="text-[11px] text-[#777] flex items-center gap-1 font-mono">
                                <Phone className="w-3 h-3 text-[#D4AF37]" /> {u.phone}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Email */}
                      <td className="py-3.5 px-4 font-mono text-[#AAA]">
                        {u.email}
                      </td>

                      {/* Role */}
                      <td className="py-3.5 px-4">
                        <span className={`inline-block px-2.5 py-1 rounded-lg text-[10px] font-black uppercase border ${badge.bg} ${badge.text} ${badge.border}`}>
                          {u.role}
                        </span>
                        <span className="text-[10px] text-[#666] block mt-0.5 max-w-[200px] truncate" title={roleDescriptions[u.role]}>
                          {roleDescriptions[u.role]}
                        </span>
                      </td>

                      {/* Password Defined by Admin */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <div className="px-2.5 py-1 bg-[#161616] border border-[#2B2B2B] rounded-lg font-mono text-xs text-[#F2D675]">
                            {isPassVisible ? (
                              <span>{u.password || '12345'}</span>
                            ) : (
                              <span>••••••</span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => togglePasswordVisibility(u.id)}
                            className="p-1 text-[#777] hover:text-white rounded hover:bg-[#222]"
                            title={isPassVisible ? 'Ocultar senha' : 'Ver senha cadastrada'}
                          >
                            {isPassVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </td>

                      {/* Active Status */}
                      <td className="py-3.5 px-4 text-center">
                        <button
                          type="button"
                          onClick={() => handleQuickToggleActive(u)}
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold transition-all cursor-pointer border ${
                            u.active
                              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/30'
                              : 'bg-red-500/20 text-red-400 border-red-500/40 hover:bg-red-500/30'
                          }`}
                          title="Clique para alternar entre Ativo e Inativo"
                        >
                          {u.active ? 'Ativo' : 'Inativo'}
                        </button>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => openEditModal(u)}
                            className="p-2 bg-[#181818] hover:bg-[#252525] border border-[#333] hover:border-[#D4AF37] text-white hover:text-[#F2D675] rounded-xl transition-colors cursor-pointer"
                            title="Editar colaborador, mudar cargo ou redefinir senha"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => setUserToDelete(u)}
                            className="p-2 bg-[#181818] hover:bg-red-950/40 border border-[#333] hover:border-red-500/50 text-[#888] hover:text-red-400 rounded-xl transition-colors cursor-pointer"
                            title="Remover colaborador da equipe"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================== */}
      {/* MODAL: ADICIONAR / EDITAR COLABORADOR                     */}
      {/* ========================================================== */}
      {isAddEditModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#111111] border border-[#2B2B2B] rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl p-6 sm:p-8 space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-[#222]">
              <div>
                <span className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-wider block">
                  {editingUser ? 'Atualizar Colaborador' : 'Novo Colaborador'}
                </span>
                <h3 className="text-white font-serif-luxury font-black text-lg uppercase tracking-wide">
                  {editingUser ? `Editar: ${editingUser.name}` : 'Cadastrar Membro da Equipe'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddEditModalOpen(false)}
                className="p-2 text-[#777] hover:text-white rounded-xl hover:bg-[#222]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Nome Completo do Colaborador *
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="Ex: João da Silva"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  E-mail de Acesso (Login) *
                </label>
                <input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="joao@mercadinhoalianca.com.br"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Role Switcher */}
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Cargo / Função (Role) *
                  </label>
                  <select
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value as StaffRole)}
                    className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-[#F2D675] font-bold outline-none cursor-pointer"
                  >
                    <option value="ADMIN">ADMIN (Acesso Total)</option>
                    <option value="GERENTE">GERENTE</option>
                    <option value="ESTOQUE">ESTOQUE</option>
                    <option value="CAIXA">CAIXA</option>
                    <option value="ENTREGA">ENTREGA</option>
                    <option value="ATENDIMENTO">ATENDIMENTO</option>
                  </select>
                </div>

                {/* Phone */}
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Telefone / WhatsApp
                  </label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="(74) 99999-0000"
                    className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-mono"
                  />
                </div>
              </div>

              {/* Password Defined by Admin */}
              <div className="p-4 bg-[#141414] border border-[#2B2B2B] rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-white uppercase flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-[#D4AF37]" />
                    Senha de Acesso Definida pelo Administrador *
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[11px] text-[#888] hover:text-[#D4AF37] flex items-center gap-1"
                  >
                    {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    {showPassword ? 'Ocultar' : 'Exibir'}
                  </button>
                </div>

                <input
                  type={showPassword ? 'text' : 'password'}
                  value={formPassword}
                  onChange={(e) => setFormPassword(e.target.value)}
                  placeholder="Defina uma senha para o colaborador (ex: caixa2026)"
                  className="w-full bg-[#1A1A1A] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono font-bold outline-none"
                  required
                />
                <p className="text-[11px] text-[#777]">
                  Você tem o controle: informe esta senha ao seu colaborador para que ele possa se conectar ao sistema.
                </p>
              </div>

              {/* Active Toggle */}
              <div className="flex items-center justify-between pt-2">
                <div>
                  <span className="font-bold text-white block">Status da Conta</span>
                  <span className="text-[11px] text-[#777]">
                    Colaboradores desativados não conseguem acessar o sistema.
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formActive}
                    onChange={(e) => setFormActive(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-[#333333] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                </label>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#222]">
                <button
                  type="button"
                  onClick={() => setIsAddEditModalOpen(false)}
                  className="px-4 py-2.5 text-xs text-[#888] hover:text-white rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg disabled:opacity-50"
                >
                  {isSubmitting ? 'Salvando...' : editingUser ? 'Salvar Alterações' : 'Criar Colaborador'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================== */}
      {/* MODAL: ALTERAR SENHA MESTRE DO ADMINISTRADOR (12345)       */}
      {/* ========================================================== */}
      {isMasterModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#111111] border border-[#D4AF37]/50 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl p-6 sm:p-8 space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-[#222]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37] flex items-center justify-center text-[#D4AF37]">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-white font-serif-luxury font-black text-lg uppercase tracking-wide">
                    Alterar Senha Mestre
                  </h3>
                  <span className="text-[10px] text-[#A0A0A0]">
                    Senha principal de controle e desbloqueio do painel
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsMasterModalOpen(false)}
                className="p-2 text-[#777] hover:text-white rounded-xl hover:bg-[#222]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleChangeMasterPassword} className="space-y-4 text-xs">
              <div className="p-3 bg-[#181818] border border-[#2B2B2B] rounded-xl text-[11px] text-[#AAAAAA]">
                <strong>Nota:</strong> A senha mestre inicial padrão é <code className="text-[#F2D675] font-mono font-bold">12345</code>. Digite-a no campo abaixo para validar e configurar sua nova senha.
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Senha Mestre Atual *
                </label>
                <input
                  type={showMasterPass ? 'text' : 'password'}
                  value={currentMasterPass}
                  onChange={(e) => setCurrentMasterPass(e.target.value)}
                  placeholder="Digite a senha atual (padrão: 12345)"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Nova Senha Mestre *
                </label>
                <input
                  type={showMasterPass ? 'text' : 'password'}
                  value={newMasterPass}
                  onChange={(e) => setNewMasterPass(e.target.value)}
                  placeholder="Digite a nova senha desejada"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Confirme a Nova Senha Mestre *
                </label>
                <input
                  type={showMasterPass ? 'text' : 'password'}
                  value={confirmMasterPass}
                  onChange={(e) => setConfirmMasterPass(e.target.value)}
                  placeholder="Repita a nova senha para confirmação"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                  required
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  onClick={() => setShowMasterPass(!showMasterPass)}
                  className="text-[11px] text-[#888] hover:text-white flex items-center gap-1"
                >
                  {showMasterPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  {showMasterPass ? 'Ocultar caracteres' : 'Visualizar caracteres'}
                </button>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#222]">
                <button
                  type="button"
                  onClick={() => setIsMasterModalOpen(false)}
                  className="px-4 py-2.5 text-xs text-[#888] hover:text-white rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={savingMaster}
                  className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg disabled:opacity-50"
                >
                  {savingMaster ? 'Gravando...' : 'Salvar Nova Senha'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================== */}
      {/* MODAL: CONFIRMAR EXCLUSÃO DE COLABORADOR                   */}
      {/* ========================================================== */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111111] border border-red-500/40 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-red-500/20 border border-red-500/50 flex items-center justify-center text-red-400 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-white font-bold text-base">Remover Colaborador?</h3>
              <p className="text-xs text-[#888888] mt-1">
                Tem certeza que deseja remover <strong>{userToDelete.name}</strong> da equipe do Mercadinho Aliança? Esta ação não pode ser desfeita.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="px-4 py-2.5 text-xs text-[#888] hover:text-white rounded-xl"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteUser}
                disabled={deleting}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg disabled:opacity-50"
              >
                {deleting ? 'Removendo...' : 'Sim, Remover'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
