import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Bot,
  User,
  AlertTriangle,
  Loader2,
  TrendingDown,
  Tag,
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  actionTaken?: string;
  data?: any;
}

export const AdminAiManager: React.FC = () => {
  const { showToast } = useApp();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm-init',
      role: 'assistant',
      text: 'Olá! Sou o **Aliança AI Manager**. Estou conectado diretamente ao banco de dados do Mercadinho Aliança através de ferramentas inteligentes (Function Calling). Posso analisar vendas, verificar itens com estoque baixo, consultar pedidos em andamento ou propor campanhas promocionais. O que você gostaria de analisar agora?'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = async (customPrompt?: string) => {
    const text = customPrompt || input;
    if (!text.trim() || loading) return;

    const userMsg: Message = { id: `u-${Date.now()}`, role: 'user', text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const history = messages.slice(-6).map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        text: m.text
      }));

      const res = await api.chatAi(text, 'admin', history);

      setMessages(prev => [
        ...prev,
        {
          id: `b-${Date.now()}`,
          role: 'assistant',
          text: res.reply || 'Operação realizada.',
          actionTaken: res.actionTaken,
          data: res.data
        }
      ]);
    } catch {
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          text: 'Falha na comunicação com o serviço Gemini. Verifique a chave de API no backend.'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    'Quais produtos estão com estoque baixo?',
    'Resumo de vendas e faturamento atual',
    'Crie um cupom de 10% para compras acima de R$ 100',
    'Sugira uma promoção para produtos de limpeza',
    'Quais pedidos estão com entrega pendente?'
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E1E1E]">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Inteligência Artificial & Function Calling
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-[#D4AF37]" />
            Aliança AI Manager
          </h1>
        </div>

        <div className="flex items-center gap-2 bg-[#0E0E0E] border border-[#D4AF37]/30 px-3 py-1.5 rounded-xl text-xs">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[#F2D675] font-bold">Gemini 3.8 Flash Conectado</span>
        </div>
      </div>

      {/* Main Chat Panel */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl overflow-hidden shadow-2xl flex flex-col h-[640px]">
        {/* Messages viewport */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'assistant' && (
                <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/50 text-[#D4AF37] flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#C9A227] text-black font-semibold rounded-tr-none'
                    : 'bg-[#121212] border border-[#222222] text-[#F0F0F0] rounded-tl-none shadow-md'
                }`}
              >
                <div className="whitespace-pre-line">{m.text}</div>

                {/* If function called returned low stock */}
                {m.actionTaken === 'get_low_stock' && m.data?.items && (
                  <div className="mt-3 p-3 bg-[#080808] border border-red-500/30 rounded-xl space-y-1">
                    <span className="text-[11px] font-bold text-red-400 block uppercase">
                      Itens Críticos Detectados via Function Calling:
                    </span>
                    {m.data.items.map((i: any) => (
                      <div key={i.id} className="flex justify-between text-xs text-[#CCC]">
                        <span>• {i.name}</span>
                        <strong className="text-red-400 font-mono">{i.stock} un restante(s)</strong>
                      </div>
                    ))}
                  </div>
                )}

                {/* If function called returned sales report */}
                {m.actionTaken === 'get_sales_report' && m.data && (
                  <div className="mt-3 p-3 bg-[#080808] border border-[#D4AF37]/30 rounded-xl space-y-1 font-mono text-xs">
                    <span className="text-[11px] font-bold text-[#D4AF37] block uppercase font-sans">
                      Relatório Consolidado em Tempo Real:
                    </span>
                    <div>Faturamento Bruto: <strong>R$ {m.data.totalRevenue?.toFixed(2)}</strong></div>
                    <div>Ticket Médio: <strong>R$ {m.data.ticketMedio?.toFixed(2)}</strong></div>
                    <div>Total de Pedidos: <strong>{m.data.totalOrders}</strong></div>
                  </div>
                )}
              </div>

              {m.role === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-[#D4AF37] text-black flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-4 h-4 font-bold" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-[#888888] pl-3">
              <Loader2 className="w-4 h-4 animate-spin text-[#D4AF37]" />
              <span>Aliança AI Manager está consultando ferramentas do sistema...</span>
            </div>
          )}

          <div ref={endRef} />
        </div>

        {/* Prompt Suggestions */}
        <div className="p-3 bg-[#0D0D0D] border-t border-[#1C1C1C] flex gap-2 overflow-x-auto no-scrollbar">
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="shrink-0 text-[11px] bg-[#141414] hover:bg-[#202020] border border-[#262626] text-[#BDBDBD] hover:text-white px-3 py-1.5 rounded-full transition-colors cursor-pointer"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-4 bg-[#080808] border-t border-[#1A1A1A] flex gap-3"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Pergunte sobre estoque, vendas, cupons ou peça uma análise estratégica..."
            className="flex-1 bg-[#121212] border border-[#2B2B2B] focus:border-[#D4AF37] text-xs text-white rounded-xl px-4 py-3 outline-none"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="px-5 py-3 bg-[#D4AF37] hover:bg-[#F2D675] disabled:opacity-50 text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            Enviar
          </button>
        </form>
      </div>
    </div>
  );
};
