import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  QrCode,
  ShieldCheck,
  AlertCircle,
  CheckCircle,
  RefreshCw,
  Key,
  Plus,
  Trash2,
  Edit2,
  Building,
  Banknote,
  Calendar,
  ToggleLeft,
  ToggleRight,
  Info,
  DollarSign,
  Save,
  Check,
  X
} from 'lucide-react';
import { PaymentMethodConfig, BankAccount } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';

export const AdminPayments: React.FC = () => {
  const { settings, refreshSettings, showToast } = useApp();
  const [activeSubTab, setActiveSubTab] = useState<'methods' | 'banks' | 'gateways'>('methods');
  const [providers, setProviders] = useState<any[]>([]);
  const [demoMode, setDemoMode] = useState<boolean>(settings?.demoMode ?? true);

  // Payment methods list state
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethodConfig[]>([]);

  // Bank accounts list state
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);

  // Terms and conditions
  const [creditTerms, setCreditTerms] = useState(
    settings?.creditTermsText || 'Sujeito a aprovação cadastral e análise de limite financeiro pelo Mercadinho Aliança.'
  );
  const [cashTerms, setCashTerms] = useState(
    settings?.cashTermsText || 'Pagamento em espécie no ato da entrega, sujeito a conferência de troco e validação prévia.'
  );

  // Gateways manual keys
  const [mpToken, setMpToken] = useState(settings?.mercadoPagoAccessToken || '');
  const [stripeKey, setStripeKey] = useState(settings?.stripeSecretKey || '');
  const [savingSettings, setSavingSettings] = useState(false);

  // Method Modal state (add / edit)
  const [isMethodModalOpen, setIsMethodModalOpen] = useState(false);
  const [editingMethod, setEditingMethod] = useState<PaymentMethodConfig | null>(null);
  const [methodName, setMethodName] = useState('');
  const [methodCategory, setMethodCategory] = useState<PaymentMethodConfig['category']>('CUSTOM');
  const [methodDesc, setMethodDesc] = useState('');
  const [methodBadge, setMethodBadge] = useState('');
  const [methodInstructions, setMethodInstructions] = useState('');
  const [methodRequiresApproval, setMethodRequiresApproval] = useState(false);
  const [methodDiscount, setMethodDiscount] = useState<number>(0);
  const [methodActive, setMethodActive] = useState(true);

  // Bank Modal state (add / edit)
  const [isBankModalOpen, setIsBankModalOpen] = useState(false);
  const [editingBank, setEditingBank] = useState<BankAccount | null>(null);
  const [bankName, setBankName] = useState('');
  const [bankAgency, setBankAgency] = useState('');
  const [bankAccountNum, setBankAccountNum] = useState('');
  const [bankAccountType, setBankAccountType] = useState<'CORRENTE' | 'POUPANCA'>('CORRENTE');
  const [bankHolder, setBankHolder] = useState('Mercadinho Aliança LTDA');
  const [bankDocument, setBankDocument] = useState(settings?.cnpj || '12.345.678/0001-90');
  const [bankPixKey, setBankPixKey] = useState('');
  const [bankActive, setBankActive] = useState(true);

  useEffect(() => {
    const loadProviders = async () => {
      try {
        const data = await api.getPaymentProviders();
        setProviders(data);
      } catch (err) {
        console.error(err);
      }
    };
    loadProviders();
  }, []);

  useEffect(() => {
    if (settings) {
      setDemoMode(settings.demoMode ?? true);
      setMpToken(settings.mercadoPagoAccessToken || '');
      setStripeKey(settings.stripeSecretKey || '');
      setCreditTerms(
        settings.creditTermsText ||
          'Sujeito a aprovação cadastral e análise de limite financeiro pelo Mercadinho Aliança.'
      );
      setCashTerms(
        settings.cashTermsText ||
          'Pagamento em espécie no ato da entrega, sujeito a conferência de troco e validação prévia.'
      );

      if (settings.paymentMethods && settings.paymentMethods.length > 0) {
        setPaymentMethods(settings.paymentMethods);
      } else {
        // Fallback default methods
        setPaymentMethods([
          {
            id: 'pix',
            name: 'PIX Dinâmico e Chave Oficial',
            category: 'PIX',
            active: true,
            badgeText: 'Instantâneo',
            description: 'Pagamento instantâneo via QR Code ou Copia e Cola com baixa automática.',
            instructions: 'Escaneie o QR Code ou utilize o código Copia e Cola em seu app bancário favorito.'
          },
          {
            id: 'a_prazo',
            name: 'A Prazo (Sujeito a Aprovação)',
            category: 'A_PRAZO',
            active: true,
            requiresApproval: true,
            badgeText: 'Sujeito a Aprovação',
            description: 'Crediário Aliança / Carnê da casa para clientes cadastrados com limite pré-aprovado.',
            instructions: '⚠️ Pedido sujeito a análise cadastral e aprovação de crédito pela administração do Mercadinho Aliança.'
          },
          {
            id: 'cash_delivery',
            name: 'Em Dinheiro no Ato da Entrega (Sujeito a Aprovação)',
            category: 'CASH',
            active: true,
            requiresApproval: true,
            badgeText: 'Sujeito a Aprovação',
            description: 'Pagamento em notas/moedas na entrega das compras com troco conferido pelo motoboy.',
            instructions: '⚠️ Sujeito a aprovação e conferência. Por favor informe o valor para troco.'
          },
          {
            id: 'bank_transfer',
            name: 'Outros Bancos (Transferência / TED / DOC / Pix)',
            category: 'BANK_TRANSFER',
            active: true,
            badgeText: 'Contas Bancárias',
            description: 'Transferência direta para nossas contas no Banco do Brasil, Bradesco, Caixa, Itaú ou Nubank.',
            instructions: 'Transfira o valor para uma de nossas contas bancárias e envie o comprovante pelo WhatsApp.'
          },
          {
            id: 'delivery_card',
            name: 'Cartão na Maquininha (Entrega)',
            category: 'DELIVERY_CARD',
            active: true,
            badgeText: 'Maquininha Móvel',
            description: 'Pague no ato da entrega em cartão de crédito, débito ou voucher na maquininha sem fio.',
            instructions: 'O entregador levará a máquina sem fio até o seu endereço.'
          },
          {
            id: 'credit_card_online',
            name: 'Cartão de Crédito Online',
            category: 'CREDIT_CARD_ONLINE',
            active: true,
            badgeText: 'Pagamento Digital',
            description: 'Pague online em ambiente 100% seguro via gateway integrado Mercado Pago ou Stripe.',
            instructions: 'Seus dados são criptografados com certificado de alta segurança.'
          }
        ]);
      }

      if (settings.bankAccounts && settings.bankAccounts.length > 0) {
        setBankAccounts(settings.bankAccounts);
      } else {
        setBankAccounts([
          {
            id: 'bank-bb',
            bankName: 'Banco do Brasil (001)',
            agency: '1234-5',
            account: '98765-4',
            accountType: 'CORRENTE',
            holderName: 'Mercadinho Aliança LTDA',
            document: '12.345.678/0001-90',
            pixKey: '12.345.678/0001-90',
            active: true
          },
          {
            id: 'bank-bradesco',
            bankName: 'Bradesco (237)',
            agency: '0456',
            account: '12345-6',
            accountType: 'CORRENTE',
            holderName: 'Mercadinho Aliança LTDA',
            document: '12.345.678/0001-90',
            pixKey: 'contato@mercadinhoalianca.com.br',
            active: true
          },
          {
            id: 'bank-caixa',
            bankName: 'Caixa Econômica Federal (104)',
            agency: '0890',
            account: '003.00054321-0',
            accountType: 'CORRENTE',
            holderName: 'Mercadinho Aliança LTDA',
            document: '12.345.678/0001-90',
            pixKey: '74999598143',
            active: true
          },
          {
            id: 'bank-nubank',
            bankName: 'Nubank (260)',
            agency: '0001',
            account: '8765432-1',
            accountType: 'CORRENTE',
            holderName: 'Mercadinho Aliança LTDA',
            document: '12.345.678/0001-90',
            pixKey: '74998008283',
            active: true
          }
        ]);
      }
    }
  }, [settings]);

  // Save current lists to backend
  const saveAllToBackend = async (
    updatedMethods = paymentMethods,
    updatedBanks = bankAccounts,
    updatedCreditTerms = creditTerms,
    updatedCashTerms = cashTerms
  ) => {
    setSavingSettings(true);
    try {
      await api.updateSettings({
        paymentMethods: updatedMethods,
        bankAccounts: updatedBanks,
        creditTermsText: updatedCreditTerms,
        cashTermsText: updatedCashTerms,
        mercadoPagoAccessToken: mpToken,
        stripeSecretKey: stripeKey,
        mercadoPagoConnected: Boolean(mpToken),
        stripeConnected: Boolean(stripeKey),
        demoMode
      });
      await refreshSettings();
      showToast('Configurações Salvas', 'Formas de pagamento e contas atualizadas no servidor.', 'success');
    } catch {
      showToast('Erro', 'Falha ao salvar configurações de pagamento.', 'error');
    } finally {
      setSavingSettings(false);
    }
  };

  // Toggle demo mode
  const handleToggleDemoMode = async (val: boolean) => {
    setDemoMode(val);
    try {
      await api.updateSettings({ demoMode: val });
      await refreshSettings();
      showToast('Modo Alterado', `Operação alterada para ${val ? 'DEMONSTRAÇÃO' : 'PRODUÇÃO'}.`, 'info');
    } catch {
      showToast('Erro', 'Falha ao salvar modo de operação.', 'error');
    }
  };

  // Toggle method active status
  const handleToggleMethodActive = async (methodId: string) => {
    const updated = paymentMethods.map(m => (m.id === methodId ? { ...m, active: !m.active } : m));
    setPaymentMethods(updated);
    await saveAllToBackend(updated, bankAccounts);
  };

  // Open Add Method Modal
  const handleOpenAddMethod = () => {
    setEditingMethod(null);
    setMethodName('');
    setMethodCategory('CUSTOM');
    setMethodDesc('');
    setMethodBadge('');
    setMethodInstructions('');
    setMethodRequiresApproval(false);
    setMethodDiscount(0);
    setMethodActive(true);
    setIsMethodModalOpen(true);
  };

  // Open Edit Method Modal
  const handleOpenEditMethod = (method: PaymentMethodConfig) => {
    setEditingMethod(method);
    setMethodName(method.name);
    setMethodCategory(method.category);
    setMethodDesc(method.description || '');
    setMethodBadge(method.badgeText || '');
    setMethodInstructions(method.instructions || '');
    setMethodRequiresApproval(Boolean(method.requiresApproval));
    setMethodDiscount(method.discountPercent || 0);
    setMethodActive(method.active);
    setIsMethodModalOpen(true);
  };

  // Save Method (Add / Edit)
  const handleSaveMethodModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!methodName.trim()) {
      showToast('Campo Obrigatório', 'Informe o nome da forma de pagamento.', 'error');
      return;
    }

    let updated: PaymentMethodConfig[];
    if (editingMethod) {
      updated = paymentMethods.map(m =>
        m.id === editingMethod.id
          ? {
              ...m,
              name: methodName.trim(),
              category: methodCategory,
              description: methodDesc.trim(),
              badgeText: methodBadge.trim() || undefined,
              instructions: methodInstructions.trim() || undefined,
              requiresApproval: methodRequiresApproval,
              discountPercent: Number(methodDiscount) || undefined,
              active: methodActive
            }
          : m
      );
    } else {
      const newMethod: PaymentMethodConfig = {
        id: `method-${Date.now()}`,
        name: methodName.trim(),
        category: methodCategory,
        description: methodDesc.trim(),
        badgeText: methodBadge.trim() || undefined,
        instructions: methodInstructions.trim() || undefined,
        requiresApproval: methodRequiresApproval,
        discountPercent: Number(methodDiscount) || undefined,
        active: methodActive
      };
      updated = [...paymentMethods, newMethod];
    }

    setPaymentMethods(updated);
    setIsMethodModalOpen(false);
    await saveAllToBackend(updated, bankAccounts);
  };

  // Delete custom method
  const handleDeleteMethod = async (id: string, name: string) => {
    if (!confirm(`Deseja remover a forma de pagamento "${name}"?`)) return;
    const updated = paymentMethods.filter(m => m.id !== id);
    setPaymentMethods(updated);
    await saveAllToBackend(updated, bankAccounts);
    showToast('Removido', `Forma de pagamento "${name}" removida.`, 'info');
  };

  // Toggle bank active
  const handleToggleBankActive = async (bankId: string) => {
    const updated = bankAccounts.map(b => (b.id === bankId ? { ...b, active: !b.active } : b));
    setBankAccounts(updated);
    await saveAllToBackend(paymentMethods, updated);
  };

  // Open Add Bank Modal
  const handleOpenAddBank = () => {
    setEditingBank(null);
    setBankName('');
    setBankAgency('');
    setBankAccountNum('');
    setBankAccountType('CORRENTE');
    setBankHolder('Mercadinho Aliança LTDA');
    setBankDocument(settings?.cnpj || '12.345.678/0001-90');
    setBankPixKey('');
    setBankActive(true);
    setIsBankModalOpen(true);
  };

  // Open Edit Bank Modal
  const handleOpenEditBank = (bank: BankAccount) => {
    setEditingBank(bank);
    setBankName(bank.bankName);
    setBankAgency(bank.agency);
    setBankAccountNum(bank.account);
    setBankAccountType(bank.accountType);
    setBankHolder(bank.holderName);
    setBankDocument(bank.document);
    setBankPixKey(bank.pixKey || '');
    setBankActive(bank.active);
    setIsBankModalOpen(true);
  };

  // Save Bank Account
  const handleSaveBankModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bankName.trim() || !bankAgency.trim() || !bankAccountNum.trim()) {
      showToast('Campos Obrigatórios', 'Preencha o banco, agência e conta.', 'error');
      return;
    }

    let updated: BankAccount[];
    if (editingBank) {
      updated = bankAccounts.map(b =>
        b.id === editingBank.id
          ? {
              ...b,
              bankName: bankName.trim(),
              agency: bankAgency.trim(),
              account: bankAccountNum.trim(),
              accountType: bankAccountType,
              holderName: bankHolder.trim(),
              document: bankDocument.trim(),
              pixKey: bankPixKey.trim() || undefined,
              active: bankActive
            }
          : b
      );
    } else {
      const newBank: BankAccount = {
        id: `bank-${Date.now()}`,
        bankName: bankName.trim(),
        agency: bankAgency.trim(),
        account: bankAccountNum.trim(),
        accountType: bankAccountType,
        holderName: bankHolder.trim(),
        document: bankDocument.trim(),
        pixKey: bankPixKey.trim() || undefined,
        active: bankActive
      };
      updated = [...bankAccounts, newBank];
    }

    setBankAccounts(updated);
    setIsBankModalOpen(false);
    await saveAllToBackend(paymentMethods, updated);
  };

  // Delete Bank Account
  const handleDeleteBank = async (id: string, name: string) => {
    if (!confirm(`Deseja remover a conta do "${name}"?`)) return;
    const updated = bankAccounts.filter(b => b.id !== id);
    setBankAccounts(updated);
    await saveAllToBackend(paymentMethods, updated);
    showToast('Removido', `Conta do "${name}" removida.`, 'info');
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E1E1E]">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Gestão Financeira & Meios de Pagamento
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Formas de Pagamento, Bancos & Gateways
          </h1>
          <p className="text-xs text-[#888888] mt-1">
            Configure opções de pagamento: PIX, A Prazo, Dinheiro na Entrega, Outros Bancos e Cartões.
          </p>
        </div>

        {/* Mode Switcher */}
        <div className="flex items-center gap-2 bg-[#0E0E0E] border border-[#2B2B2B] p-1.5 rounded-2xl">
          <button
            onClick={() => handleToggleDemoMode(true)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              demoMode ? 'bg-[#D4AF37] text-black font-black' : 'text-[#777] hover:text-white'
            }`}
          >
            Modo Simulado
          </button>
          <button
            onClick={() => handleToggleDemoMode(false)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              !demoMode ? 'bg-emerald-500 text-black font-black' : 'text-[#777] hover:text-white'
            }`}
          >
            Modo Produção
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-[#1C1C1C] pb-2">
        <button
          onClick={() => setActiveSubTab('methods')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'methods'
              ? 'bg-[#D4AF37] text-black font-black shadow-lg shadow-[#D4AF37]/15'
              : 'bg-[#121212] text-[#888] hover:text-white hover:bg-[#1A1A1A]'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Formas de Pagamento ({paymentMethods.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('banks')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'banks'
              ? 'bg-[#D4AF37] text-black font-black shadow-lg shadow-[#D4AF37]/15'
              : 'bg-[#121212] text-[#888] hover:text-white hover:bg-[#1A1A1A]'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Outros Bancos & Contas ({bankAccounts.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('gateways')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'gateways'
              ? 'bg-[#D4AF37] text-black font-black shadow-lg shadow-[#D4AF37]/15'
              : 'bg-[#121212] text-[#888] hover:text-white hover:bg-[#1A1A1A]'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>Gateways Online (Mercado Pago / Stripe)</span>
        </button>
      </div>

      {/* SUB-TAB 1: FORMAS DE PAGAMENTO */}
      {activeSubTab === 'methods' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-white font-bold text-base">Meios de Pagamento Disponíveis no Checkout</h3>
              <p className="text-xs text-[#777]">
                Ative ou pause qualquer forma de pagamento e defina avisos de "Sujeito a Aprovação" ou descontos.
              </p>
            </div>

            <button
              onClick={handleOpenAddMethod}
              className="px-4 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-[#D4AF37]/15"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Forma de Pagamento</span>
            </button>
          </div>

          {/* Special highlights banner */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-[#111111] border border-[#D4AF37]/30 rounded-2xl flex items-start gap-3">
              <Calendar className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
              <div className="space-y-1 text-xs">
                <strong className="text-white font-bold">A Prazo (Sujeito a Aprovação)</strong>
                <p className="text-[#888] leading-relaxed">
                  Permite aos clientes fiéis comprarem no crediário ou carnê. O pedido entra com status pendente de aprovação financeira antes da expedição.
                </p>
              </div>
            </div>

            <div className="p-4 bg-[#111111] border border-emerald-500/30 rounded-2xl flex items-start gap-3">
              <Banknote className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div className="space-y-1 text-xs">
                <strong className="text-white font-bold">Dinheiro no Ato da Entrega (Sujeito a Aprovação)</strong>
                <p className="text-[#888] leading-relaxed">
                  Solicita o valor do troco no checkout e valida a compra com o cliente antes do envio com o entregador.
                </p>
              </div>
            </div>
          </div>

          {/* Methods Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {paymentMethods.map((m) => (
              <div
                key={m.id}
                className={`p-5 rounded-3xl border transition-all flex flex-col justify-between ${
                  m.active
                    ? 'bg-[#0E0E0E] border-[#222222] hover:border-[#D4AF37]/50 shadow-xl'
                    : 'bg-[#0A0A0A] border-[#181818] opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h4 className="font-bold text-white text-sm leading-snug">{m.name}</h4>
                    {m.badgeText && (
                      <span
                        className={`text-[9px] font-black px-2 py-0.5 rounded-full shrink-0 uppercase ${
                          m.requiresApproval
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-[#D4AF37]/20 text-[#F2D675] border border-[#D4AF37]/40'
                        }`}
                      >
                        {m.badgeText}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-[#888888] leading-relaxed mb-3">{m.description}</p>

                  {m.instructions && (
                    <div className="p-2.5 bg-[#141414] border border-[#242424] rounded-xl text-[11px] text-[#AAAAAA] mb-3">
                      <strong className="text-white block mb-0.5">Instrução ao Cliente:</strong>
                      {m.instructions}
                    </div>
                  )}

                  {m.discountPercent ? (
                    <span className="text-[10px] text-emerald-400 font-bold block mb-2">
                      🏷️ Desconto de {m.discountPercent}% nesta opção
                    </span>
                  ) : null}
                </div>

                {/* Card footer */}
                <div className="pt-3 border-t border-[#1C1C1C] flex items-center justify-between gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => handleToggleMethodActive(m.id)}
                    className={`text-[11px] font-bold px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                      m.active
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                    }`}
                  >
                    {m.active ? 'Ativa no Site' : 'Pausada'}
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleOpenEditMethod(m)}
                      className="p-1.5 bg-[#161616] hover:bg-[#252525] text-[#AAAAAA] hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="Editar"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    {m.id.startsWith('method-') && (
                      <button
                        type="button"
                        onClick={() => handleDeleteMethod(m.id, m.name)}
                        className="p-1.5 bg-[#161616] hover:bg-red-950/40 text-[#AAAAAA] hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                        title="Remover"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Terms & Conditions text fields */}
          <div className="p-6 bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl space-y-4">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider flex items-center gap-2">
              <Info className="w-4 h-4 text-[#D4AF37]" /> Termos e Políticas Exibidas no Checkout
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Termo para Pagamentos "A Prazo"
                </label>
                <textarea
                  value={creditTerms}
                  onChange={(e) => setCreditTerms(e.target.value)}
                  rows={3}
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white outline-none leading-relaxed"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Termo para Pagamentos "Em Dinheiro no Ato da Entrega"
                </label>
                <textarea
                  value={cashTerms}
                  onChange={(e) => setCashTerms(e.target.value)}
                  rows={3}
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white outline-none leading-relaxed"
                />
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => saveAllToBackend(paymentMethods, bankAccounts, creditTerms, cashTerms)}
                disabled={savingSettings}
                className="px-5 py-2.5 bg-[#1A1A1A] hover:bg-[#252525] border border-[#D4AF37]/50 text-[#F2D675] font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer transition-colors"
              >
                <Save className="w-4 h-4 text-[#D4AF37]" />
                {savingSettings ? 'Salvando...' : 'Salvar Termos de Pagamento'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: OUTROS BANCOS & CONTAS */}
      {activeSubTab === 'banks' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-white font-bold text-base">Contas Bancárias Oficiais para Transferência e TED</h3>
              <p className="text-xs text-[#777]">
                Cadastre as contas dos bancos (Banco do Brasil, Bradesco, Caixa, Itaú, Nubank, etc.) exibidas ao cliente no checkout.
              </p>
            </div>

            <button
              onClick={handleOpenAddBank}
              className="px-4 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-[#D4AF37]/15"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Banco</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {bankAccounts.map((b) => (
              <div
                key={b.id}
                className={`p-6 rounded-3xl border transition-all flex flex-col justify-between ${
                  b.active
                    ? 'bg-[#0E0E0E] border-[#222222] hover:border-[#D4AF37]/50 shadow-xl'
                    : 'bg-[#0A0A0A] border-[#181818] opacity-60'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-[#1A1A1A]">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-[#D4AF37]/15 text-[#D4AF37] flex items-center justify-center font-bold text-xs">
                        <Building className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-base">{b.bankName}</h4>
                        <span className="text-[11px] text-[#888]">Conta {b.accountType}</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleBankActive(b.id)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full cursor-pointer ${
                        b.active
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                      }`}
                    >
                      {b.active ? 'Ativa' : 'Pausada'}
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs bg-[#141414] p-3.5 rounded-2xl border border-[#222]">
                    <div>
                      <span className="text-[10px] text-[#777] uppercase font-bold block">Agência:</span>
                      <strong className="text-white font-mono text-sm">{b.agency}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#777] uppercase font-bold block">Conta:</span>
                      <strong className="text-white font-mono text-sm">{b.account}</strong>
                    </div>
                    <div className="col-span-2">
                      <span className="text-[10px] text-[#777] uppercase font-bold block">Titular:</span>
                      <strong className="text-white text-xs">{b.holderName}</strong>
                    </div>
                    {b.document && (
                      <div className="col-span-2">
                        <span className="text-[10px] text-[#777] uppercase font-bold block">CNPJ / CPF:</span>
                        <strong className="text-[#AAAAAA] font-mono text-xs">{b.document}</strong>
                      </div>
                    )}
                    {b.pixKey && (
                      <div className="col-span-2 pt-1 border-t border-[#222]">
                        <span className="text-[10px] text-[#D4AF37] uppercase font-bold block">Chave PIX Deste Banco:</span>
                        <code className="text-[#F2D675] font-mono text-xs block truncate">{b.pixKey}</code>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-[#1C1C1C] flex items-center justify-end gap-2 mt-4">
                  <button
                    type="button"
                    onClick={() => handleOpenEditBank(b)}
                    className="p-1.5 bg-[#161616] hover:bg-[#252525] text-[#AAAAAA] hover:text-white rounded-lg transition-colors cursor-pointer"
                    title="Editar banco"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteBank(b.id, b.bankName)}
                    className="p-1.5 bg-[#161616] hover:bg-red-950/40 text-[#AAAAAA] hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                    title="Remover banco"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: GATEWAYS ONLINE */}
      {activeSubTab === 'gateways' && (
        <div className="space-y-6">
          <div className="p-5 bg-[#0E0E0E] border border-[#2B2B2B] rounded-3xl flex items-start gap-4 shadow-xl">
            <div className="p-2.5 rounded-2xl bg-[#D4AF37]/15 text-[#D4AF37] shrink-0 mt-0.5">
              <Key className="w-5 h-5" />
            </div>
            <div className="space-y-1 text-xs">
              <h3 className="font-bold text-white text-sm">Arquitetura de Segurança Bancária</h3>
              <p className="text-[#888888] leading-relaxed">
                Tokens de API do Mercado Pago e Stripe são salvos de forma protegida para geração de PIX com QR code oficial e checkout de cartão seguro.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Mercado Pago */}
            <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#1A1A1A]">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
                    MP
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-sm">Mercado Pago Provider</h3>
                    <span className="text-[10px] text-[#777]">PIX Dinâmico, Cartão de Crédito e Débito</span>
                  </div>
                </div>

                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                    providers.find(p => p.name === 'Mercado Pago')?.configured
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  }`}
                >
                  {providers.find(p => p.name === 'Mercado Pago')?.configured ? 'Conectado' : 'Aguardando Credencial'}
                </span>
              </div>

              <div className="space-y-2 text-xs text-[#AAAAAA]">
                <div>• Webhook URL: <code className="text-[#D4AF37] font-mono text-[11px]">/api/payments/webhook?provider=Mercado+Pago</code></div>
                <div>• Status da Geração PIX: <strong className="text-emerald-400">Ativo (Payload BR Code + QR Code Oficial)</strong></div>
              </div>

              <div className="p-4 bg-[#141414] border border-[#2B2B2B] rounded-2xl space-y-2 text-xs">
                <label className="font-bold text-white uppercase block">
                  Inserir Access Token Manualmente:
                </label>
                <input
                  type="password"
                  value={mpToken}
                  onChange={(e) => setMpToken(e.target.value)}
                  placeholder="APP_USR-xxxxxxxxxxxxxxxxxxxx"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white font-mono text-xs outline-none"
                />
              </div>
            </div>

            {/* Stripe */}
            <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#1A1A1A]">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
                    ST
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-sm">Stripe Provider</h3>
                    <span className="text-[10px] text-[#777]">Cartões Nacionais e Internacionais</span>
                  </div>
                </div>

                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                    providers.find(p => p.name === 'Stripe')?.configured
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  }`}
                >
                  {providers.find(p => p.name === 'Stripe')?.configured ? 'Conectado' : 'Aguardando Credencial'}
                </span>
              </div>

              <div className="space-y-2 text-xs text-[#AAAAAA]">
                <div>• Webhook URL: <code className="text-[#D4AF37] font-mono text-[11px]">/api/payments/webhook?provider=Stripe</code></div>
                <div>• Suporte a Apple Pay & Google Pay: <strong className="text-white">Preparado</strong></div>
              </div>

              <div className="p-4 bg-[#141414] border border-[#2B2B2B] rounded-2xl space-y-2 text-xs">
                <label className="font-bold text-white uppercase block">
                  Inserir Secret Key Manualmente:
                </label>
                <input
                  type="password"
                  value={stripeKey}
                  onChange={(e) => setStripeKey(e.target.value)}
                  placeholder="sk_live_... ou sk_test_..."
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white font-mono text-xs outline-none"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={() => saveAllToBackend(paymentMethods, bankAccounts)}
              disabled={savingSettings}
              className="px-6 py-3 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 cursor-pointer transition-colors shadow-lg"
            >
              <Key className="w-4 h-4" />
              {savingSettings ? 'Salvando...' : 'Salvar Chaves Manuais de Pagamento'}
            </button>
          </div>
        </div>
      )}

      {/* Modal: Add / Edit Payment Method */}
      {isMethodModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0E0E0E] border border-[#282828] rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-[#222] pb-3">
              <h3 className="font-serif-luxury font-bold text-lg text-white">
                {editingMethod ? 'Editar Forma de Pagamento' : 'Nova Forma de Pagamento'}
              </h3>
              <button
                onClick={() => setIsMethodModalOpen(false)}
                className="text-[#777] hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMethodModal} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Nome da Forma de Pagamento *
                </label>
                <input
                  type="text"
                  value={methodName}
                  onChange={(e) => setMethodName(e.target.value)}
                  placeholder="Ex: Carnê Aliança 30 Dias (Sujeito a Aprovação)"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Categoria
                  </label>
                  <select
                    value={methodCategory}
                    onChange={(e) => setMethodCategory(e.target.value as any)}
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] text-white rounded-xl px-3 py-2.5 outline-none font-bold cursor-pointer"
                  >
                    <option value="A_PRAZO">A Prazo (Crediário)</option>
                    <option value="CASH">Dinheiro na Entrega</option>
                    <option value="BANK_TRANSFER">Outros Bancos / TED</option>
                    <option value="PIX">PIX</option>
                    <option value="DELIVERY_CARD">Cartão na Maquininha</option>
                    <option value="CREDIT_CARD_ONLINE">Cartão Online</option>
                    <option value="CUSTOM">Personalizada</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Texto do Selo / Badge
                  </label>
                  <input
                    type="text"
                    value={methodBadge}
                    onChange={(e) => setMethodBadge(e.target.value)}
                    placeholder="Ex: Sujeito a Aprovação"
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2.5 text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Descrição (Exibida no Card)
                </label>
                <textarea
                  value={methodDesc}
                  onChange={(e) => setMethodDesc(e.target.value)}
                  placeholder="Ex: Pague no vencimento com limite pré-aprovado pela gerência."
                  rows={2}
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white outline-none leading-relaxed"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Instruções Adicionais para o Cliente
                </label>
                <textarea
                  value={methodInstructions}
                  onChange={(e) => setMethodInstructions(e.target.value)}
                  placeholder="Ex: ⚠️ O pedido ficará sob análise de crédito e a loja entrará em contato via WhatsApp."
                  rows={2}
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white outline-none leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 items-center">
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Desconto Promocional (%)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    max="50"
                    value={methodDiscount}
                    onChange={(e) => setMethodDiscount(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white font-bold outline-none"
                  />
                </div>

                <div className="pt-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="requiresApprovalCheck"
                      checked={methodRequiresApproval}
                      onChange={(e) => setMethodRequiresApproval(e.target.checked)}
                      className="rounded accent-[#D4AF37] w-4 h-4 cursor-pointer"
                    />
                    <label htmlFor="requiresApprovalCheck" className="text-white font-bold cursor-pointer">
                      Sujeito a Aprovação
                    </label>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="methodActiveCheck"
                      checked={methodActive}
                      onChange={(e) => setMethodActive(e.target.checked)}
                      className="rounded accent-[#D4AF37] w-4 h-4 cursor-pointer"
                    />
                    <label htmlFor="methodActiveCheck" className="text-white font-bold cursor-pointer">
                      Ativa no Checkout
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#222]">
                <button
                  type="button"
                  onClick={() => setIsMethodModalOpen(false)}
                  className="px-4 py-2 text-[#888] hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black uppercase rounded-xl transition-all cursor-pointer shadow-lg"
                >
                  Salvar Opção
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add / Edit Bank Account */}
      {isBankModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0E0E0E] border border-[#282828] rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-[#222] pb-3">
              <h3 className="font-serif-luxury font-bold text-lg text-white">
                {editingBank ? 'Editar Conta Bancária' : 'Adicionar Nova Conta Bancária'}
              </h3>
              <button
                onClick={() => setIsBankModalOpen(false)}
                className="text-[#777] hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBankModal} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Nome do Banco *
                </label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="Ex: Banco do Brasil (001), Bradesco, Itaú, Nubank, Sicredi"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Agência *
                  </label>
                  <input
                    type="text"
                    value={bankAgency}
                    onChange={(e) => setBankAgency(e.target.value)}
                    placeholder="Ex: 1234-5"
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white font-mono outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Conta *
                  </label>
                  <input
                    type="text"
                    value={bankAccountNum}
                    onChange={(e) => setBankAccountNum(e.target.value)}
                    placeholder="Ex: 98765-4"
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white font-mono outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Tipo de Conta
                  </label>
                  <select
                    value={bankAccountType}
                    onChange={(e) => setBankAccountType(e.target.value as any)}
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] text-white rounded-xl px-2 py-2 outline-none font-bold"
                  >
                    <option value="CORRENTE">Corrente</option>
                    <option value="POUPANCA">Poupança</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Titular da Conta *
                </label>
                <input
                  type="text"
                  value={bankHolder}
                  onChange={(e) => setBankHolder(e.target.value)}
                  placeholder="Mercadinho Aliança LTDA"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    CNPJ / CPF
                  </label>
                  <input
                    type="text"
                    value={bankDocument}
                    onChange={(e) => setBankDocument(e.target.value)}
                    placeholder="12.345.678/0001-90"
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white font-mono outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Chave PIX Deste Banco
                  </label>
                  <input
                    type="text"
                    value={bankPixKey}
                    onChange={(e) => setBankPixKey(e.target.value)}
                    placeholder="Chave Pix para este banco"
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-white font-mono outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="bankActiveCheck"
                  checked={bankActive}
                  onChange={(e) => setBankActive(e.target.checked)}
                  className="rounded accent-[#D4AF37] w-4 h-4 cursor-pointer"
                />
                <label htmlFor="bankActiveCheck" className="text-white font-bold cursor-pointer">
                  Conta bancária ativa para visualização do cliente
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#222]">
                <button
                  type="button"
                  onClick={() => setIsBankModalOpen(false)}
                  className="px-4 py-2 text-[#888] hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black uppercase rounded-xl transition-all cursor-pointer shadow-lg"
                >
                  Salvar Banco
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
