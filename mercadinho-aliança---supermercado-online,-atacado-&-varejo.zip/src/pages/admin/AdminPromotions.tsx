import React, { useState, useEffect } from 'react';
import { Tag, Plus, Check, Trash2, Calendar, Percent } from 'lucide-react';
import { Coupon } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';

export const AdminPromotions: React.FC = () => {
  const { showToast } = useApp();
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [code, setCode] = useState('');
  const [type, setType] = useState<'PERCENTAGE' | 'FIXED'>('PERCENTAGE');
  const [value, setValue] = useState(10);
  const [minOrderValue, setMinOrderValue] = useState(80);
  const [isAdding, setIsAdding] = useState(false);

  const load = async () => {
    try {
      const data = await api.getCoupons();
      setCoupons(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !value) return;

    try {
      await api.saveCoupon({
        code: code.trim().toUpperCase(),
        type,
        value: Number(value),
        minOrderValue: Number(minOrderValue),
        maxUses: 500,
        usedCount: 0,
        startDate: new Date().toISOString().split('T')[0],
        endDate: '2026-12-31',
        active: true
      });
      showToast('Cupom Cadastrado', `Cupom ${code.toUpperCase()} ativado na loja!`, 'success');
      setCode('');
      setIsAdding(false);
      load();
    } catch {
      showToast('Erro', 'Não foi possível cadastrar o cupom.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E1E1E]">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Marketing & Descontos
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Cupons & Campanhas Promocionais
          </h1>
        </div>

        <button
          onClick={() => setIsAdding(true)}
          className="px-4 py-2 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Novo Cupom
        </button>
      </div>

      {/* New coupon form */}
      {isAdding && (
        <form onSubmit={handleCreateCoupon} className="p-5 bg-[#0E0E0E] border border-[#D4AF37]/40 rounded-3xl space-y-4 max-w-xl shadow-xl animate-in fade-in">
          <h3 className="text-white font-bold text-sm uppercase">Criar Novo Cupom</h3>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold text-[#AAA] uppercase block mb-1">Código do Cupom *</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Ex: OFERTA15"
                className="w-full bg-[#161616] border border-[#2B2B2B] rounded-xl px-3 py-2 text-xs text-white uppercase font-mono outline-none"
                required
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-[#AAA] uppercase block mb-1">Tipo de Desconto</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full bg-[#161616] border border-[#2B2B2B] rounded-xl px-3 py-2 text-xs text-white outline-none"
              >
                <option value="PERCENTAGE">Porcentagem (%)</option>
                <option value="FIXED">Valor Fixo (R$)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold text-[#AAA] uppercase block mb-1">
                Valor ({type === 'PERCENTAGE' ? '%' : 'R$'})
              </label>
              <input
                type="number"
                step="0.01"
                value={value}
                onChange={(e) => setValue(Number(e.target.value))}
                className="w-full bg-[#161616] border border-[#2B2B2B] rounded-xl px-3 py-2 text-xs text-white outline-none"
                required
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-[#AAA] uppercase block mb-1">
                Valor Mínimo do Pedido (R$)
              </label>
              <input
                type="number"
                step="0.01"
                value={minOrderValue}
                onChange={(e) => setMinOrderValue(Number(e.target.value))}
                className="w-full bg-[#161616] border border-[#2B2B2B] rounded-xl px-3 py-2 text-xs text-white outline-none"
              />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              className="px-5 py-2 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs uppercase rounded-xl"
            >
              Ativar Cupom
            </button>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 text-xs text-[#888] hover:text-white"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}

      {/* Coupons Table */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl overflow-hidden shadow-xl">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-[#121212] border-b border-[#1E1E1E] text-[#777] uppercase text-[10px]">
              <th className="py-3 px-4">Código</th>
              <th className="py-3 px-4">Desconto</th>
              <th className="py-3 px-4">Pedido Mínimo</th>
              <th className="py-3 px-4">Usos Realizados</th>
              <th className="py-3 px-4">Validade</th>
              <th className="py-3 px-4 text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#161616]">
            {coupons.map((c) => (
              <tr key={c.id} className="text-white hover:bg-[#141414]">
                <td className="py-3 px-4 font-mono font-bold text-[#D4AF37] flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5" /> {c.code}
                </td>
                <td className="py-3 px-4 font-bold">
                  {c.type === 'PERCENTAGE' ? `${c.value}% OFF` : `R$ ${c.value.toFixed(2)} OFF`}
                </td>
                <td className="py-3 px-4 text-[#AAA]">
                  R$ {c.minOrderValue.toFixed(2)}
                </td>
                <td className="py-3 px-4 text-[#888]">
                  {c.usedCount} de {c.maxUses}
                </td>
                <td className="py-3 px-4 text-[#777] font-mono">
                  Até {c.endDate}
                </td>
                <td className="py-3 px-4 text-right">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Ativo
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
