import React, { useState, useEffect } from 'react';
import {
  Truck,
  MapPin,
  Clock,
  Plus,
  Save,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  Store,
  DollarSign,
  Search,
  Sparkles,
  X
} from 'lucide-react';
import { DeliveryZone, StoreSettings } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';

export const AdminDelivery: React.FC = () => {
  const { settings, refreshSettings, showToast } = useApp();
  const [zones, setZones] = useState<DeliveryZone[]>([]);
  const [loading, setLoading] = useState(true);

  // Global delivery settings state
  const [deliveryActive, setDeliveryActive] = useState<boolean>(settings?.deliveryActive ?? true);
  const [pickupActive, setPickupActive] = useState<boolean>(settings?.pickupActive ?? true);
  const [freeShippingThreshold, setFreeShippingThreshold] = useState<number>(settings?.freeShippingThreshold ?? 180);
  const [defaultDeliveryFee, setDefaultDeliveryFee] = useState<number>(settings?.defaultDeliveryFee ?? 5);
  const [deliveryHours, setDeliveryHours] = useState<string>(
    settings?.deliveryHours ?? 'Segunda a Sábado: 07h às 21h | Domingos: 08h às 14h'
  );
  const [deliveryTimeEstimate, setDeliveryTimeEstimate] = useState<string>(
    settings?.deliveryTimeEstimate ?? '35 a 55 minutos'
  );
  const [savingGlobal, setSavingGlobal] = useState(false);

  // Add / Edit Zone modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingZone, setEditingZone] = useState<DeliveryZone | null>(null);
  const [zoneName, setZoneName] = useState('');
  const [zoneDistanceKm, setZoneDistanceKm] = useState<number>(5);
  const [zoneFee, setZoneFee] = useState<number>(5);
  const [zoneTimeMin, setZoneTimeMin] = useState<number>(40);
  const [zoneNeighborhoods, setZoneNeighborhoods] = useState('');
  const [zoneActive, setZoneActive] = useState(true);
  const [savingZone, setSavingZone] = useState(false);

  // Simulator state
  const [testNeighborhood, setTestNeighborhood] = useState('');
  const [simulatedZone, setSimulatedZone] = useState<DeliveryZone | null>(null);

  // Synchronize settings when context loads
  useEffect(() => {
    if (settings) {
      setDeliveryActive(settings.deliveryActive ?? true);
      setPickupActive(settings.pickupActive ?? true);
      setFreeShippingThreshold(settings.freeShippingThreshold ?? 180);
      setDefaultDeliveryFee(settings.defaultDeliveryFee ?? 5);
      setDeliveryHours(settings.deliveryHours ?? 'Segunda a Sábado: 07h às 21h | Domingos: 08h às 14h');
      setDeliveryTimeEstimate(settings.deliveryTimeEstimate ?? '35 a 55 minutos');
    }
  }, [settings]);

  const loadZones = async () => {
    try {
      setLoading(true);
      const data = await api.getDeliveryZones();
      setZones(data);
    } catch (err) {
      console.error(err);
      showToast('Erro', 'Não foi possível carregar as zonas de entrega.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadZones();
  }, []);

  const handleSaveGlobalSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingGlobal(true);
    try {
      await api.updateSettings({
        deliveryActive,
        pickupActive,
        freeShippingThreshold: Number(freeShippingThreshold),
        defaultDeliveryFee: Number(defaultDeliveryFee),
        deliveryHours,
        deliveryTimeEstimate
      });
      await refreshSettings();
      showToast('Configurações Salvas', 'Políticas e horários de entrega atualizados com sucesso.', 'success');
    } catch (err: any) {
      showToast('Erro', 'Falha ao salvar configurações de entrega.', 'error');
    } finally {
      setSavingGlobal(false);
    }
  };

  const handleOpenAddModal = () => {
    setEditingZone(null);
    setZoneName('');
    setZoneDistanceKm(5);
    setZoneFee(5);
    setZoneTimeMin(40);
    setZoneNeighborhoods('');
    setZoneActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (zone: DeliveryZone) => {
    setEditingZone(zone);
    setZoneName(zone.name);
    setZoneDistanceKm(zone.distanceKm);
    setZoneFee(zone.fee);
    setZoneTimeMin(zone.estimatedTimeMin);
    setZoneNeighborhoods(zone.neighborhoods?.join(', ') || '');
    setZoneActive(zone.active);
    setIsModalOpen(true);
  };

  const handleSaveZone = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!zoneName.trim()) {
      showToast('Campo Obrigatório', 'Informe o nome da zona de entrega.', 'error');
      return;
    }

    const parsedNeighborhoods = zoneNeighborhoods
      .split(',')
      .map(n => n.trim())
      .filter(Boolean);

    setSavingZone(true);
    try {
      const payload: Partial<DeliveryZone> = {
        id: editingZone ? editingZone.id : undefined,
        name: zoneName.trim(),
        distanceKm: Number(zoneDistanceKm),
        fee: Number(zoneFee),
        estimatedTimeMin: Number(zoneTimeMin),
        neighborhoods: parsedNeighborhoods,
        active: zoneActive
      };

      await api.saveDeliveryZone(payload);
      await loadZones();
      setIsModalOpen(false);
      showToast(
        'Zona Salva',
        editingZone ? 'Zona de entrega atualizada com sucesso.' : 'Nova zona de entrega criada com sucesso.',
        'success'
      );
    } catch (err: any) {
      showToast('Erro ao salvar', 'Não foi possível salvar a zona de entrega.', 'error');
    } finally {
      setSavingZone(false);
    }
  };

  const handleDeleteZone = async (id: string, name: string) => {
    if (!confirm(`Tem certeza que deseja excluir a zona "${name}"?`)) return;
    try {
      await api.deleteDeliveryZone(id);
      showToast('Zona Excluída', `Zona "${name}" foi removida.`, 'info');
      loadZones();
    } catch {
      showToast('Erro', 'Não foi possível remover a zona.', 'error');
    }
  };

  const handleToggleZoneActive = async (zone: DeliveryZone) => {
    try {
      await api.saveDeliveryZone({ ...zone, active: !zone.active });
      loadZones();
      showToast('Status Atualizado', `Zona ${zone.name} agora está ${!zone.active ? 'Ativa' : 'Inativa'}.`, 'info');
    } catch {
      showToast('Erro', 'Falha ao alterar status da zona.', 'error');
    }
  };

  const handleSimulate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testNeighborhood.trim()) return;
    const query = testNeighborhood.toLowerCase().trim();
    const found = zones.find(z =>
      z.active && z.neighborhoods.some(n => n.toLowerCase().includes(query))
    );
    setSimulatedZone(found || null);
  };

  return (
    <div className="space-y-8 max-w-6xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E1E1E]">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Logística & Expedição
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Zonas de Entrega, Fretes & Retirada
          </h1>
          <p className="text-xs text-[#888888] mt-1">
            Controle total sobre taxas por bairro, frete grátis, horários de entrega e retirada na loja.
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="px-4 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-[#D4AF37]/15"
        >
          <Plus className="w-4 h-4" />
          <span>Nova Zona / Bairro</span>
        </button>
      </div>

      {/* Global Delivery Settings Form */}
      <form onSubmit={handleSaveGlobalSettings} className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex items-center justify-between border-b border-[#1A1A1A] pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#D4AF37]/15 text-[#D4AF37]">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-bold text-base">Políticas Gerais de Entrega</h3>
              <p className="text-xs text-[#777777]">Configurações globais que afetam o checkout e os clientes</p>
            </div>
          </div>
          <button
            type="submit"
            disabled={savingGlobal}
            className="px-4 py-2 bg-[#1A1A1A] hover:bg-[#252525] border border-[#D4AF37]/40 hover:border-[#D4AF37] text-[#F2D675] text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition-colors"
          >
            <Save className="w-4 h-4 text-[#D4AF37]" />
            <span>{savingGlobal ? 'Salvando...' : 'Salvar Políticas'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Delivery Active Toggle */}
          <div className="p-4 bg-[#141414] border border-[#262626] rounded-2xl flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-[#888] uppercase font-bold block mb-1">Status do Delivery</span>
              <h4 className="text-white font-bold text-sm">Serviço de Entregas</h4>
              <p className="text-[11px] text-[#777] mt-1">Desative temporariamente em dias de chuva forte ou alta demanda.</p>
            </div>
            <button
              type="button"
              onClick={() => setDeliveryActive(!deliveryActive)}
              className={`mt-4 px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                deliveryActive
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-red-500/20 text-red-400 border border-red-500/40'
              }`}
            >
              {deliveryActive ? (
                <>
                  <ToggleRight className="w-4 h-4" /> Entregas Ativas
                </>
              ) : (
                <>
                  <ToggleLeft className="w-4 h-4" /> Entregas Pausadas
                </>
              )}
            </button>
          </div>

          {/* Pickup Active Toggle */}
          <div className="p-4 bg-[#141414] border border-[#262626] rounded-2xl flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-[#888] uppercase font-bold block mb-1">Retirada na Loja</span>
              <h4 className="text-white font-bold text-sm">Balcão / Drive-thru</h4>
              <p className="text-[11px] text-[#777] mt-1">Permite ao cliente fazer o pedido e buscar pessoalmente sem taxa.</p>
            </div>
            <button
              type="button"
              onClick={() => setPickupActive(!pickupActive)}
              className={`mt-4 px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                pickupActive
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-red-500/20 text-red-400 border border-red-500/40'
              }`}
            >
              {pickupActive ? (
                <>
                  <Store className="w-4 h-4" /> Retirada Ativa
                </>
              ) : (
                <>
                  <X className="w-4 h-4" /> Retirada Desativada
                </>
              )}
            </button>
          </div>

          {/* Free Shipping Threshold */}
          <div className="p-4 bg-[#141414] border border-[#262626] rounded-2xl">
            <span className="text-[10px] text-[#888] uppercase font-bold block mb-1">Frete Grátis a partir de</span>
            <div className="relative mt-2">
              <span className="absolute left-3 top-2.5 text-[#777] text-xs font-bold">R$</span>
              <input
                type="number"
                step="0.01"
                min="0"
                value={freeShippingThreshold}
                onChange={(e) => setFreeShippingThreshold(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] text-white rounded-xl pl-9 pr-3 py-2 text-sm font-bold outline-none"
              />
            </div>
            <p className="text-[10px] text-[#777] mt-2">Pedidos com valor igual ou superior ganham frete 100% gratuito.</p>
          </div>

          {/* Default Delivery Fee */}
          <div className="p-4 bg-[#141414] border border-[#262626] rounded-2xl">
            <span className="text-[10px] text-[#888] uppercase font-bold block mb-1">Taxa Base / Padrão</span>
            <div className="relative mt-2">
              <span className="absolute left-3 top-2.5 text-[#777] text-xs font-bold">R$</span>
              <input
                type="number"
                step="0.01"
                min="0"
                value={defaultDeliveryFee}
                onChange={(e) => setDefaultDeliveryFee(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] text-white rounded-xl pl-9 pr-3 py-2 text-sm font-bold outline-none"
              />
            </div>
            <p className="text-[10px] text-[#777] mt-2">Taxa padrão aplicada quando o bairro não está cadastrado em outra zona.</p>
          </div>
        </div>

        {/* Working Hours & Estimated Time */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#D4AF37]" /> Horários de Funcionamento do Delivery
            </label>
            <input
              type="text"
              value={deliveryHours}
              onChange={(e) => setDeliveryHours(e.target.value)}
              placeholder="Ex: Segunda a Sábado: 07h às 21h | Domingos: 08h às 14h"
              className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
            />
          </div>
          <div>
            <label className="text-xs font-bold text-[#AAAAAA] uppercase block mb-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" /> Previsão de Tempo Médio de Entrega
            </label>
            <input
              type="text"
              value={deliveryTimeEstimate}
              onChange={(e) => setDeliveryTimeEstimate(e.target.value)}
              placeholder="Ex: 35 a 55 minutos"
              className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
            />
          </div>
        </div>
      </form>

      {/* Zones List Card */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1A] pb-4">
          <div>
            <h3 className="text-white font-bold text-base flex items-center gap-2">
              <MapPin className="w-5 h-5 text-[#D4AF37]" />
              Zonas de Entrega & Bairros Cadastrados ({zones.length})
            </h3>
            <p className="text-xs text-[#777777]">Defina valores e tempos por distância e bairros atendidos</p>
          </div>

          <button
            onClick={handleOpenAddModal}
            className="px-4 py-2 bg-[#1A1A1A] hover:bg-[#252525] border border-[#D4AF37]/50 text-[#F2D675] text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4 text-[#D4AF37]" />
            <span>Adicionar Zona</span>
          </button>
        </div>

        {loading ? (
          <div className="py-12 text-center text-xs text-[#888]">Carregando zonas de entrega...</div>
        ) : zones.length === 0 ? (
          <div className="py-12 text-center space-y-2">
            <Truck className="w-8 h-8 text-[#555] mx-auto" />
            <p className="text-sm text-white font-bold">Nenhuma zona de entrega cadastrada</p>
            <p className="text-xs text-[#777]">Clique em "Adicionar Zona" para criar a primeira.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {zones.map((zone) => (
              <div
                key={zone.id}
                className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                  zone.active
                    ? 'bg-[#121212] border-[#252525] hover:border-[#D4AF37]/50'
                    : 'bg-[#0E0E0E] border-[#1C1C1C] opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <h4 className="font-bold text-white text-sm">{zone.name}</h4>
                      <span className="text-[11px] text-[#888]">
                        Raio até {zone.distanceKm} km • Previsão: {zone.estimatedTimeMin} min
                      </span>
                    </div>
                    <span className="font-serif-luxury font-black text-base text-[#F2D675] shrink-0">
                      R$ {zone.fee.toFixed(2)}
                    </span>
                  </div>

                  {/* Neighborhoods tags */}
                  <div className="space-y-1.5 my-3">
                    <span className="text-[10px] text-[#777] uppercase font-bold block">Bairros Atendidos:</span>
                    <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                      {zone.neighborhoods && zone.neighborhoods.length > 0 ? (
                        zone.neighborhoods.map((n, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 bg-[#1C1C1C] border border-[#2B2B2B] rounded-md text-[10px] text-[#DDD]"
                          >
                            {n}
                          </span>
                        ))
                      ) : (
                        <span className="text-[10px] text-[#666] italic">Nenhum bairro vinculado</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Footer Controls */}
                <div className="pt-4 border-t border-[#1C1C1C] flex items-center justify-between gap-2 mt-4">
                  <button
                    type="button"
                    onClick={() => handleToggleZoneActive(zone)}
                    className={`text-[11px] font-bold px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                      zone.active
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                    }`}
                  >
                    {zone.active ? 'Ativa' : 'Pausada'}
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleOpenEditModal(zone)}
                      className="p-1.5 bg-[#181818] hover:bg-[#252525] text-[#AAAAAA] hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="Editar zona"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteZone(zone.id, zone.name)}
                      className="p-1.5 bg-[#181818] hover:bg-red-950/40 text-[#AAAAAA] hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                      title="Excluir zona"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Simulator Test Tool */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-4 shadow-xl">
        <h3 className="text-white font-bold text-sm uppercase tracking-wider flex items-center gap-2">
          <Search className="w-4 h-4 text-[#D4AF37]" />
          Simulador de Consulta de Bairro (Teste do Cliente)
        </h3>
        <p className="text-xs text-[#777]">
          Digite o nome de um bairro para testar se a regra de frete e a zona estão correspondendo corretamente.
        </p>

        <form onSubmit={handleSimulate} className="flex gap-2 max-w-xl">
          <input
            type="text"
            value={testNeighborhood}
            onChange={(e) => setTestNeighborhood(e.target.value)}
            placeholder="Ex: Centro, Bela Vista, Parque das Flores..."
            className="flex-1 bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
          />
          <button
            type="submit"
            className="px-5 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs uppercase rounded-xl transition-all cursor-pointer"
          >
            Testar
          </button>
        </form>

        {simulatedZone && (
          <div className="p-4 bg-[#141414] border border-[#D4AF37]/40 rounded-2xl max-w-xl animate-in fade-in">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-white text-sm">{simulatedZone.name}</span>
                <p className="text-xs text-[#888] mt-0.5">
                  Previsão: {simulatedZone.estimatedTimeMin} min • Raio até {simulatedZone.distanceKm} km
                </p>
              </div>
              <span className="font-serif-luxury font-black text-lg text-[#F2D675]">
                R$ {simulatedZone.fee.toFixed(2)}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Add / Edit Zone Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0E0E0E] border border-[#282828] rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-[#222] pb-3">
              <h3 className="font-serif-luxury font-bold text-lg text-white">
                {editingZone ? 'Editar Zona de Entrega' : 'Nova Zona de Entrega'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-[#777] hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveZone} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Nome da Zona *
                </label>
                <input
                  type="text"
                  value={zoneName}
                  onChange={(e) => setZoneName(e.target.value)}
                  placeholder="Ex: Zona 1 - Centro e Bairros Vizinhos"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Taxa (R$) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={zoneFee}
                    onChange={(e) => setZoneFee(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2.5 text-white font-bold outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Raio (Km)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    min="1"
                    value={zoneDistanceKm}
                    onChange={(e) => setZoneDistanceKm(parseFloat(e.target.value) || 1)}
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2.5 text-white font-bold outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Tempo (Min)
                  </label>
                  <input
                    type="number"
                    min="5"
                    value={zoneTimeMin}
                    onChange={(e) => setZoneTimeMin(parseInt(e.target.value) || 30)}
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-2.5 text-white font-bold outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Bairros Atendidos (separados por vírgula)
                </label>
                <textarea
                  value={zoneNeighborhoods}
                  onChange={(e) => setZoneNeighborhoods(e.target.value)}
                  placeholder="Ex: Centro, Bela Vista, Jardim América, Planalto, Santo Antônio"
                  rows={3}
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none leading-relaxed"
                />
                <span className="text-[10px] text-[#777] mt-1 block">
                  Quando o cliente digitar qualquer um desses bairros no checkout, essa zona será selecionada.
                </span>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="zoneActiveCheck"
                  checked={zoneActive}
                  onChange={(e) => setZoneActive(e.target.checked)}
                  className="rounded accent-[#D4AF37] w-4 h-4 cursor-pointer"
                />
                <label htmlFor="zoneActiveCheck" className="text-white font-bold cursor-pointer">
                  Zona ativa para seleção imediata no checkout
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#222]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-[#888] hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={savingZone}
                  className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black uppercase rounded-xl transition-all cursor-pointer shadow-lg"
                >
                  {savingZone ? 'Salvando...' : 'Salvar Zona'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
