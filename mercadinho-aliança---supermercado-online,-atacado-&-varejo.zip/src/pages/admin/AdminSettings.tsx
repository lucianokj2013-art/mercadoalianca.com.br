import React, { useState, useEffect, useRef } from 'react';
import {
  Settings,
  Save,
  CheckCircle,
  Key,
  Phone,
  MapPin,
  Image as ImageIcon,
  ShieldCheck,
  Sparkles,
  CreditCard,
  Building,
  Upload,
  RefreshCw,
  ExternalLink,
  Check,
  AlertCircle,
  Clock,
  Layers,
  Truck
} from 'lucide-react';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';
import { StoreSettings } from '../../../shared/types.ts';
import { AdminFooter } from './AdminFooter.tsx';

export const AdminSettings: React.FC = () => {
  const { settings, refreshSettings, showToast } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeTab, setActiveTab] = useState<'identidade' | 'endereco' | 'telefones' | 'integracoes' | 'pagamentos' | 'regras' | 'rodape'>('identidade');

  const defaultFooterConfig = {
    atendimentoTitle: 'Atendimento',
    atendimentoLinks: [
      { id: 'at-1', label: 'Meus pedidos', action: 'orders', active: true },
      { id: 'at-2', label: 'Central de atendimento', action: 'sac', active: true },
      { id: 'at-3', label: 'Fale conosco', action: 'contact', active: true }
    ],
    institucionalTitle: 'Institucional',
    institucionalCol1Links: [
      { id: 'inst-1', label: 'Quem somos', action: 'about', active: true },
      { id: 'inst-2', label: 'Nossas lojas', action: 'stores', active: true },
      { id: 'inst-3', label: 'Folhetos', action: 'offers', active: true },
      { id: 'inst-4', label: 'WhatsApp de Ofertas', action: 'whatsapp', active: true },
      { id: 'inst-5', label: 'Trabalhe conosco', action: 'jobs', active: true },
      { id: 'inst-6', label: 'Cartão Aliança', action: 'card', active: true }
    ],
    institucionalCol2Links: [
      { id: 'inst-7', label: 'Aplicativo Meu Aliança', action: 'app', active: true },
      { id: 'inst-8', label: 'Responsabilidade Social', action: 'social', active: true },
      { id: 'inst-9', label: 'Imprensa', action: 'press', active: true },
      { id: 'inst-10', label: 'Blog Aliança', action: 'blog', active: true },
      { id: 'inst-11', label: 'Denúncias', action: 'ethics', active: true }
    ],
    politicasTitle: 'Políticas Mercadinho Aliança',
    politicasLinks: [
      { id: 'pol-1', label: 'Política de Trocas e Devoluções', action: 'refunds', active: true },
      { id: 'pol-2', label: 'Política de Entregas', action: 'delivery', active: true },
      { id: 'pol-3', label: 'Termos e Condições de Uso', action: 'terms', active: true },
      { id: 'pol-4', label: 'Políticas de Privacidade', action: 'privacy', active: true },
      { id: 'pol-5', label: 'Política de Diversidade', action: 'diversity', active: true },
      { id: 'pol-6', label: 'Outras Políticas', action: 'other_policies', active: true }
    ],
    paymentFlags: ['mastercard', 'visa', 'elo', 'hipercard', 'cartao_alianca', 'diners', 'amex', 'pix'],
    appDownloadTitle: 'Baixe o aplicativo Meu Aliança',
    googlePlayUrl: 'https://play.google.com',
    appStoreUrl: 'https://apple.com/app-store',
    socialTitle: 'Acompanhe a gente nas redes sociais',
    socialLinks: {
      facebook: 'https://facebook.com',
      instagram: 'https://instagram.com',
      x: 'https://x.com',
      youtube: 'https://youtube.com',
      linkedin: 'https://linkedin.com',
      whatsapp: 'https://wa.me/5574999598143'
    },
    legalNoticeText:
      'Racismo é crime. Denuncie. Disque 100 ou procure a Delegacia de Polícia Civil mais próxima ou o Ministério Público.',
    legalNoticeUrl: 'https://www.gov.br/mdh/pt-br/disque100'
  };

  const [formData, setFormData] = useState<StoreSettings>({
    storeName: 'Mercadinho Aliança',
    cnpj: '12.345.678/0001-90',
    phone: '(74) 99959-8143',
    phone2: '(74) 99800-8283',
    whatsapp: '5574999598143',
    whatsapp2: '5574998008283',
    email: 'contato@mercadinhoalianca.com.br',
    address: 'Rua Principal',
    streetNumber: '100',
    neighborhood: 'Centro',
    city: 'Bahia',
    state: 'BA',
    cep: '48900-000',
    complement: 'Em frente à Praça Central',
    reference: 'Ao lado da Farmácia Central',
    businessHours: 'Segunda a Sábado: 07h às 22h | Domingos e Feriados: 08h às 20h',
    pixKey: '74999598143',
    pixKeyType: 'PHONE',
    pixReceiver: 'Mercadinho Aliança',
    mercadoPagoAccessToken: '',
    mercadoPagoPublicKey: '',
    mercadoPagoConnected: false,
    stripeSecretKey: '',
    stripePublishableKey: '',
    stripeConnected: false,
    geminiApiKey: '',
    logoUrl: '/logo.png',
    demoMode: true,
    freeShippingThreshold: 180.00,
    defaultDeliveryFee: 5.00,
    wholesaleDefaultMinQty: 5,
    aiHelpEnabled: true,
    footerConfig: defaultFooterConfig
  });

  const [testingAi, setTestingAi] = useState(false);
  const [aiTestResult, setAiTestResult] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    if (settings) {
      setFormData(prev => ({
        ...prev,
        ...settings,
        phone: settings.phone || '(74) 99959-8143',
        phone2: settings.phone2 || '(74) 99800-8283',
        whatsapp: settings.whatsapp || '5574999598143',
        whatsapp2: settings.whatsapp2 || '5574998008283',
        address: settings.address || 'Rua Principal',
        streetNumber: settings.streetNumber || '100',
        neighborhood: settings.neighborhood || 'Centro',
        city: settings.city || 'Bahia',
        state: settings.state || 'BA',
        cep: settings.cep || '48900-000',
        cnpj: settings.cnpj || '12.345.678/0001-90',
        logoUrl: settings.logoUrl || '/logo.png',
        footerConfig: settings.footerConfig || prev.footerConfig || defaultFooterConfig
      }));
    }
  }, [settings]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        showToast('Arquivo muito grande', 'Selecione uma imagem de até 5MB.', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setFormData(prev => ({ ...prev, logoUrl: reader.result as string }));
          showToast('Logotipo Carregado', 'A nova imagem foi carregada para pré-visualização. Clique em "Salvar Configurações" para gravar.', 'success');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTestAi = async () => {
    setTestingAi(true);
    setAiTestResult(null);
    try {
      const res = await api.chatAi('Teste rápido de conexão com o sistema Mercadinho Aliança.', 'admin');
      if (res && res.reply) {
        setAiTestResult({ success: true, message: 'Conexão com Gemini estabelecida com sucesso!' });
        showToast('IA Operacional', 'O assistente respondeu normalmente.', 'success');
      } else {
        setAiTestResult({ success: false, message: 'Resposta vazia ou sem comunicação.' });
      }
    } catch (err: any) {
      setAiTestResult({
        success: false,
        message: err?.message || 'Não foi possível comunicar com o endpoint de IA.'
      });
    } finally {
      setTestingAi(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.updateSettings(formData);
      await refreshSettings();
      showToast('Configurações Salvas', 'Dados do mercado, logotipo, endereços, telefones e integrações foram salvos com sucesso.', 'success');
    } catch {
      showToast('Erro', 'Não foi possível salvar as configurações.', 'error');
    }
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div className="pb-4 border-b border-[#1E1E1E] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Painel Administrativo & Controle
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Configurações Gerais & Integrações Manuais
          </h1>
          <p className="text-xs text-[#888888] mt-1">
            Personalize a logo oficial, endereços, telefones corretos da Bahia (DDD 74) e insira chaves de API sem precisar mexer em código.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSubmit}
          className="px-6 py-3 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-widest rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-xl shadow-[#D4AF37]/20 self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          Salvar Alterações
        </button>
      </div>

      {/* Tabs Navigation */}
      <div className="flex flex-wrap gap-2 border-b border-[#222222] pb-3 text-xs font-bold">
        {[
          { id: 'identidade', label: '1. Logotipo & Marca', icon: ImageIcon },
          { id: 'endereco', label: '2. Endereço Completo', icon: MapPin },
          { id: 'telefones', label: '3. Telefones & WhatsApps', icon: Phone },
          { id: 'integracoes', label: '4. Chaves de API Manuais', icon: Key },
          { id: 'pagamentos', label: '5. PIX & Pagamentos', icon: CreditCard },
          { id: 'regras', label: '6. Frete & Atacado', icon: Truck },
          { id: 'rodape', label: '7. Gestão do Rodapé & Links', icon: Layers },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#D4AF37] text-black shadow-lg font-black'
                  : 'bg-[#121212] text-[#AAAAAA] hover:text-white hover:bg-[#1A1A1A] border border-[#242424]'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* ======================================================== */}
        {/* TAB 1: IDENTIDADE & LOGOTIPO                             */}
        {/* ======================================================== */}
        {activeTab === 'identidade' && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center gap-2 pb-3 border-b border-[#1A1A1A]">
              <ImageIcon className="w-5 h-5 text-[#D4AF37]" />
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
                  Logotipo Oficial do Mercadinho Aliança
                </h3>
                <p className="text-xs text-[#888888]">
                  Visualize o logotipo oficial ou envie um arquivo de imagem personalizado (PNG, JPG, SVG).
                </p>
              </div>
            </div>

            {/* Logo Preview & Upload */}
            <div className="flex flex-col md:flex-row items-center gap-8 p-6 bg-[#080808] border border-[#222222] rounded-2xl">
              {/* Visual preview */}
              <div className="flex flex-col items-center gap-2">
                <span className="text-[10px] uppercase font-bold text-[#888888] tracking-wider">
                  Pré-visualização do Logo
                </span>
                <div className="w-72 h-36 bg-[#050505] border-2 border-[#D4AF37]/50 rounded-2xl p-3 flex items-center justify-center overflow-hidden shadow-2xl relative group">
                  <img
                    src={formData.logoUrl || '/logo.png'}
                    alt="Logo Aliança Preview"
                    className="max-w-full max-h-full object-contain"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/logo.svg';
                    }}
                  />
                </div>
              </div>

              {/* Upload & controls */}
              <div className="space-y-4 flex-1 w-full text-xs">
                <div>
                  <label className="font-bold text-[#CCCCCC] uppercase block mb-1">
                    Enviar Imagem do Logotipo (PNG / JPG / SVG)
                  </label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept="image/png, image/jpeg, image/svg+xml, image/webp"
                    className="hidden"
                  />
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-4 py-2.5 bg-[#1C1C1C] hover:bg-[#2A2A2A] text-white font-bold rounded-xl border border-[#3E3E3E] flex items-center gap-2 cursor-pointer transition-colors"
                    >
                      <Upload className="w-4 h-4 text-[#D4AF37]" />
                      Carregar Imagem do Dispositivo
                    </button>

                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, logoUrl: '/logo.png' })}
                      className="px-4 py-2.5 bg-[#141414] hover:bg-[#202020] text-[#F2D675] font-bold rounded-xl border border-[#D4AF37]/40 flex items-center gap-2 cursor-pointer transition-colors"
                    >
                      <RefreshCw className="w-4 h-4" />
                      Restaurar Logotipo Oficial Padrão
                    </button>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    Ou informe o caminho / URL da imagem
                  </label>
                  <input
                    type="text"
                    value={formData.logoUrl || ''}
                    onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
                    placeholder="/logo.png ou https://..."
                    className="w-full bg-[#121212] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Nome da Loja *</label>
                    <input
                      type="text"
                      value={formData.storeName}
                      onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                      placeholder="Mercadinho Aliança"
                      className="w-full bg-[#121212] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="font-bold text-[#AAAAAA] uppercase block mb-1">CNPJ da Empresa</label>
                    <input
                      type="text"
                      value={formData.cnpj || ''}
                      onChange={(e) => setFormData({ ...formData, cnpj: e.target.value })}
                      placeholder="12.345.678/0001-90"
                      className="w-full bg-[#121212] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: ENDEREÇO COMPLETO                                */}
        {/* ======================================================== */}
        {activeTab === 'endereco' && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center gap-2 pb-3 border-b border-[#1A1A1A]">
              <MapPin className="w-5 h-5 text-[#D4AF37]" />
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
                  Endereço Oficial da Loja Física (Bahia)
                </h3>
                <p className="text-xs text-[#888888]">
                  Endereço impresso nos comprovantes térmicos, rodapé e página de contato.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="sm:col-span-2">
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Logradouro / Rua *
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Rua Principal"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-medium"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Número</label>
                <input
                  type="text"
                  value={formData.streetNumber || ''}
                  onChange={(e) => setFormData({ ...formData, streetNumber: e.target.value })}
                  placeholder="100 ou S/N"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Bairro</label>
                <input
                  type="text"
                  value={formData.neighborhood || ''}
                  onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                  placeholder="Centro"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Cidade (Bahia)</label>
                <input
                  type="text"
                  value={formData.city || ''}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="Bahia"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Estado</label>
                <input
                  type="text"
                  value={formData.state || ''}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  placeholder="BA"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">CEP</label>
                <input
                  type="text"
                  value={formData.cep || ''}
                  onChange={(e) => setFormData({ ...formData, cep: e.target.value })}
                  placeholder="48900-000"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Complemento</label>
                <input
                  type="text"
                  value={formData.complement || ''}
                  onChange={(e) => setFormData({ ...formData, complement: e.target.value })}
                  placeholder="Em frente à Praça Central"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Ponto de Referência</label>
                <input
                  type="text"
                  value={formData.reference || ''}
                  onChange={(e) => setFormData({ ...formData, reference: e.target.value })}
                  placeholder="Ao lado da Farmácia Central"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Horário de Funcionamento
                </label>
                <input
                  type="text"
                  value={formData.businessHours}
                  onChange={(e) => setFormData({ ...formData, businessHours: e.target.value })}
                  placeholder="Segunda a Sábado: 07h às 22h | Domingos e Feriados: 08h às 20h"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: TELEFONES & WHATSAPP CORRETOS                     */}
        {/* ======================================================== */}
        {activeTab === 'telefones' && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center gap-2 pb-3 border-b border-[#1A1A1A]">
              <Phone className="w-5 h-5 text-[#D4AF37]" />
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
                  Telefones Oficiais & Atendimento (Conforme Logo)
                </h3>
                <p className="text-xs text-[#888888]">
                  Telefones com DDD 74 da Bahia e links automáticos para mensagens no WhatsApp.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs">
              {/* Phone 1 */}
              <div className="p-4 bg-[#141414] border border-[#242424] rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-[#CCCCCC] uppercase flex items-center gap-1.5">
                    <Phone className="w-4 h-4 text-[#D4AF37]" />
                    Telefone 1 * (Conforme Logo)
                  </label>
                  <span className="text-[10px] text-emerald-400 font-bold">Principal</span>
                </div>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="(74) 99959-8143"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono font-bold outline-none text-sm"
                  required
                />
                <p className="text-[11px] text-[#777]">Número fixo ou móvel exibido no cabeçalho e recibos.</p>
              </div>

              {/* Phone 2 */}
              <div className="p-4 bg-[#141414] border border-[#242424] rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-[#CCCCCC] uppercase flex items-center gap-1.5">
                    <Phone className="w-4 h-4 text-[#D4AF37]" />
                    Telefone 2 (Conforme Logo)
                  </label>
                  <span className="text-[10px] text-[#888] font-bold">Secundário</span>
                </div>
                <input
                  type="text"
                  value={formData.phone2 || ''}
                  onChange={(e) => setFormData({ ...formData, phone2: e.target.value })}
                  placeholder="(74) 99800-8283"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono font-bold outline-none text-sm"
                />
                <p className="text-[11px] text-[#777]">Segundo telefone oficial registrado no logotipo da empresa.</p>
              </div>

              {/* WhatsApp 1 */}
              <div className="p-4 bg-[#141414] border border-[#242424] rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-[#CCCCCC] uppercase flex items-center gap-1.5">
                    <Phone className="w-4 h-4 text-emerald-400" />
                    WhatsApp 1 (Para Pedidos e Acompanhamento)
                  </label>
                  <a
                    href={`https://wa.me/${formData.whatsapp}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[10px] text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    Testar <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <input
                  type="text"
                  value={formData.whatsapp}
                  onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                  placeholder="5574999598143"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-emerald-400 font-mono font-bold outline-none text-sm"
                  required
                />
                <p className="text-[11px] text-[#777]">Formato com DDI (55) + DDD (74) + 9 dígitos.</p>
              </div>

              {/* WhatsApp 2 */}
              <div className="p-4 bg-[#141414] border border-[#242424] rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-[#CCCCCC] uppercase flex items-center gap-1.5">
                    <Phone className="w-4 h-4 text-emerald-400" />
                    WhatsApp 2 (Atendimento & SAC)
                  </label>
                  <a
                    href={`https://wa.me/${formData.whatsapp2}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[10px] text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    Testar <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <input
                  type="text"
                  value={formData.whatsapp2 || ''}
                  onChange={(e) => setFormData({ ...formData, whatsapp2: e.target.value })}
                  placeholder="5574998008283"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-emerald-400 font-mono font-bold outline-none text-sm"
                />
                <p className="text-[11px] text-[#777]">Segundo número de suporte ao cliente.</p>
              </div>

              {/* Email */}
              <div className="sm:col-span-2 p-4 bg-[#141414] border border-[#242424] rounded-2xl space-y-2">
                <label className="font-bold text-[#CCCCCC] uppercase block">E-mail Comercial & SAC</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="contato@mercadinhoalianca.com.br"
                  className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 4: CHAVES DE API MANUAIS (GEMINI, MP, STRIPE)       */}
        {/* ======================================================== */}
        {activeTab === 'integracoes' && (
          <div className="bg-[#0B0B0B] border border-[#D4AF37]/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#252525]">
              <div className="flex items-center gap-2.5">
                <Key className="w-5 h-5 text-[#D4AF37]" />
                <div>
                  <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
                    Configuração Manual de Chaves & Tokens
                  </h3>
                  <span className="text-[11px] text-[#A0A0A0]">
                    Você tem total liberdade para colar suas próprias chaves de IA e gateways aqui manualmente.
                  </span>
                </div>
              </div>

              <span className="bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#F2D675] text-[10px] font-black uppercase px-2.5 py-1 rounded-full">
                Controle Manual
              </span>
            </div>

            <div className="space-y-5 text-xs">
              {/* Master Password Card */}
              <div className="p-5 bg-gradient-to-r from-[#141414] to-[#181818] border border-[#D4AF37]/50 rounded-2xl space-y-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-white uppercase flex items-center gap-2">
                    <Key className="w-4 h-4 text-[#D4AF37]" />
                    Senha Mestre do Painel de Administrador (Padrão: 12345)
                  </label>
                  <span className="bg-[#D4AF37]/20 text-[#F2D675] font-mono text-[10px] font-bold px-2 py-0.5 rounded border border-[#D4AF37]/40">
                    Acesso Master
                  </span>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={formData.masterPassword || '12345'}
                    onChange={(e) => setFormData({ ...formData, masterPassword: e.target.value })}
                    placeholder="12345"
                    className="flex-1 bg-[#1A1A1A] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-[#F2D675] font-mono font-bold outline-none text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, masterPassword: '12345' })}
                    className="px-3 py-2 bg-[#222] hover:bg-[#2A2A2A] text-[#CCC] text-xs font-bold rounded-xl border border-[#444] transition-colors cursor-pointer shrink-0"
                    title="Restaurar padrão inicial 12345"
                  >
                    Restaurar 12345
                  </button>
                </div>

                <p className="text-[11px] text-[#888888]">
                  Esta é a sua senha mestre para acessar ou desbloquear o painel. As senhas de cada colaborador da sua equipe você define individualmente na aba <strong>"Equipe & Senhas"</strong>.
                </p>
              </div>

              {/* Visibilidade do Painel / Ocultar do Público */}
              <div className="p-5 bg-[#141414] border-2 border-[#D4AF37]/40 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="font-bold text-white uppercase flex items-center gap-2 text-sm">
                      <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                      Painel Visível Apenas para o Administrador (Ocultar do Público)
                    </label>
                    <span className="text-[11px] text-[#AAAAAA] block mt-0.5">
                      Quando ativado, o rodapé não exibe nenhum link ("Área do Colaborador"). O acesso é exclusivo do administrador via <strong>Ctrl+Shift+A</strong> ou 3 toques no rodapé.
                    </span>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={formData.hideAdminAccessFromPublic !== false}
                      onChange={(e) => setFormData({ ...formData, hideAdminAccessFromPublic: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-12 h-6 bg-[#333333] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#D4AF37]"></div>
                  </label>
                </div>
              </div>

              {/* Google Gemini API Key */}
              <div className="p-5 bg-[#141414] border border-[#292929] rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-white uppercase flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                    Google Gemini API Key (IA Concierge, Cadastro com IA & Function Calling)
                  </label>
                  {formData.geminiApiKey ? (
                    <span className="text-emerald-400 font-bold text-[10px] flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" /> Chave Inserida
                    </span>
                  ) : (
                    <span className="text-[#888] text-[10px]">Utilizando chave do ambiente .env</span>
                  )}
                </div>

                <div className="flex gap-2">
                  <input
                    type="password"
                    value={formData.geminiApiKey || ''}
                    onChange={(e) => setFormData({ ...formData, geminiApiKey: e.target.value })}
                    placeholder="AIzaSy... (Cole sua chave do Google AI Studio)"
                    className="flex-1 bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleTestAi}
                    disabled={testingAi}
                    className="px-4 py-2 bg-[#222222] hover:bg-[#333333] text-[#F2D675] font-bold rounded-xl border border-[#444] flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 disabled:opacity-50"
                  >
                    {testingAi ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />}
                    Testar Conexão IA
                  </button>
                </div>

                {aiTestResult && (
                  <div
                    className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                      aiTestResult.success
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                        : 'bg-red-500/10 border-red-500/30 text-red-300'
                    }`}
                  >
                    {aiTestResult.success ? <Check className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                    <span>{aiTestResult.message}</span>
                  </div>
                )}

                <p className="text-[11px] text-[#777777]">
                  Com essa chave o backend processa o Chat com IA, cadastra produtos por texto/foto e executa Function Calling com o banco de dados.
                </p>
              </div>

              {/* Mercado Pago */}
              <div className="p-5 bg-[#141414] border border-[#292929] rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-white uppercase flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-sky-400" />
                    Mercado Pago (Cartão, Débito e PIX Instantâneo)
                  </label>
                  {formData.mercadoPagoAccessToken ? (
                    <span className="text-emerald-400 font-bold text-[10px] flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" /> Token Manual Configurado
                    </span>
                  ) : (
                    <span className="text-amber-400 text-[10px] font-bold">Modo Simulado Ativo</span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-[#999] block mb-1">Access Token (Produção ou Teste)</label>
                    <input
                      type="password"
                      value={formData.mercadoPagoAccessToken || ''}
                      onChange={(e) => setFormData({ ...formData, mercadoPagoAccessToken: e.target.value })}
                      placeholder="APP_USR-xxxxxxxxxxxxxxxxxxxxxxxx"
                      className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-[#999] block mb-1">Public Key (Opcional)</label>
                    <input
                      type="text"
                      value={formData.mercadoPagoPublicKey || ''}
                      onChange={(e) => setFormData({ ...formData, mercadoPagoPublicKey: e.target.value })}
                      placeholder="APP_USR-xxxxxxxx-xxxx-xxxx-xxxx"
                      className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                    />
                  </div>
                </div>

                {/* Demo Mode Toggle */}
                <div className="pt-2 flex items-center justify-between border-t border-[#222222]">
                  <div>
                    <span className="font-bold text-white block">Modo Demonstração / Testes Rápidos</span>
                    <span className="text-[11px] text-[#777]">
                      Gera QR Codes PIX realistas e simula aprovação imediata para você testar todo o fluxo da loja sem cobrança bancária.
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={formData.demoMode}
                      onChange={(e) => setFormData({ ...formData, demoMode: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-[#333333] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#D4AF37]"></div>
                  </label>
                </div>
              </div>

              {/* Stripe */}
              <div className="p-5 bg-[#141414] border border-[#292929] rounded-2xl space-y-3">
                <label className="font-bold text-white uppercase flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-purple-400" />
                  Stripe (Pagamentos Internacionais e Cartões)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-[#999] block mb-1">Secret Key</label>
                    <input
                      type="password"
                      value={formData.stripeSecretKey || ''}
                      onChange={(e) => setFormData({ ...formData, stripeSecretKey: e.target.value })}
                      placeholder="sk_live_... ou sk_test_..."
                      className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-[#999] block mb-1">Publishable Key</label>
                    <input
                      type="text"
                      value={formData.stripePublishableKey || ''}
                      onChange={(e) => setFormData({ ...formData, stripePublishableKey: e.target.value })}
                      placeholder="pk_live_... ou pk_test_..."
                      className="w-full bg-[#181818] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 5: PIX & PAGAMENTOS                                  */}
        {/* ======================================================== */}
        {activeTab === 'pagamentos' && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center gap-2 pb-3 border-b border-[#1A1A1A]">
              <Building className="w-5 h-5 text-[#D4AF37]" />
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
                  Configuração de PIX Direto da Loja
                </h3>
                <p className="text-xs text-[#888888]">
                  Defina a chave PIX e recebedor para pagamentos diretos na conta bancária do Mercadinho Aliança.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Chave PIX da Loja *</label>
                <input
                  type="text"
                  value={formData.pixKey}
                  onChange={(e) => setFormData({ ...formData, pixKey: e.target.value })}
                  placeholder="74999598143"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Tipo da Chave PIX</label>
                <select
                  value={formData.pixKeyType}
                  onChange={(e) => setFormData({ ...formData, pixKeyType: e.target.value as any })}
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none cursor-pointer"
                >
                  <option value="PHONE">Telefone ((74) 99959-8143)</option>
                  <option value="CNPJ">CNPJ da Empresa</option>
                  <option value="CPF">CPF</option>
                  <option value="EMAIL">E-mail</option>
                  <option value="RANDOM">Chave Aleatória (EVP)</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Nome do Favorecido / Beneficiário
                </label>
                <input
                  type="text"
                  value={formData.pixReceiver}
                  onChange={(e) => setFormData({ ...formData, pixReceiver: e.target.value })}
                  placeholder="Mercadinho Aliança"
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-bold"
                  required
                />
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 6: REGRAS DE FRETE & ATACADO                         */}
        {/* ======================================================== */}
        {activeTab === 'regras' && (
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center gap-2 pb-3 border-b border-[#1A1A1A]">
              <Truck className="w-5 h-5 text-[#D4AF37]" />
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
                  Regras de Frete, Delivery & Atacado
                </h3>
                <p className="text-xs text-[#888888]">
                  Defina o valor mínimo para frete grátis e parâmetros padrão de atacado.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Valor Mínimo para Frete Grátis (R$)
                </label>
                <input
                  type="number"
                  step="1"
                  value={formData.freeShippingThreshold}
                  onChange={(e) => setFormData({ ...formData, freeShippingThreshold: Number(e.target.value) })}
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-bold text-sm"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Taxa Padrão de Entrega (R$)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={formData.defaultDeliveryFee || 5.00}
                  onChange={(e) => setFormData({ ...formData, defaultDeliveryFee: Number(e.target.value) })}
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-bold text-sm"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Qtd Mínima Padrão para Preço de Atacado
                </label>
                <input
                  type="number"
                  step="1"
                  value={formData.wholesaleDefaultMinQty || 5}
                  onChange={(e) => setFormData({ ...formData, wholesaleDefaultMinQty: Number(e.target.value) })}
                  className="w-full bg-[#141414] border border-[#2B2B2B] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-bold text-sm"
                />
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 7: GESTÃO DO RODAPÉ & LINKS                          */}
        {/* ======================================================== */}
        {activeTab === 'rodape' && (
          <div className="pt-2">
            <AdminFooter />
          </div>
        )}

        {/* Global Save Button at bottom */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-[#1C1C1C]">
          <div className="text-xs text-[#777]">
            Todas as alterações entram em vigor imediatamente após salvar.
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xl shadow-[#D4AF37]/20"
          >
            <Save className="w-4 h-4" />
            Salvar Todas as Configurações
          </button>
        </div>
      </form>
    </div>
  );
};
