import React, { useState, useEffect } from 'react';
import {
  Layers,
  Save,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  Eye,
  EyeOff,
  Link as LinkIcon,
  ShieldCheck,
  AlertCircle,
  Lock,
  ExternalLink,
  Smartphone,
  CreditCard,
  MessageCircle,
  Sparkles,
  HelpCircle,
  RefreshCw,
  X,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import { api } from '../../services/api.ts';
import { FooterConfig, FooterLink, StoreSettings } from '../../../shared/types.ts';

export const AdminFooter: React.FC = () => {
  const { settings, refreshSettings, showToast } = useApp();

  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'colunas' | 'pagamentos' | 'app_social' | 'seguranca' | 'preview'>('colunas');

  // Editing link modal state
  const [editingModal, setEditingModal] = useState<{
    isOpen: boolean;
    section: 'atendimento' | 'institucional1' | 'institucional2' | 'politicas';
    link: FooterLink;
    isNew: boolean;
  }>({
    isOpen: false,
    section: 'atendimento',
    link: { id: '', label: '', action: 'about', active: true },
    isNew: false
  });

  // Local state initialized with store settings
  const [hideAdminAccess, setHideAdminAccess] = useState<boolean>(true);

  const [footerConfig, setFooterConfig] = useState<FooterConfig>({
    atendimentoTitle: 'Atendimento',
    atendimentoLinks: [
      { id: 'at-1', label: 'Meus pedidos', action: 'orders', active: true },
      { id: 'at-2', label: 'Central de atendimento', action: 'sac', active: true },
      { id: 'at-3', label: 'Fale conosco', action: 'contact', active: true }
    ],
    institucionalTitle: 'Institucional',
    institucionalCol1Links: [
      { id: 'inst-1', label: 'Quem somos', action: 'about', active: true },
      { id: 'inst-2', label: 'Nossas lojas', action: 'stores', active: true },
      { id: 'inst-3', label: 'Folhetos', action: 'offers', active: true },
      { id: 'inst-4', label: 'WhatsApp de Ofertas', action: 'whatsapp', active: true },
      { id: 'inst-5', label: 'Trabalhe conosco', action: 'jobs', active: true },
      { id: 'inst-6', label: 'Cartão Aliança', action: 'card', active: true }
    ],
    institucionalCol2Links: [
      { id: 'inst-7', label: 'Aplicativo Meu Aliança', action: 'app', active: true },
      { id: 'inst-8', label: 'Responsabilidade Social', action: 'social', active: true },
      { id: 'inst-9', label: 'Imprensa', action: 'press', active: true },
      { id: 'inst-10', label: 'Blog Aliança', action: 'blog', active: true },
      { id: 'inst-11', label: 'Denúncias', action: 'ethics', active: true }
    ],
    politicasTitle: 'Políticas Mercadinho Aliança',
    politicasLinks: [
      { id: 'pol-1', label: 'Política de Trocas e Devoluções', action: 'refunds', active: true },
      { id: 'pol-2', label: 'Política de Entregas', action: 'delivery', active: true },
      { id: 'pol-3', label: 'Termos e Condições de Uso', action: 'terms', active: true },
      { id: 'pol-4', label: 'Políticas de Privacidade', action: 'privacy', active: true },
      { id: 'pol-5', label: 'Política de Diversidade', action: 'diversity', active: true },
      { id: 'pol-6', label: 'Outras Políticas', action: 'other_policies', active: true }
    ],
    paymentFlags: ['mastercard', 'visa', 'elo', 'hipercard', 'cartao_alianca', 'diners', 'amex', 'pix'],
    appDownloadTitle: 'Baixe o aplicativo Meu Aliança',
    googlePlayUrl: 'https://play.google.com',
    appStoreUrl: 'https://apple.com/app-store',
    showAppDownload: true,
    socialTitle: 'Acompanhe a gente nas redes sociais',
    socialLinks: {
      facebook: 'https://facebook.com',
      instagram: 'https://instagram.com',
      x: 'https://x.com',
      youtube: 'https://youtube.com',
      linkedin: 'https://linkedin.com',
      whatsapp: 'https://wa.me/5574999598143'
    },
    legalNoticeText:
      'Racismo é crime. Denuncie. Disque 100 ou procure a Delegacia de Polícia Civil mais próxima ou o Ministério Público.',
    legalNoticeUrl: 'https://www.gov.br/mdh/pt-br/disque100'
  });

  useEffect(() => {
    if (settings) {
      if (settings.footerConfig) {
        setFooterConfig(settings.footerConfig);
      }
      setHideAdminAccess(settings.hideAdminAccessFromPublic !== false);
    }
  }, [settings]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await api.updateSettings({
        footerConfig,
        hideAdminAccessFromPublic: hideAdminAccess
      });
      await refreshSettings();
      showToast('Rodapé Salvo', 'As alterações do rodapé e a privacidade do painel foram atualizadas!', 'success');
    } catch (err: any) {
      showToast('Erro', 'Não foi possível salvar as configurações do rodapé.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Section Links Handlers
  const handleOpenAddLink = (section: 'atendimento' | 'institucional1' | 'institucional2' | 'politicas') => {
    setEditingModal({
      isOpen: true,
      section,
      link: {
        id: `link-${Date.now()}`,
        label: '',
        action: 'about',
        url: '',
        active: true
      },
      isNew: true
    });
  };

  const handleOpenEditLink = (
    section: 'atendimento' | 'institucional1' | 'institucional2' | 'politicas',
    link: FooterLink
  ) => {
    setEditingModal({
      isOpen: true,
      section,
      link: { ...link },
      isNew: false
    });
  };

  const handleSaveLinkModal = () => {
    if (!editingModal.link.label.trim()) {
      showToast('Campo Obrigatório', 'Informe o texto do link.', 'error');
      return;
    }

    const { section, link, isNew } = editingModal;
    const updateLinks = (current: FooterLink[]) => {
      if (isNew) {
        return [...current, link];
      }
      return current.map(item => (item.id === link.id ? link : item));
    };

    if (section === 'atendimento') {
      setFooterConfig(prev => ({
        ...prev,
        atendimentoLinks: updateLinks(prev.atendimentoLinks)
      }));
    } else if (section === 'institucional1') {
      setFooterConfig(prev => ({
        ...prev,
        institucionalCol1Links: updateLinks(prev.institucionalCol1Links)
      }));
    } else if (section === 'institucional2') {
      setFooterConfig(prev => ({
        ...prev,
        institucionalCol2Links: updateLinks(prev.institucionalCol2Links)
      }));
    } else if (section === 'politicas') {
      setFooterConfig(prev => ({
        ...prev,
        politicasLinks: updateLinks(prev.politicasLinks)
      }));
    }

    setEditingModal({ ...editingModal, isOpen: false });
    showToast('Link Atualizado', `O link "${link.label}" foi salvo na lista.`, 'info');
  };

  const handleDeleteLink = (
    section: 'atendimento' | 'institucional1' | 'institucional2' | 'politicas',
    linkId: string
  ) => {
    if (section === 'atendimento') {
      setFooterConfig(prev => ({
        ...prev,
        atendimentoLinks: prev.atendimentoLinks.filter(l => l.id !== linkId)
      }));
    } else if (section === 'institucional1') {
      setFooterConfig(prev => ({
        ...prev,
        institucionalCol1Links: prev.institucionalCol1Links.filter(l => l.id !== linkId)
      }));
    } else if (section === 'institucional2') {
      setFooterConfig(prev => ({
        ...prev,
        institucionalCol2Links: prev.institucionalCol2Links.filter(l => l.id !== linkId)
      }));
    } else if (section === 'politicas') {
      setFooterConfig(prev => ({
        ...prev,
        politicasLinks: prev.politicasLinks.filter(l => l.id !== linkId)
      }));
    }
  };

  const handleToggleLinkActive = (
    section: 'atendimento' | 'institucional1' | 'institucional2' | 'politicas',
    linkId: string
  ) => {
    const toggle = (list: FooterLink[]) =>
      list.map(l => (l.id === linkId ? { ...l, active: !l.active } : l));

    if (section === 'atendimento') {
      setFooterConfig(prev => ({ ...prev, atendimentoLinks: toggle(prev.atendimentoLinks) }));
    } else if (section === 'institucional1') {
      setFooterConfig(prev => ({ ...prev, institucionalCol1Links: toggle(prev.institucionalCol1Links) }));
    } else if (section === 'institucional2') {
      setFooterConfig(prev => ({ ...prev, institucionalCol2Links: toggle(prev.institucionalCol2Links) }));
    } else if (section === 'politicas') {
      setFooterConfig(prev => ({ ...prev, politicasLinks: toggle(prev.politicasLinks) }));
    }
  };

  // Flag toggle
  const allFlags = [
    { id: 'mastercard', label: 'Mastercard' },
    { id: 'visa', label: 'Visa' },
    { id: 'elo', label: 'Elo' },
    { id: 'hipercard', label: 'Hipercard' },
    { id: 'cartao_alianca', label: 'Cartão Aliança / Crediário' },
    { id: 'diners', label: 'Diners Club / Vouchers' },
    { id: 'amex', label: 'American Express' },
    { id: 'pix', label: 'PIX Oficial' }
  ];

  const handleToggleFlag = (flagId: string) => {
    setFooterConfig(prev => {
      const exists = prev.paymentFlags.includes(flagId);
      const updated = exists
        ? prev.paymentFlags.filter(f => f !== flagId)
        : [...prev.paymentFlags, flagId];
      return { ...prev, paymentFlags: updated };
    });
  };

  const actionsList = [
    { value: 'orders', label: 'Página: Meus Pedidos' },
    { value: 'sac', label: 'Aviso: Central de Atendimento & Telefones' },
    { value: 'contact', label: 'Aviso: Fale Conosco' },
    { value: 'about', label: 'Página: Quem Somos / Institucional' },
    { value: 'stores', label: 'Aviso: Nossas Lojas Físicas' },
    { value: 'offers', label: 'Página: Folhetos & Ofertas' },
    { value: 'whatsapp', label: 'Abrir WhatsApp Direto' },
    { value: 'jobs', label: 'Aviso: Trabalhe Conosco (E-mail)' },
    { value: 'card', label: 'Aviso: Cartão Aliança / Crediário' },
    { value: 'app', label: 'Aviso: Aplicativo Meu Aliança' },
    { value: 'social', label: 'Aviso: Responsabilidade Social' },
    { value: 'press', label: 'Aviso: Assessoria de Imprensa' },
    { value: 'blog', label: 'Aviso: Blog Aliança' },
    { value: 'ethics', label: 'Aviso: Denúncias & Ética' },
    { value: 'refunds', label: 'Aviso: Trocas & Devoluções' },
    { value: 'delivery', label: 'Página: Política de Entregas & Frete' },
    { value: 'terms', label: 'Página: Termos e Condições' },
    { value: 'privacy', label: 'Página: Política de Privacidade' },
    { value: 'diversity', label: 'Aviso: Diversidade e Inclusão' },
    { value: 'other_policies', label: 'Aviso: Outras Políticas Gerais' },
    { value: 'custom_url', label: 'Link Externo (URL personalizada)' }
  ];

  return (
    <div className="space-y-6 max-w-6xl pb-16">
      {/* Top Header */}
      <div className="pb-4 border-b border-[#1E1E1E] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Customização Total do Supermercado
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Gestão do Rodapé & Acesso do Administrador
          </h1>
          <p className="text-xs text-[#888888] mt-1">
            Edite todos os textos, links, bandeiras de cartão, redes sociais, avisos legais e configure a visibilidade exclusiva do painel administrativo.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSave}
          disabled={isSaving}
          className="px-6 py-3 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-widest rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-xl shadow-[#D4AF37]/20 self-start sm:self-auto disabled:opacity-50"
        >
          {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Salvar Todas as Alterações
        </button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-[#222222] pb-3 text-xs font-bold">
        {[
          { id: 'colunas', label: '1. Colunas & Links (Atendimento, Institucional, Políticas)', icon: Layers },
          { id: 'pagamentos', label: '2. Bandeiras de Pagamento', icon: CreditCard },
          { id: 'app_social', label: '3. App, Redes Sociais & Aviso Legal', icon: Smartphone },
          { id: 'seguranca', label: '4. Segurança & Painel Visível Apenas ao Administrador', icon: Lock },
          { id: 'preview', label: '5. Pré-visualização ao Vivo', icon: Eye }
        ].map(t => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#D4AF37] text-black shadow-lg font-black'
                  : 'bg-[#121212] text-[#AAAAAA] hover:text-white hover:bg-[#1A1A1A] border border-[#242424]'
              }`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: 3 COLUNAS PRINCIPAIS (ATENDIMENTO, INSTITUCIONAL, POLÍTICAS)       */}
      {/* ========================================================================= */}
      {activeTab === 'colunas' && (
        <div className="space-y-6">
          {/* COLUNA 1: ATENDIMENTO */}
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#1A1A1A] gap-3">
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
                  Coluna 1: Atendimento
                </h3>
                <p className="text-xs text-[#888888]">
                  Edite o título da coluna e os links exibidos para o cliente.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={footerConfig.atendimentoTitle}
                  onChange={(e) => setFooterConfig({ ...footerConfig, atendimentoTitle: e.target.value })}
                  placeholder="Atendimento"
                  className="bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-1.5 text-xs text-white outline-none font-bold"
                />
                <button
                  type="button"
                  onClick={() => handleOpenAddLink('atendimento')}
                  className="px-3 py-1.5 bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#F2D675] border border-[#D4AF37]/40 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Adicionar Link
                </button>
              </div>
            </div>

            {/* Links table */}
            <div className="space-y-2">
              {footerConfig.atendimentoLinks.map((link) => (
                <div
                  key={link.id}
                  className="flex items-center justify-between p-3 bg-[#121212] border border-[#222222] rounded-xl text-xs gap-3 hover:border-[#333] transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleToggleLinkActive('atendimento', link.id)}
                      className={`w-6 h-6 rounded-lg flex items-center justify-center cursor-pointer transition-colors ${
                        link.active ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-zinc-800 text-zinc-500'
                      }`}
                      title={link.active ? 'Link Ativo (Visível)' : 'Link Inativo (Oculto)'}
                    >
                      {link.active ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    </button>
                    <div>
                      <span className={`font-bold block ${link.active ? 'text-white' : 'text-zinc-500 line-through'}`}>
                        {link.label}
                      </span>
                      <span className="text-[10px] text-[#777] font-mono">
                        Ação: {link.action || 'Sem ação'} {link.url ? `(${link.url})` : ''}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpenEditLink('atendimento', link)}
                      className="p-1.5 bg-[#1C1C1C] hover:bg-[#2A2A2A] text-[#CCC] hover:text-[#D4AF37] rounded-lg transition-colors cursor-pointer"
                      title="Editar"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteLink('atendimento', link.id)}
                      className="p-1.5 bg-red-950/20 hover:bg-red-950/40 text-red-400 rounded-lg transition-colors cursor-pointer"
                      title="Excluir"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* COLUNA 2: INSTITUCIONAL (COM 2 SUBCOLUNAS) */}
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#1A1A1A] gap-3">
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
                  Coluna 2: Institucional (Duas Sub-colunas Lado a Lado)
                </h3>
                <p className="text-xs text-[#888888]">
                  Esta coluna possui duas listas lado a lado exatamente como especificado.
                </p>
              </div>

              <div>
                <input
                  type="text"
                  value={footerConfig.institucionalTitle}
                  onChange={(e) => setFooterConfig({ ...footerConfig, institucionalTitle: e.target.value })}
                  placeholder="Institucional"
                  className="bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-1.5 text-xs text-white outline-none font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Sub-coluna 1 */}
              <div className="p-4 bg-[#0E0E0E] border border-[#222] rounded-2xl space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[#1C1C1C]">
                  <span className="text-xs font-bold text-[#F2D675] uppercase">
                    Sub-coluna 1 (Quem somos, Lojas, Folhetos...)
                  </span>
                  <button
                    type="button"
                    onClick={() => handleOpenAddLink('institucional1')}
                    className="px-2.5 py-1 bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#F2D675] rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" /> Adicionar
                  </button>
                </div>

                <div className="space-y-2">
                  {footerConfig.institucionalCol1Links.map((link) => (
                    <div
                      key={link.id}
                      className="flex items-center justify-between p-2.5 bg-[#141414] border border-[#252525] rounded-xl text-xs gap-2"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <button
                          type="button"
                          onClick={() => handleToggleLinkActive('institucional1', link.id)}
                          className={`w-5 h-5 rounded flex items-center justify-center cursor-pointer ${
                            link.active ? 'text-emerald-400 bg-emerald-500/10' : 'text-zinc-500 bg-zinc-800'
                          }`}
                        >
                          {link.active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                        </button>
                        <span className={`font-medium truncate ${link.active ? 'text-white' : 'text-zinc-500 line-through'}`}>
                          {link.label}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleOpenEditLink('institucional1', link)}
                          className="p-1 text-[#AAA] hover:text-[#D4AF37] cursor-pointer"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteLink('institucional1', link.id)}
                          className="p-1 text-red-400 hover:text-red-300 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Sub-coluna 2 */}
              <div className="p-4 bg-[#0E0E0E] border border-[#222] rounded-2xl space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[#1C1C1C]">
                  <span className="text-xs font-bold text-[#F2D675] uppercase">
                    Sub-coluna 2 (Aplicativo, Social, Imprensa...)
                  </span>
                  <button
                    type="button"
                    onClick={() => handleOpenAddLink('institucional2')}
                    className="px-2.5 py-1 bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#F2D675] rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" /> Adicionar
                  </button>
                </div>

                <div className="space-y-2">
                  {footerConfig.institucionalCol2Links.map((link) => (
                    <div
                      key={link.id}
                      className="flex items-center justify-between p-2.5 bg-[#141414] border border-[#252525] rounded-xl text-xs gap-2"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <button
                          type="button"
                          onClick={() => handleToggleLinkActive('institucional2', link.id)}
                          className={`w-5 h-5 rounded flex items-center justify-center cursor-pointer ${
                            link.active ? 'text-emerald-400 bg-emerald-500/10' : 'text-zinc-500 bg-zinc-800'
                          }`}
                        >
                          {link.active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                        </button>
                        <span className={`font-medium truncate ${link.active ? 'text-white' : 'text-zinc-500 line-through'}`}>
                          {link.label}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleOpenEditLink('institucional2', link)}
                          className="p-1 text-[#AAA] hover:text-[#D4AF37] cursor-pointer"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteLink('institucional2', link.id)}
                          className="p-1 text-red-400 hover:text-red-300 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* COLUNA 3: POLÍTICAS MERCADINHO ALIANÇA */}
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#1A1A1A] gap-3">
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
                  Coluna 3: Políticas Mercadinho Aliança
                </h3>
                <p className="text-xs text-[#888888]">
                  Trocas, entregas, termos de uso, privacidade, diversidade e diretrizes.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={footerConfig.politicasTitle}
                  onChange={(e) => setFooterConfig({ ...footerConfig, politicasTitle: e.target.value })}
                  placeholder="Políticas Mercadinho Aliança"
                  className="bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-3 py-1.5 text-xs text-white outline-none font-bold"
                />
                <button
                  type="button"
                  onClick={() => handleOpenAddLink('politicas')}
                  className="px-3 py-1.5 bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#F2D675] border border-[#D4AF37]/40 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Adicionar Link
                </button>
              </div>
            </div>

            {/* Links table */}
            <div className="space-y-2">
              {footerConfig.politicasLinks.map((link) => (
                <div
                  key={link.id}
                  className="flex items-center justify-between p-3 bg-[#121212] border border-[#222222] rounded-xl text-xs gap-3 hover:border-[#333] transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleToggleLinkActive('politicas', link.id)}
                      className={`w-6 h-6 rounded-lg flex items-center justify-center cursor-pointer transition-colors ${
                        link.active ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-zinc-800 text-zinc-500'
                      }`}
                      title={link.active ? 'Link Ativo (Visível)' : 'Link Inativo (Oculto)'}
                    >
                      {link.active ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    </button>
                    <div>
                      <span className={`font-bold block ${link.active ? 'text-white' : 'text-zinc-500 line-through'}`}>
                        {link.label}
                      </span>
                      <span className="text-[10px] text-[#777] font-mono">
                        Ação: {link.action || 'Sem ação'} {link.url ? `(${link.url})` : ''}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpenEditLink('politicas', link)}
                      className="p-1.5 bg-[#1C1C1C] hover:bg-[#2A2A2A] text-[#CCC] hover:text-[#D4AF37] rounded-lg transition-colors cursor-pointer"
                      title="Editar"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteLink('politicas', link.id)}
                      className="p-1.5 bg-red-950/20 hover:bg-red-950/40 text-red-400 rounded-lg transition-colors cursor-pointer"
                      title="Excluir"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: BANDEIRAS DE PAGAMENTO NO RODAPÉ                                   */}
      {/* ========================================================================= */}
      {activeTab === 'pagamentos' && (
        <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="pb-3 border-b border-[#1A1A1A]">
            <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
              Bandeiras Visuais de Cartões & Meios de Pagamento
            </h3>
            <p className="text-xs text-[#888888]">
              Ative ou desative as bandeiras que são renderizadas com destaque visual no rodapé do site.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {allFlags.map((flag) => {
              const isEnabled = footerConfig.paymentFlags.includes(flag.id);
              return (
                <div
                  key={flag.id}
                  onClick={() => handleToggleFlag(flag.id)}
                  className={`p-4 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                    isEnabled
                      ? 'bg-[#181818] border-[#D4AF37]/50 shadow-md'
                      : 'bg-[#0E0E0E] border-[#222222] opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs ${
                        isEnabled ? 'bg-[#D4AF37] text-black' : 'bg-zinc-800 text-zinc-500'
                      }`}
                    >
                      {isEnabled ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                    </div>
                    <span className="font-bold text-xs text-white">{flag.label}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: APP, REDES SOCIAIS & AVISO LEGAL                                   */}
      {/* ========================================================================= */}
      {activeTab === 'app_social' && (
        <div className="space-y-6">
          {/* Baixe o App */}
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1A1A1A]">
              <div>
                <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
                  Bloco "Baixe o aplicativo Meu Aliança"
                </h3>
                <p className="text-xs text-[#888888]">
                  Configure os botões oficiais para Google Play e Apple App Store.
                </p>
              </div>

              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={footerConfig.showAppDownload !== false}
                  onChange={(e) => setFooterConfig({ ...footerConfig, showAppDownload: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#333333] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#D4AF37]"></div>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Título do Bloco</label>
                <input
                  type="text"
                  value={footerConfig.appDownloadTitle}
                  onChange={(e) => setFooterConfig({ ...footerConfig, appDownloadTitle: e.target.value })}
                  placeholder="Baixe o aplicativo Meu Aliança"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Link Google Play</label>
                <input
                  type="text"
                  value={footerConfig.googlePlayUrl}
                  onChange={(e) => setFooterConfig({ ...footerConfig, googlePlayUrl: e.target.value })}
                  placeholder="https://play.google.com/..."
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Link Apple App Store</label>
                <input
                  type="text"
                  value={footerConfig.appStoreUrl}
                  onChange={(e) => setFooterConfig({ ...footerConfig, appStoreUrl: e.target.value })}
                  placeholder="https://apple.com/app-store/..."
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                />
              </div>
            </div>
          </div>

          {/* Redes Sociais */}
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-4 shadow-xl">
            <div className="pb-3 border-b border-[#1A1A1A]">
              <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider">
                Redes Sociais Oficiais
              </h3>
              <p className="text-xs text-[#888888]">
                Links dos botões circulares exibidos no rodapé do Mercadinho Aliança.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Título do Bloco</label>
                <input
                  type="text"
                  value={footerConfig.socialTitle}
                  onChange={(e) => setFooterConfig({ ...footerConfig, socialTitle: e.target.value })}
                  placeholder="Acompanhe a gente nas redes sociais"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Facebook</label>
                <input
                  type="text"
                  value={footerConfig.socialLinks?.facebook || ''}
                  onChange={(e) =>
                    setFooterConfig({
                      ...footerConfig,
                      socialLinks: { ...footerConfig.socialLinks, facebook: e.target.value }
                    })
                  }
                  placeholder="https://facebook.com/mercadinhoalianca"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Instagram</label>
                <input
                  type="text"
                  value={footerConfig.socialLinks?.instagram || ''}
                  onChange={(e) =>
                    setFooterConfig({
                      ...footerConfig,
                      socialLinks: { ...footerConfig.socialLinks, instagram: e.target.value }
                    })
                  }
                  placeholder="https://instagram.com/mercadinhoalianca"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">X (Twitter)</label>
                <input
                  type="text"
                  value={footerConfig.socialLinks?.x || ''}
                  onChange={(e) =>
                    setFooterConfig({
                      ...footerConfig,
                      socialLinks: { ...footerConfig.socialLinks, x: e.target.value }
                    })
                  }
                  placeholder="https://x.com/alianca"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">YouTube</label>
                <input
                  type="text"
                  value={footerConfig.socialLinks?.youtube || ''}
                  onChange={(e) =>
                    setFooterConfig({
                      ...footerConfig,
                      socialLinks: { ...footerConfig.socialLinks, youtube: e.target.value }
                    })
                  }
                  placeholder="https://youtube.com/@mercadinhoalianca"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">WhatsApp</label>
                <input
                  type="text"
                  value={footerConfig.socialLinks?.whatsapp || ''}
                  onChange={(e) =>
                    setFooterConfig({
                      ...footerConfig,
                      socialLinks: { ...footerConfig.socialLinks, whatsapp: e.target.value }
                    })
                  }
                  placeholder="https://wa.me/5574999598143"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                />
              </div>
            </div>
          </div>

          {/* Aviso Legal: Racismo é Crime */}
          <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-4 shadow-xl">
            <div className="pb-3 border-b border-[#1A1A1A]">
              <h3 className="font-serif-luxury font-black text-base text-red-500 uppercase tracking-wider flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-red-500" />
                Mensagem Legal: Racismo é Crime (Disque 100)
              </h3>
              <p className="text-xs text-[#888888]">
                Texto obrigatório de conscientização e combate ao racismo exibido em destaque vermelho no rodapé.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Texto do Aviso Legal</label>
                <textarea
                  rows={3}
                  value={footerConfig.legalNoticeText}
                  onChange={(e) => setFooterConfig({ ...footerConfig, legalNoticeText: e.target.value })}
                  className="w-full bg-[#141414] border border-[#333] focus:border-red-500 rounded-xl px-4 py-2.5 text-white outline-none font-medium leading-relaxed"
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">Link de Informações / Denúncia (Opcional)</label>
                <input
                  type="text"
                  value={footerConfig.legalNoticeUrl || ''}
                  onChange={(e) => setFooterConfig({ ...footerConfig, legalNoticeUrl: e.target.value })}
                  placeholder="https://www.gov.br/mdh/pt-br/disque100"
                  className="w-full bg-[#141414] border border-[#333] focus:border-red-500 rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: SEGURANÇA & PAINEL VISÍVEL APENAS PARA O ADMINISTRADOR            */}
      {/* ========================================================================= */}
      {activeTab === 'seguranca' && (
        <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="pb-3 border-b border-[#1A1A1A] flex items-center gap-3">
            <div className="p-3 bg-[#D4AF37]/15 rounded-2xl border border-[#D4AF37]/40 text-[#D4AF37]">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-serif-luxury font-black text-lg text-white uppercase tracking-wider">
                Privacidade & Visibilidade do Painel Administrativo
              </h3>
              <p className="text-xs text-[#888888]">
                Atenda exatamente à sua preferência: tornar o painel de configuração e administração invisível para clientes comuns.
              </p>
            </div>
          </div>

          {/* Toggle Principal de Ocultação */}
          <div className="p-6 bg-[#121212] border-2 border-[#D4AF37]/40 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1 max-w-xl">
              <span className="font-serif-luxury font-black text-white text-base block uppercase">
                Painel Visível Apenas para o Administrador
              </span>
              <p className="text-xs text-[#AAAAAA] leading-relaxed">
                Quando ativado, <strong>NENHUM botão ou link público ("Área do Colaborador", "Painel")</strong> é exibido no rodapé para clientes ou visitantes do site. O site parecerá 100% uma loja comercial padrão para o público em geral.
              </p>
            </div>

            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={hideAdminAccess}
                onChange={(e) => setHideAdminAccess(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-14 h-7 bg-[#333333] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#D4AF37]"></div>
            </label>
          </div>

          {/* Instruções de como o administrador entra */}
          <div className="space-y-4 pt-2">
            <h4 className="font-bold text-white text-sm uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              Como Você (Administrador) Acessa o Painel com Segurança:
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-[#141414] border border-[#262626] rounded-2xl space-y-2">
                <div className="flex items-center gap-2 font-bold text-[#F2D675]">
                  <span className="px-2 py-0.5 bg-[#252525] rounded font-mono text-[10px] text-white">Opção 1</span>
                  <span>Atalho no Teclado</span>
                </div>
                <p className="text-[#888888] leading-relaxed">
                  Pressione <kbd className="px-1.5 py-0.5 bg-black border border-[#444] rounded text-white font-mono">Ctrl</kbd> + <kbd className="px-1.5 py-0.5 bg-black border border-[#444] rounded text-white font-mono">Shift</kbd> + <kbd className="px-1.5 py-0.5 bg-black border border-[#444] rounded text-white font-mono">A</kbd> em qualquer tela do site para abrir imediatamente a tela de senha.
                </p>
              </div>

              <div className="p-4 bg-[#141414] border border-[#262626] rounded-2xl space-y-2">
                <div className="flex items-center gap-2 font-bold text-[#F2D675]">
                  <span className="px-2 py-0.5 bg-[#252525] rounded font-mono text-[10px] text-white">Opção 2</span>
                  <span>3 Toques no Rodapé</span>
                </div>
                <p className="text-[#888888] leading-relaxed">
                  Dê 3 toques/cliques seguidos sobre o texto de direitos autorais (© Mercadinho Aliança) no rodapé para desbloquear a tela de login.
                </p>
              </div>

              <div className="p-4 bg-[#141414] border border-[#262626] rounded-2xl space-y-2">
                <div className="flex items-center gap-2 font-bold text-[#F2D675]">
                  <span className="px-2 py-0.5 bg-[#252525] rounded font-mono text-[10px] text-white">Opção 3</span>
                  <span>Senha Mestre</span>
                </div>
                <p className="text-[#888888] leading-relaxed">
                  A tela de acesso sempre solicita a sua senha mestre (padrão inicial <strong className="text-[#F2D675] font-mono">12345</strong>), impedindo que pessoas não autorizadas vejam os dados.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: PRÉ-VISUALIZAÇÃO AO VIVO                                          */}
      {/* ========================================================================= */}
      {activeTab === 'preview' && (
        <div className="bg-[#050505] border border-[#222222] rounded-3xl p-6 sm:p-8 space-y-8 shadow-2xl">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E1E1E]">
            <div>
              <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
                Pré-visualização
              </span>
              <h3 className="font-serif-luxury font-black text-lg text-white uppercase tracking-wider">
                Como os Clientes Vêem o Rodapé no Site:
              </h3>
            </div>
            <span className="text-[11px] text-[#777] bg-[#141414] px-3 py-1.5 rounded-xl border border-[#222]">
              Atualização em Tempo Real
            </span>
          </div>

          {/* SIMULAÇÃO DO RODAPÉ */}
          <div className="bg-[#080808] border border-[#1C1C1C] rounded-2xl p-6 text-xs text-[#E0E0E0] select-none">
            {/* 3 COLUNAS */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-8">
              <div className="md:col-span-3 space-y-3">
                <h4 className="font-bold text-white text-sm font-serif-luxury uppercase border-b border-[#222] pb-1.5">
                  {footerConfig.atendimentoTitle || 'Atendimento'}
                </h4>
                <ul className="space-y-1.5 text-xs text-[#999]">
                  {footerConfig.atendimentoLinks.filter(l => l.active).map(link => (
                    <li key={link.id} className="hover:text-[#D4AF37] cursor-pointer">
                      {link.label}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="md:col-span-5 space-y-3">
                <h4 className="font-bold text-white text-sm font-serif-luxury uppercase border-b border-[#222] pb-1.5">
                  {footerConfig.institucionalTitle || 'Institucional'}
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <ul className="space-y-1.5 text-xs text-[#999]">
                    {footerConfig.institucionalCol1Links.filter(l => l.active).map(link => (
                      <li key={link.id} className="hover:text-[#D4AF37] cursor-pointer">
                        {link.label}
                      </li>
                    ))}
                  </ul>
                  <ul className="space-y-1.5 text-xs text-[#999]">
                    {footerConfig.institucionalCol2Links.filter(l => l.active).map(link => (
                      <li key={link.id} className="hover:text-[#D4AF37] cursor-pointer">
                        {link.label}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="md:col-span-4 space-y-3">
                <h4 className="font-bold text-white text-sm font-serif-luxury uppercase border-b border-[#222] pb-1.5">
                  {footerConfig.politicasTitle || 'Políticas Mercadinho Aliança'}
                </h4>
                <ul className="space-y-1.5 text-xs text-[#999]">
                  {footerConfig.politicasLinks.filter(l => l.active).map(link => (
                    <li key={link.id} className="hover:text-[#D4AF37] cursor-pointer">
                      {link.label}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <hr className="border-[#1C1C1C] my-4" />

            {/* BANDEIRAS, APP E REDES */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 py-4 items-start">
              <div className="md:col-span-5 space-y-2">
                <h5 className="font-bold text-white text-[11px] uppercase tracking-wider">
                  Formas de pagamento
                </h5>
                <div className="flex flex-wrap gap-2 pt-1">
                  {footerConfig.paymentFlags.map(f => (
                    <span key={f} className="px-2 py-1 bg-[#161616] border border-[#2D2D2D] rounded text-[10px] uppercase font-bold text-[#D4AF37]">
                      {f.replace('_', ' ')}
                    </span>
                  ))}
                </div>
              </div>

              {footerConfig.showAppDownload !== false && (
                <div className="md:col-span-4 space-y-2">
                  <h5 className="font-bold text-white text-[11px] uppercase tracking-wider">
                    {footerConfig.appDownloadTitle}
                  </h5>
                  <div className="flex items-center gap-2 pt-1 text-[11px]">
                    <span className="px-2.5 py-1 bg-black border border-zinc-700 rounded-lg text-white font-bold">
                      Google Play
                    </span>
                    <span className="px-2.5 py-1 bg-black border border-zinc-700 rounded-lg text-white font-bold">
                      App Store
                    </span>
                  </div>
                </div>
              )}

              <div className="md:col-span-3 space-y-2">
                <h5 className="font-bold text-white text-[11px] uppercase tracking-wider">
                  {footerConfig.socialTitle}
                </h5>
                <div className="flex items-center gap-2 pt-1">
                  <div className="w-7 h-7 rounded-full bg-[#E85D04] text-white flex items-center justify-center font-bold text-xs">
                    f
                  </div>
                  <div className="w-7 h-7 rounded-full bg-[#E85D04] text-white flex items-center justify-center font-bold text-xs">
                    ig
                  </div>
                  <div className="w-7 h-7 rounded-full bg-[#E85D04] text-white flex items-center justify-center font-bold text-xs">
                    x
                  </div>
                  <div className="w-7 h-7 rounded-full bg-[#E85D04] text-white flex items-center justify-center font-bold text-xs">
                    yt
                  </div>
                </div>
              </div>
            </div>

            {/* AVISO RACISMO É CRIME */}
            <div className="border-t border-[#1C1C1C] pt-4 pb-2">
              <p className="text-red-500 font-bold text-xs">
                <span className="underline decoration-red-500 font-black">Racismo é crime.</span>{' '}
                {footerConfig.legalNoticeText
                  ? footerConfig.legalNoticeText.replace(/^Racismo é crime\.\s*/i, '')
                  : 'Denuncie. Disque 100 ou procure a Delegacia de Polícia Civil mais próxima ou o Ministério Público.'}
              </p>
            </div>

            {/* COPYRIGHT */}
            <div className="border-t border-[#161616] pt-3 flex items-center justify-between text-[10px] text-[#666]">
              <span>© {new Date().getFullYear()} Mercadinho Aliança LTDA • CNPJ: 12.345.678/0001-90</span>
              <span>
                {hideAdminAccess
                  ? '🔒 Painel Oculto do Público (Apenas Admin)'
                  : '👁️ Link do Painel Visível no Rodapé'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: ADICIONAR / EDITAR LINK                                            */}
      {/* ========================================================================= */}
      {editingModal.isOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#0C0C0C] border border-[#2B2B2B] rounded-3xl p-6 sm:p-8 space-y-5 shadow-2xl relative animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-[#222]">
              <h3 className="font-serif-luxury font-black text-base text-white uppercase tracking-wider flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-[#D4AF37]" />
                {editingModal.isNew ? 'Adicionar Novo Link' : 'Editar Link do Rodapé'}
              </h3>
              <button
                type="button"
                onClick={() => setEditingModal({ ...editingModal, isOpen: false })}
                className="p-1 text-[#888] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Texto do Link (Como aparece para o cliente) *
                </label>
                <input
                  type="text"
                  value={editingModal.link.label}
                  onChange={(e) =>
                    setEditingModal({
                      ...editingModal,
                      link: { ...editingModal.link, label: e.target.value }
                    })
                  }
                  placeholder="Ex: Política de Entregas"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none font-bold"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  Ação ao Clicar *
                </label>
                <select
                  value={editingModal.link.action || 'about'}
                  onChange={(e) =>
                    setEditingModal({
                      ...editingModal,
                      link: { ...editingModal.link, action: e.target.value }
                    })
                  }
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white outline-none cursor-pointer"
                >
                  {actionsList.map(a => (
                    <option key={a.value} value={a.value}>
                      {a.label}
                    </option>
                  ))}
                </select>
              </div>

              {editingModal.link.action === 'custom_url' && (
                <div>
                  <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                    URL Externa (https://...) *
                  </label>
                  <input
                    type="url"
                    value={editingModal.link.url || ''}
                    onChange={(e) =>
                      setEditingModal({
                        ...editingModal,
                        link: { ...editingModal.link, url: e.target.value }
                      })
                    }
                    placeholder="https://exemplo.com.br"
                    className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-2.5 text-white font-mono outline-none"
                  />
                </div>
              )}

              <div className="flex items-center justify-between p-3 bg-[#141414] border border-[#222] rounded-xl">
                <div>
                  <span className="font-bold text-white block">Status do Link</span>
                  <span className="text-[11px] text-[#777]">Visível no rodapé para os clientes</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={editingModal.link.active}
                    onChange={(e) =>
                      setEditingModal({
                        ...editingModal,
                        link: { ...editingModal.link, active: e.target.checked }
                      })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-[#333333] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#D4AF37]"></div>
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#222]">
              <button
                type="button"
                onClick={() => setEditingModal({ ...editingModal, isOpen: false })}
                className="px-4 py-2.5 bg-[#181818] hover:bg-[#252525] text-[#AAA] rounded-xl text-xs font-bold"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveLinkModal}
                className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl cursor-pointer shadow-lg"
              >
                Salvar Link
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
