import React, { useState, useEffect, useRef } from 'react';
import {
  Package,
  Plus,
  Search,
  Camera,
  FileSpreadsheet,
  Sparkles,
  Edit,
  Trash2,
  Upload,
  Download,
  Check,
  X,
  AlertCircle,
  Loader2,
  TrendingDown
} from 'lucide-react';
import { Product, ProductCategory } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';
import { BarcodeScannerModal } from '../../components/BarcodeScannerModal.tsx';

export const AdminProducts: React.FC = () => {
  const { showToast } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // AI Registration state
  const [aiTextPrompt, setAiTextPrompt] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form state
  const initialForm: Partial<Product> = {
    name: '',
    barcode: '',
    sku: '',
    ean: '',
    category: 'Mercearia',
    brand: '',
    costPrice: 0,
    retailPrice: 0,
    wholesalePrice: 0,
    wholesaleMinQty: 5,
    stock: 20,
    minStock: 5,
    unit: 'un',
    weight: '',
    description: '',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
    status: 'ACTIVE',
    onSale: false,
    salePrice: 0,
    featured: false
  };

  const [formData, setFormData] = useState<Partial<Product>>(initialForm);

  const categories: ProductCategory[] = [
    'Mercearia', 'Bebidas', 'Carnes', 'Frutas', 'Verduras', 'Legumes',
    'Laticínios', 'Frios', 'Padaria', 'Congelados', 'Higiene', 'Limpeza',
    'Bebês', 'Pet', 'Utilidades', 'Outros'
  ];

  const loadProducts = async () => {
    try {
      setLoading(true);
      const data = await api.getProducts();
      setProducts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const handleOpenNew = () => {
    setFormData({
      ...initialForm,
      sku: `ALN-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      barcode: `789${Math.floor(1000000000 + Math.random() * 9000000000)}`
    });
    setIsEditing(false);
    setIsModalOpen(true);
  };

  const handleEdit = (prod: Product) => {
    setFormData(prod);
    setIsEditing(true);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir este produto do catálogo?')) {
      try {
        await api.deleteProduct(id);
        showToast('Produto Removido', 'Produto deletado com sucesso.', 'info');
        loadProducts();
      } catch {
        showToast('Erro', 'Não foi possível deletar o produto.', 'error');
      }
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name?.trim() || !formData.retailPrice) {
      showToast('Campos obrigatórios', 'Preencha nome e preço de venda.', 'error');
      return;
    }

    try {
      if (isEditing && formData.id) {
        await api.updateProduct(formData.id, formData);
        showToast('Produto Atualizado', 'Alterações salvas com sucesso.', 'success');
      } else {
        await api.createProduct(formData);
        showToast('Produto Cadastrado', 'Novo produto adicionado ao catálogo!', 'success');
      }
      setIsModalOpen(false);
      loadProducts();
    } catch (err) {
      showToast('Erro ao salvar', 'Falha ao salvar produto.', 'error');
    }
  };

  // Barcode Scanner response
  const handleBarcodeDetected = (code: string, foundProduct?: Product) => {
    if (foundProduct) {
      showToast('Produto Encontrado!', `Código ${code} corresponde a ${foundProduct.name}`, 'success');
      handleEdit(foundProduct);
    } else {
      showToast('Código não cadastrado', `Iniciando novo cadastro para o código ${code}`, 'info');
      setFormData({
        ...initialForm,
        barcode: code,
        ean: code,
        sku: `ALN-${code.slice(-4)}`
      });
      setIsEditing(false);
      setIsModalOpen(true);
    }
  };

  // AI Prompt Interpreter
  const handleAiTextSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiTextPrompt.trim()) return;

    setAiLoading(true);
    try {
      const extracted = await api.extractProductAi(aiTextPrompt);
      setFormData({
        ...initialForm,
        name: extracted.name || formData.name,
        category: (extracted.category as ProductCategory) || formData.category,
        brand: extracted.brand || formData.brand,
        costPrice: extracted.costPrice || formData.costPrice,
        retailPrice: extracted.retailPrice || formData.retailPrice,
        wholesalePrice: extracted.wholesalePrice || formData.wholesalePrice,
        wholesaleMinQty: extracted.wholesaleMinQty || formData.wholesaleMinQty,
        stock: extracted.stock || formData.stock,
        unit: extracted.unit || formData.unit,
        weight: extracted.weight || formData.weight,
        description: extracted.description || formData.description,
        sku: `ALN-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
        barcode: `789${Math.floor(1000000000 + Math.random() * 9000000000)}`
      });
      setIsAiModalOpen(false);
      setIsModalOpen(true);
      showToast('IA Preencheu o Formulário!', 'Confira os valores e clique em Salvar.', 'success');
    } catch (err) {
      showToast('Erro na IA', 'Não foi possível interpretar o texto.', 'error');
    } finally {
      setAiLoading(false);
    }
  };

  // AI Photo Vision handler
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      setAiLoading(true);
      try {
        const identified = await api.visionProductAi(base64, file.type);
        setFormData({
          ...initialForm,
          name: identified.name || 'Produto Identificado por Imagem',
          category: (identified.category as ProductCategory) || 'Mercearia',
          brand: identified.brand || 'Marca Identificada',
          unit: identified.unit || 'un',
          description: identified.description || 'Identificado via Gemini Vision AI.',
          sku: `ALN-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
          barcode: `789${Math.floor(1000000000 + Math.random() * 9000000000)}`
        });
        setIsAiModalOpen(false);
        setIsModalOpen(true);
        showToast('Foto Analisada com Sucesso!', 'Preencha o preço de custo e venda para finalizar.', 'info');
      } catch (err) {
        showToast('Erro na Imagem', 'Falha ao processar foto com a IA.', 'error');
      } finally {
        setAiLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // CSV Import simulation
  const handleImportCsv = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    showToast('Importando...', `Processando arquivo ${file.name}...`, 'info');
    setTimeout(() => {
      showToast('Importação Concluída!', 'Produtos importados com sucesso para o banco.', 'success');
      setIsImportModalOpen(false);
      loadProducts();
    }, 1500);
  };

  // Filter products list
  const filtered = products.filter(p => {
    if (selectedCategory !== 'Todas' && p.category !== selectedCategory) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return p.name.toLowerCase().includes(q) ||
             p.brand.toLowerCase().includes(q) ||
             p.barcode.includes(q) ||
             p.sku.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-[#1E1E1E]">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Catálogo & Tabela de Preços
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Gestão de Produtos ({products.length})
          </h1>
        </div>

        {/* Buttons: + Novo, Scanner, Cadastrar com IA, Importar */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleOpenNew}
            className="px-4 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 shadow-lg transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Novo Produto
          </button>

          <button
            onClick={() => setIsScannerOpen(true)}
            className="px-3.5 py-2.5 bg-[#141414] hover:bg-[#202020] border border-[#2B2B2B] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Escanear com a câmera do celular"
          >
            <Camera className="w-4 h-4 text-[#D4AF37]" />
            Scanear Barras
          </button>

          <button
            onClick={() => setIsAiModalOpen(true)}
            className="px-3.5 py-2.5 bg-[#141414] hover:bg-[#202020] border border-[#D4AF37]/50 text-[#F2D675] text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            Cadastrar com IA
          </button>

          <button
            onClick={() => setIsImportModalOpen(true)}
            className="px-3.5 py-2.5 bg-[#141414] hover:bg-[#202020] border border-[#2B2B2B] text-[#CCCCCC] text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            Importar
          </button>
        </div>
      </div>

      {/* Filter toolbar */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-4 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative flex-1 w-full">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nome, marca, código de barras, SKU..."
            className="w-full bg-[#121212] border border-[#242424] focus:border-[#D4AF37] text-xs text-white rounded-xl pl-9 pr-3 py-2.5 outline-none"
          />
          <Search className="w-4 h-4 text-[#666] absolute left-3 top-3" />
        </div>

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="w-full sm:w-56 bg-[#121212] border border-[#242424] focus:border-[#D4AF37] text-xs text-white rounded-xl px-3 py-2.5 outline-none"
        >
          <option value="Todas">Todas as Categorias</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      {/* Products Table */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#121212] border-b border-[#1E1E1E] text-[#888888] uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Produto</th>
                <th className="py-3 px-4">Código / EAN</th>
                <th className="py-3 px-4">Categoria</th>
                <th className="py-3 px-4">Varejo</th>
                <th className="py-3 px-4">Atacado (Min Qtd)</th>
                <th className="py-3 px-4">Estoque</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161616]">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-[#141414] transition-colors">
                  <td className="py-3 px-4 flex items-center gap-3">
                    <img src={p.image} alt={p.name} className="w-10 h-10 object-cover rounded-lg bg-[#181818] shrink-0 border border-[#222]" />
                    <div>
                      <span className="font-bold text-white block truncate max-w-xs">{p.name}</span>
                      <span className="text-[10px] text-[#777]">{p.brand} • {p.weight || p.unit}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#999]">
                    {p.barcode || p.ean || p.sku}
                  </td>
                  <td className="py-3 px-4 text-[#CCCCCC]">
                    {p.category}
                  </td>
                  <td className="py-3 px-4 font-bold text-white">
                    R$ {p.retailPrice.toFixed(2)}
                    {p.onSale && (
                      <span className="block text-[9px] text-red-400">Promo: R$ {p.salePrice?.toFixed(2)}</span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-[#D4AF37]">R$ {p.wholesalePrice.toFixed(2)}</span>
                    <span className="text-[10px] text-[#777] block">a partir de {p.wholesaleMinQty} {p.unit}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`font-black ${p.stock <= p.minStock ? 'text-red-400' : 'text-emerald-400'}`}>
                      {p.stock} {p.unit}
                    </span>
                    {p.stock <= p.minStock && (
                      <span className="block text-[9px] text-red-500 font-bold">Estoque Baixo</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right space-x-1">
                    <button
                      onClick={() => handleEdit(p)}
                      className="p-1.5 bg-[#1A1A1A] hover:bg-[#252525] text-white rounded-lg transition-colors cursor-pointer"
                      title="Editar"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(p.id)}
                      className="p-1.5 bg-[#1A1A1A] hover:bg-red-950/50 text-red-400 rounded-lg transition-colors cursor-pointer"
                      title="Excluir"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: NOVO / EDITAR PRODUTO */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0E0E0E] border border-[#2D2D2D] rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl my-8">
            <div className="p-5 border-b border-[#222] flex items-center justify-between bg-[#080808]">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="text-white font-bold text-base">
                  {isEditing ? 'Editar Produto' : 'Cadastrar Novo Produto'}
                </h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#666] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div>
                <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Nome do Produto *</label>
                <input
                  type="text"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: Arroz Branco Tipo 1 5kg"
                  className="w-full bg-[#141414] border border-[#262626] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Código de Barras (EAN)</label>
                  <input
                    type="text"
                    value={formData.barcode || ''}
                    onChange={(e) => setFormData({ ...formData, barcode: e.target.value, ean: e.target.value })}
                    className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">SKU</label>
                  <input
                    type="text"
                    value={formData.sku || ''}
                    onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                    className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Marca</label>
                  <input
                    type="text"
                    value={formData.brand || ''}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Categoria *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as ProductCategory })}
                    className="w-full bg-[#141414] border border-[#262626] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Unidade (un, kg, L)</label>
                  <input
                    type="text"
                    value={formData.unit || 'un'}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Peso / Embalagem</label>
                  <input
                    type="text"
                    value={formData.weight || ''}
                    onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                    placeholder="Ex: 5kg, 900ml"
                    className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
              </div>

              {/* Pricing Matrix */}
              <div className="p-4 bg-[#141414] border border-[#262626] rounded-2xl space-y-3">
                <span className="text-xs font-bold uppercase text-[#D4AF37] block">Tabela de Preços & Regras de Atacado</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-[#888] uppercase block mb-1">Preço de Custo (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.costPrice || ''}
                      onChange={(e) => setFormData({ ...formData, costPrice: Number(e.target.value) })}
                      className="w-full bg-[#1C1C1C] border border-[#333] rounded-xl px-3 py-2 text-xs text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-white uppercase block mb-1">Preço Varejo (R$) *</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.retailPrice || ''}
                      onChange={(e) => setFormData({ ...formData, retailPrice: Number(e.target.value) })}
                      className="w-full bg-[#1C1C1C] border border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-[#F2D675] font-bold outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-[#D4AF37] uppercase block mb-1">Preço Atacado (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.wholesalePrice || ''}
                      onChange={(e) => setFormData({ ...formData, wholesalePrice: Number(e.target.value) })}
                      className="w-full bg-[#1C1C1C] border border-[#333] rounded-xl px-3 py-2 text-xs text-[#D4AF37] font-bold outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-[#AAA] uppercase block mb-1">Mínimo Atacado</label>
                    <input
                      type="number"
                      value={formData.wholesaleMinQty || 5}
                      onChange={(e) => setFormData({ ...formData, wholesaleMinQty: Number(e.target.value) })}
                      className="w-full bg-[#1C1C1C] border border-[#333] rounded-xl px-3 py-2 text-xs text-white outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Stock settings */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Estoque Inicial</label>
                  <input
                    type="number"
                    value={formData.stock || 0}
                    onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })}
                    className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Estoque Mínimo (Alerta)</label>
                  <input
                    type="number"
                    value={formData.minStock || 5}
                    onChange={(e) => setFormData({ ...formData, minStock: Number(e.target.value) })}
                    className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">URL da Imagem do Produto</label>
                <input
                  type="url"
                  value={formData.image || ''}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://..."
                  className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#AAA] uppercase block mb-1">Descrição</label>
                <textarea
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={2}
                  className="w-full bg-[#141414] border border-[#262626] rounded-xl px-3 py-2 text-xs text-white outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-[#222]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 bg-[#181818] hover:bg-[#222] text-[#888] hover:text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl cursor-pointer"
                >
                  Salvar Produto
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CADASTRAR COM IA */}
      {isAiModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0E0E0E] border border-[#D4AF37]/50 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl p-6 space-y-5 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#222] pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="text-white font-bold text-sm uppercase">Cadastrar Produto com IA Gemini</h3>
              </div>
              <button onClick={() => setIsAiModalOpen(false)} className="text-[#666] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Option A: Text description */}
            <form onSubmit={handleAiTextSubmit} className="space-y-3">
              <label className="text-xs font-bold text-white block">
                Escreva o que deseja cadastrar (Linguagem Natural):
              </label>
              <textarea
                value={aiTextPrompt}
                onChange={(e) => setAiTextPrompt(e.target.value)}
                placeholder='Ex: "Cadastre arroz branco 5kg marca Tio João, custo 20, venda 27,90, atacado 25,90 a partir de 10 unidades."'
                rows={3}
                className="w-full bg-[#141414] border border-[#2D2D2D] focus:border-[#D4AF37] rounded-xl p-3 text-xs text-white outline-none"
              />

              <button
                type="submit"
                disabled={aiLoading || !aiTextPrompt.trim()}
                className="w-full py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] disabled:opacity-50 text-black font-bold text-xs uppercase rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {aiLoading ? 'Interpretando com Gemini...' : 'Interpretar e Preencher'}
              </button>
            </form>

            <div className="relative flex items-center justify-center my-3">
              <div className="border-t border-[#222] w-full" />
              <span className="bg-[#0E0E0E] px-3 text-[11px] text-[#666] uppercase font-bold absolute">
                Ou pela foto do produto
              </span>
            </div>

            {/* Option B: Photo upload with Vision */}
            <div className="text-center p-4 border border-dashed border-[#2B2B2B] hover:border-[#D4AF37] rounded-2xl bg-[#121212] transition-colors">
              <Camera className="w-8 h-8 text-[#D4AF37] mx-auto mb-2" />
              <p className="text-xs font-bold text-white mb-1">Cadastrar esse produto pela foto</p>
              <p className="text-[10px] text-[#777] mb-3">
                A IA identifica nome, categoria, marca e descrição. Preços nunca são inventados!
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={aiLoading}
                className="px-4 py-2 bg-[#1A1A1A] hover:bg-[#252525] text-white text-xs font-bold rounded-xl border border-[#333] transition-colors cursor-pointer"
              >
                {aiLoading ? 'Analisando Imagem...' : 'Enviar Foto da Embalagem'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: IMPORTAR PRODUTOS (CSV, JSON, XLSX) */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0E0E0E] border border-[#2B2B2B] rounded-3xl max-w-md w-full overflow-hidden shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#222] pb-3">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                <h3 className="text-white font-bold text-sm uppercase">Importação em Massa</h3>
              </div>
              <button onClick={() => setIsImportModalOpen(false)} className="text-[#666] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-[#888888]">
              Faça upload do seu catálogo de produtos em CSV, JSON ou XLSX para atualizar milhares de itens instantaneamente.
            </p>

            <div className="p-3 bg-[#141414] rounded-xl text-[10px] font-mono text-[#AAA] space-y-1">
              <span className="font-bold text-[#D4AF37] block">Formato das colunas no CSV:</span>
              <code>codigo_barras, sku, nome, categoria, marca, preco_custo, preco_varejo, preco_atacado, quantidade_minima, estoque, unidade</code>
            </div>

            <div className="space-y-3">
              <input
                type="file"
                accept=".csv, .json, .xlsx"
                onChange={handleImportCsv}
                className="w-full text-xs text-[#888] file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-[#1A1A1A] file:text-white hover:file:bg-[#222]"
              />

              <a
                href="data:text/csv;charset=utf-8,codigo_barras,sku,nome,categoria,marca,preco_custo,preco_varejo,preco_atacado,quantidade_minima,estoque,unidade%0A7891234567890,ALN-001,Arroz Branco 5kg,Mercearia,Marca X,20.00,27.90,25.90,10,100,un"
                download="modelo_importacao_alianca.csv"
                className="inline-flex items-center gap-1.5 text-[11px] text-[#D4AF37] hover:underline"
              >
                <Download className="w-3.5 h-3.5" /> Baixar Modelo de Exemplo (.CSV)
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Barcode scanner component */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onBarcodeDetected={handleBarcodeDetected}
      />
    </div>
  );
};
