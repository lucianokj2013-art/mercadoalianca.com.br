import React, { useState } from 'react';
import {
  LayoutDashboard,
  Package,
  Layers,
  Boxes,
  ShoppingBag,
  Users,
  Truck,
  CreditCard,
  Tag,
  BarChart3,
  Sparkles,
  Settings,
  ShieldCheck,
  LogOut,
  Menu,
  X,
  ExternalLink,
  ChevronDown,
  Key,
  Lock,
  ArrowRight,
  Eye,
  EyeOff
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import { StaffRole } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';

interface AdminLayoutProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ activeTab, setActiveTab, children }) => {
  const { currentStaffRole, setCurrentStaffRole, navigate, settings, showToast } = useApp();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('alianca_admin_session') === 'true';
  });

  // Login form state
  const [loginMode, setLoginMode] = useState<'master' | 'staff'>('master');
  const [passwordInput, setPasswordInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsVerifying(true);

    try {
      if (loginMode === 'master') {
        const res = await api.verifyAdminMaster(passwordInput);
        if (res.valid) {
          sessionStorage.setItem('alianca_admin_session', 'true');
          setIsAuthenticated(true);
          setCurrentStaffRole('ADMIN');
          showToast('Acesso Autorizado', 'Bem-vindo ao Painel do Mercadinho Aliança!', 'success');
        }
      } else {
        const res = await api.verifyAdminMaster(passwordInput, emailInput);
        if (res.valid) {
          sessionStorage.setItem('alianca_admin_session', 'true');
          setIsAuthenticated(true);
          setCurrentStaffRole(res.role || 'CAIXA');
          showToast('Acesso Autorizado', `Bem-vindo(a), ${res.user?.name || 'Colaborador'}!`, 'success');
        }
      }
    } catch (err: any) {
      setLoginError(err?.message || 'Senha ou credenciais incorretas.');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('alianca_admin_session');
    setIsAuthenticated(false);
    setPasswordInput('');
    setEmailInput('');
    showToast('Sessão Encerrada', 'Painel administrativo bloqueado com segurança.', 'info');
  };

  // If not authenticated, render the lock / login screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#050505] text-[#F5F5F5] flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-[#0B0B0B] border border-[#2B2B2B] rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95">
          {/* Top Gold Accent */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent" />

          {/* Logo & Header */}
          <div className="text-center space-y-3">
            <div className="h-14 w-auto max-w-[210px] mx-auto flex items-center justify-center">
              <img
                src={settings?.logoUrl || '/logo.png'}
                alt="Mercadinho Aliança"
                className="max-h-14 w-auto object-contain"
                onError={(e) => { (e.target as HTMLImageElement).src = '/logo.svg'; }}
              />
            </div>

            <div>
              <span className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-widest block">
                Painel Administrativo & Controle
              </span>
              <h2 className="text-xl sm:text-2xl font-serif-luxury font-black text-white uppercase tracking-wider">
                Acesso Restrito
              </h2>
            </div>
          </div>

          {/* Mode Switcher */}
          <div className="flex bg-[#141414] p-1 rounded-xl border border-[#222] text-xs">
            <button
              type="button"
              onClick={() => {
                setLoginMode('master');
                setLoginError(null);
              }}
              className={`flex-1 py-2 rounded-lg font-bold transition-all cursor-pointer ${
                loginMode === 'master'
                  ? 'bg-[#D4AF37] text-black shadow-md'
                  : 'text-[#888] hover:text-white'
              }`}
            >
              Senha Mestre (12345)
            </button>
            <button
              type="button"
              onClick={() => {
                setLoginMode('staff');
                setLoginError(null);
              }}
              className={`flex-1 py-2 rounded-lg font-bold transition-all cursor-pointer ${
                loginMode === 'staff'
                  ? 'bg-[#D4AF37] text-black shadow-md'
                  : 'text-[#888] hover:text-white'
              }`}
            >
              Colaborador
            </button>
          </div>

          {/* Login Form */}
          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            {loginMode === 'staff' && (
              <div>
                <label className="font-bold text-[#AAAAAA] uppercase block mb-1">
                  E-mail do Colaborador *
                </label>
                <input
                  type="email"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="seu.email@mercadinhoalianca.com.br"
                  className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-white outline-none font-mono"
                  required
                />
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-bold text-[#AAAAAA] uppercase">
                  {loginMode === 'master' ? 'Senha Mestre do Painel *' : 'Senha do Colaborador *'}
                </label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-[11px] text-[#777] hover:text-[#D4AF37] flex items-center gap-1"
                >
                  {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  {showPassword ? 'Ocultar' : 'Exibir'}
                </button>
              </div>

              <input
                type={showPassword ? 'text' : 'password'}
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder={loginMode === 'master' ? 'Digite a senha mestre (Padrão: 12345)' : 'Sua senha'}
                className="w-full bg-[#141414] border border-[#333] focus:border-[#D4AF37] rounded-xl px-4 py-3 text-white font-mono font-bold outline-none text-sm"
                required
              />
            </div>

            {/* Hint for master password */}
            {loginMode === 'master' && (
              <div className="p-3 bg-[#141414] border border-[#292929] rounded-xl text-[11px] text-[#999999] flex items-start gap-2">
                <Key className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>
                  Senha mestre padrão configurada: <strong className="text-[#F2D675] font-mono">12345</strong>. Você pode alterá-la para qualquer senha nas configurações após entrar.
                </span>
              </div>
            )}

            {loginError && (
              <div className="p-3 bg-red-950/40 border border-red-500/40 rounded-xl text-xs text-red-300">
                {loginError}
              </div>
            )}

            <button
              type="submit"
              disabled={isVerifying}
              className="w-full py-3.5 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-black font-black text-xs uppercase tracking-widest rounded-xl transition-all cursor-pointer shadow-xl shadow-[#D4AF37]/20 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isVerifying ? (
                <span>Validando...</span>
              ) : (
                <>
                  <span>Desbloquear Painel</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Back to store */}
          <div className="pt-2 text-center">
            <button
              type="button"
              onClick={() => navigate('home')}
              className="text-xs text-[#777] hover:text-[#D4AF37] transition-colors cursor-pointer"
            >
              ← Voltar para o Supermercado
            </button>
          </div>
        </div>
      </div>
    );
  }

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['ADMIN', 'GERENTE'] },
    { id: 'products', label: 'Produtos', icon: Package, roles: ['ADMIN', 'GERENTE', 'ESTOQUE'] },
    { id: 'inventory', label: 'Estoque & Movimento', icon: Boxes, roles: ['ADMIN', 'GERENTE', 'ESTOQUE'] },
    { id: 'orders', label: 'Pedidos & Separação', icon: ShoppingBag, roles: ['ADMIN', 'GERENTE', 'CAIXA', 'ENTREGA', 'ATENDIMENTO'] },
    { id: 'customers', label: 'Clientes', icon: Users, roles: ['ADMIN', 'GERENTE', 'ATENDIMENTO'] },
    { id: 'delivery', label: 'Delivery & Zonas', icon: Truck, roles: ['ADMIN', 'GERENTE', 'ENTREGA'] },
    { id: 'payments', label: 'Gateways de Pagto', icon: CreditCard, roles: ['ADMIN', 'GERENTE'] },
    { id: 'promotions', label: 'Promoções & Cupons', icon: Tag, roles: ['ADMIN', 'GERENTE'] },
    { id: 'reports', label: 'Relatórios & Lucro', icon: BarChart3, roles: ['ADMIN', 'GERENTE'] },
    { id: 'ai', label: 'Aliança AI Manager', icon: Sparkles, badge: 'IA', roles: ['ADMIN', 'GERENTE', 'ESTOQUE'] },
    { id: 'footer', label: 'Gestão do Rodapé', icon: Layers, roles: ['ADMIN'] },
    { id: 'settings', label: 'Configurações', icon: Settings, roles: ['ADMIN'] },
    { id: 'users', label: 'Equipe & Senhas', icon: ShieldCheck, roles: ['ADMIN'] }
  ];

  const roles: StaffRole[] = ['ADMIN', 'GERENTE', 'ESTOQUE', 'CAIXA', 'ENTREGA', 'ATENDIMENTO'];

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] flex flex-col md:flex-row">
      {/* Mobile Header Bar */}
      <div className="md:hidden bg-[#0A0A0A] border-b border-[#222222] p-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="logo-highlight-badge p-1 bg-[#141414] rounded-xl border border-[#D4AF37]/60 flex items-center">
            <img
              src={settings?.logoUrl || '/logo.png'}
              alt="Mercadinho Aliança"
              className="h-9 w-auto object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = '/logo.svg'; }}
            />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleLogout}
            className="p-2 text-[#888] hover:text-red-400 bg-[#141414] rounded-lg text-xs flex items-center gap-1"
            title="Bloquear Painel"
          >
            <Lock className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
            className="p-2 text-white bg-[#141414] rounded-lg"
          >
            {isMobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* SIDEBAR NAVIGATION */}
      <aside
        className={`fixed md:sticky top-0 left-0 h-screen z-50 w-64 bg-[#0A0A0A] border-r border-[#1C1C1C] flex flex-col justify-between transition-transform duration-300 ${
          isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div>
          {/* Logo & Header */}
          <div className="p-3.5 border-b border-[#1A1A1A] flex items-center justify-between">
            <div className="logo-highlight-badge p-1.5 bg-[#141414] rounded-2xl border border-[#D4AF37]/60 flex items-center w-full justify-center shadow-lg">
              <img
                src={settings?.logoUrl || '/logo.png'}
                alt="Mercadinho Aliança"
                className="h-12 w-auto object-contain"
                onError={(e) => { (e.target as HTMLImageElement).src = '/logo.svg'; }}
              />
            </div>
          </div>

          {/* Role selector switcher (RBAC) */}
          <div className="px-4 py-3 bg-[#0E0E0E] border-b border-[#181818]">
            <label className="text-[10px] text-[#777777] uppercase font-bold tracking-wider block mb-1">
              Perfil Ativo (RBAC):
            </label>
            <select
              value={currentStaffRole}
              onChange={(e) => setCurrentStaffRole(e.target.value as StaffRole)}
              className="w-full bg-[#161616] border border-[#2D2D2D] text-xs font-bold text-[#F2D675] rounded-xl px-2.5 py-1.5 outline-none cursor-pointer"
            >
              {roles.map((r) => (
                <option key={r} value={r} className="bg-[#111111] text-white">
                  {r}
                </option>
              ))}
            </select>
          </div>

          {/* Navigation Links */}
          <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-250px)]">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isAllowed = item.roles.includes(currentStaffRole);
              const isActive = activeTab === item.id;

              if (!isAllowed) return null;

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsMobileSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-[#D4AF37] to-[#C9A227] text-black shadow-lg shadow-[#D4AF37]/15'
                      : 'text-[#AAAAAA] hover:text-white hover:bg-[#141414]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-black ${
                        isActive ? 'bg-black text-[#D4AF37]' : 'bg-[#D4AF37]/20 text-[#F2D675]'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-[#1A1A1A] space-y-2">
          <button
            onClick={() => navigate('home')}
            className="w-full py-2 px-3 bg-[#141414] hover:bg-[#1E1E1E] text-[#CCCCCC] hover:text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-[#262626] transition-colors cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[#D4AF37]" />
            Ver Loja Virtual
          </button>

          <button
            onClick={handleLogout}
            className="w-full py-2 px-3 bg-red-950/20 hover:bg-red-950/40 text-red-400 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-red-500/30 transition-colors cursor-pointer"
            title="Bloquear painel e encerrar sessão"
          >
            <Lock className="w-3.5 h-3.5" />
            Bloquear / Sair
          </button>
        </div>
      </aside>

      {/* MAIN VIEWPORT */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden">
        {children}
      </main>
    </div>
  );
};
