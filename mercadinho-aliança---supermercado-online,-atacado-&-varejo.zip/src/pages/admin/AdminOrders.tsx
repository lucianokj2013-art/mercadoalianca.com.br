import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Clock,
  Printer,
  CheckCircle,
  Truck,
  Package,
  Search,
  Check,
  ChevronRight,
  Filter
} from 'lucide-react';
import { Order, OrderStatus } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';
import { ThermalReceipt } from '../../components/ThermalReceipt.tsx';

export const AdminOrders: React.FC = () => {
  const { settings, showToast } = useApp();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('TODOS');
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const data = await api.getOrders();
      setOrders(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, []);

  const handleUpdateStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      const updated = await api.updateOrderStatus(orderId, newStatus);
      showToast('Status Atualizado', `Pedido ${orderId} alterado para ${newStatus}`, 'success');
      loadOrders();
      if (activeOrder && activeOrder.id === orderId) {
        setActiveOrder(updated);
      }
    } catch {
      showToast('Erro', 'Não foi possível atualizar o status.', 'error');
    }
  };

  const statuses: { id: string; label: string }[] = [
    { id: 'TODOS', label: 'Todos os Pedidos' },
    { id: 'NOVO', label: 'Novos' },
    { id: 'PAGAMENTO_PENDENTE', label: 'Pagamento Pendente' },
    { id: 'PAGO', label: 'Pagos' },
    { id: 'SEPARANDO', label: 'Separando' },
    { id: 'EM_PREPARACAO', label: 'Em Preparação' },
    { id: 'SAIU_PARA_ENTREGA', label: 'Saiu para Entrega' },
    { id: 'ENTREGUE', label: 'Entregues' },
    { id: 'CANCELADO', label: 'Cancelados' }
  ];

  const filtered = orders.filter((o) => {
    if (selectedStatus !== 'TODOS' && o.status !== selectedStatus) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        o.id.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerPhone.includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E1E1E]">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            Operação & Logística
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Gestão de Pedidos ({orders.length})
          </h1>
        </div>
      </div>

      {/* Status Bar Pills */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {statuses.map((s) => {
          const count = s.id === 'TODOS' ? orders.length : orders.filter(o => o.status === s.id).length;
          const isSelected = selectedStatus === s.id;
          return (
            <button
              key={s.id}
              onClick={() => setSelectedStatus(s.id)}
              className={`shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                isSelected
                  ? 'bg-[#D4AF37] text-black shadow-md'
                  : 'bg-[#121212] text-[#888888] hover:text-white border border-[#222222]'
              }`}
            >
              <span>{s.label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-black text-[#D4AF37]' : 'bg-[#1C1C1C] text-[#666]'}`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Orders Grid / Master-Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Orders List */}
        <div className="lg:col-span-6 space-y-3">
          {filtered.length === 0 ? (
            <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-2xl p-8 text-center text-[#777]">
              Nenhum pedido nesta categoria.
            </div>
          ) : (
            filtered.map((o) => {
              const isSelected = activeOrder?.id === o.id;
              return (
                <div
                  key={o.id}
                  onClick={() => setActiveOrder(o)}
                  className={`bg-[#0B0B0B] border rounded-2xl p-4 transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'border-[#D4AF37] shadow-lg shadow-[#D4AF37]/10'
                      : 'border-[#1E1E1E] hover:border-[#333]'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-[#181818]">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs text-[#F2D675]">{o.id}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded font-black bg-[#161616] text-white">
                        {o.status}
                      </span>
                    </div>
                    <span className="text-[11px] text-[#777] font-mono">
                      {new Date(o.createdAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div className="py-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-xs text-white">{o.customerName}</div>
                      <div className="text-[10px] text-[#777]">
                        {o.deliveryType === 'DELIVERY' ? `Entrega em ${o.deliveryAddress?.neighborhood}` : 'Retirada na Loja'}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-serif-luxury font-black text-sm text-[#D4AF37]">
                        R$ {o.total.toFixed(2)}
                      </div>
                      <div className="text-[10px] text-[#888]">{o.items.length} itens</div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Selected Order Detail Pane */}
        <div className="lg:col-span-6">
          {activeOrder ? (
            <div className="bg-[#0B0B0B] border border-[#222222] rounded-3xl p-6 space-y-6 sticky top-24 shadow-2xl">
              {/* Order Header */}
              <div className="flex items-center justify-between pb-4 border-b border-[#1E1E1E]">
                <div>
                  <span className="text-xs text-[#777] font-mono block">Detalhes do Pedido</span>
                  <h3 className="text-lg font-serif-luxury font-black text-white">{activeOrder.id}</h3>
                </div>

                <button
                  onClick={() => setShowReceipt(true)}
                  className="px-3 py-1.5 bg-[#181818] hover:bg-[#222] border border-[#D4AF37]/50 text-[#F2D675] text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" /> Imprimir Comprovante
                </button>
              </div>

              {/* Workflow Action Buttons */}
              <div>
                <span className="text-[10px] uppercase font-bold text-[#888] block mb-2">
                  Ações Rápidas de Separação & Logística:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => handleUpdateStatus(activeOrder.id, 'PAGO')}
                    className="py-2 px-2 bg-[#141414] hover:bg-emerald-950/40 text-emerald-400 font-bold text-[11px] rounded-xl border border-emerald-500/30 transition-colors"
                  >
                    Aceitar / Pago
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(activeOrder.id, 'SEPARANDO')}
                    className="py-2 px-2 bg-[#141414] hover:bg-purple-950/40 text-purple-400 font-bold text-[11px] rounded-xl border border-purple-500/30 transition-colors"
                  >
                    Separar
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(activeOrder.id, 'SAIU_PARA_ENTREGA')}
                    className="py-2 px-2 bg-[#141414] hover:bg-amber-950/40 text-[#F2D675] font-bold text-[11px] rounded-xl border border-[#D4AF37]/40 transition-colors"
                  >
                    Enviar Entrega
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(activeOrder.id, 'ENTREGUE')}
                    className="py-2 px-2 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-[11px] rounded-xl transition-colors"
                  >
                    Concluir
                  </button>
                </div>
              </div>

              {/* Customer & Delivery address */}
              <div className="p-3.5 bg-[#121212] rounded-2xl text-xs space-y-1">
                <div>Cliente: <strong className="text-white">{activeOrder.customerName}</strong></div>
                <div>Telefone: <strong className="text-white">{activeOrder.customerPhone || 'N/A'}</strong></div>
                {activeOrder.deliveryAddress ? (
                  <div>
                    Endereço: {activeOrder.deliveryAddress.street}, {activeOrder.deliveryAddress.number} - {activeOrder.deliveryAddress.neighborhood}, {activeOrder.deliveryAddress.city}
                  </div>
                ) : (
                  <div>Modalidade: <strong className="text-emerald-400">Retirada na Loja física</strong></div>
                )}
                {activeOrder.notes && (
                  <div className="text-[11px] text-[#A0A0A0] pt-1 border-t border-[#1C1C1C]">
                    Observação: {activeOrder.notes}
                  </div>
                )}
              </div>

              {/* Items List */}
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold text-[#888] block">
                  Itens a Separar ({activeOrder.items.length}):
                </span>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {activeOrder.items.map((it, idx) => (
                    <div key={idx} className="p-2.5 bg-[#111] border border-[#1E1E1E] rounded-xl flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img src={it.image} alt={it.productName} className="w-8 h-8 rounded object-cover" />
                        <div className="truncate">
                          <span className="font-bold text-white block truncate">{it.productName}</span>
                          <span className="text-[10px] text-[#777]">
                            {it.isWholesale ? 'Atacado' : 'Varejo'} • R$ {it.unitPrice.toFixed(2)}/{it.unit}
                          </span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-bold text-[#F2D675] font-mono">x{it.quantity}</span>
                        <span className="text-xs text-white block font-bold">R$ {it.subtotal.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Summary */}
              <div className="pt-2 border-t border-[#1C1C1C] flex justify-between items-center text-sm font-black">
                <span>Total a Receber:</span>
                <span className="text-[#F2D675] font-serif-luxury text-lg">
                  R$ {activeOrder.total.toFixed(2)}
                </span>
              </div>
            </div>
          ) : (
            <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-12 text-center text-[#777]">
              Selecione um pedido na lista ao lado para visualizar os detalhes e gerenciar separação.
            </div>
          )}
        </div>
      </div>

      {showReceipt && activeOrder && (
        <ThermalReceipt
          order={activeOrder}
          settings={settings}
          onClose={() => setShowReceipt(false)}
        />
      )}
    </div>
  );
};
