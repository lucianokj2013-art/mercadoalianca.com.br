import React, { useState, useEffect } from 'react';
import { Boxes, Plus, ArrowUpRight, ArrowDownRight, AlertTriangle, RefreshCw } from 'lucide-react';
import { Product, InventoryMovement } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';
import { useApp } from '../../context/AppContext.tsx';

export const AdminInventory: React.FC = () => {
  const { showToast } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [movements, setMovements] = useState<InventoryMovement[]>([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState(10);
  const [type, setType] = useState<'IN' | 'OUT' | 'ADJUST'>('IN');
  const [reason, setReason] = useState('Entrada de mercadoria com Nota Fiscal');

  const load = async () => {
    try {
      const [prods, inv] = await Promise.all([
        api.getProducts(),
        api.getInventory()
      ]);
      setProducts(prods);
      setMovements(inv.movements || []);
      if (prods.length > 0 && !selectedProductId) {
        setSelectedProductId(prods[0].id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleRegisterMovement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || !quantity) return;

    try {
      await api.registerInventoryMovement({
        productId: selectedProductId,
        quantity: type === 'OUT' ? -Math.abs(quantity) : Math.abs(quantity),
        type,
        reason,
        user: 'Administrador'
      });
      showToast('Estoque Atualizado', 'Movimentação registrada com sucesso.', 'success');
      load();
    } catch {
      showToast('Erro', 'Falha ao registrar movimentação.', 'error');
    }
  };

  const lowStock = products.filter(p => p.stock <= p.minStock);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-[#1E1E1E]">
        <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
          Almoxarifado & Reposição
        </span>
        <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
          Controle de Estoque & Movimentações
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Movement Form */}
        <div className="lg:col-span-5 bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 space-y-4 shadow-xl h-fit">
          <h2 className="text-white font-bold text-sm uppercase tracking-wider flex items-center gap-2">
            <Boxes className="w-4 h-4 text-[#D4AF37]" />
            Lançar Movimentação Manual
          </h2>

          <form onSubmit={handleRegisterMovement} className="space-y-3 text-xs">
            <div>
              <label className="font-bold text-[#AAA] uppercase block mb-1">Selecionar Produto</label>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full bg-[#141414] border border-[#2B2B2B] rounded-xl px-3 py-2 text-white outline-none"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} (Atual: {p.stock} {p.unit})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-[#AAA] uppercase block mb-1">Tipo de Movimento</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full bg-[#141414] border border-[#2B2B2B] rounded-xl px-3 py-2 text-white outline-none"
                >
                  <option value="IN">Entrada (+)</option>
                  <option value="OUT">Saída (-)</option>
                  <option value="ADJUST">Ajuste de Balanço</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-[#AAA] uppercase block mb-1">Quantidade</label>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full bg-[#141414] border border-[#2B2B2B] rounded-xl px-3 py-2 text-white outline-none"
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-[#AAA] uppercase block mb-1">Motivo / Justificativa</label>
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Ex: Nota Fiscal 1234, avaria, perda..."
                className="w-full bg-[#141414] border border-[#2B2B2B] rounded-xl px-3 py-2 text-white outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer"
            >
              Confirmar Movimentação
            </button>
          </form>
        </div>

        {/* Low Stock Watchlist */}
        <div className="lg:col-span-7 bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1A1A1A]">
            <h2 className="text-white font-bold text-sm uppercase tracking-wider flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500" />
              Itens em Nível Crítico ({lowStock.length})
            </h2>
            <span className="text-[10px] text-[#777]">Estoque igual ou menor ao mínimo</span>
          </div>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {lowStock.map((p) => (
              <div key={p.id} className="p-3 bg-[#121212] border border-[#242424] rounded-2xl flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <img src={p.image} alt={p.name} className="w-9 h-9 rounded object-cover" />
                  <div>
                    <span className="font-bold text-white block">{p.name}</span>
                    <span className="text-[10px] text-[#777]">{p.category}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-black text-red-400 block">{p.stock} {p.unit}</span>
                  <span className="text-[10px] text-[#777]">Mín: {p.minStock} {p.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Movements Log Table */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-4">
        <h3 className="text-white font-bold text-sm uppercase tracking-wider">
          Histórico Recente de Movimentações
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1E1E1E] text-[#777] uppercase text-[10px]">
                <th className="py-2.5">Data / Hora</th>
                <th className="py-2.5">Produto</th>
                <th className="py-2.5">Tipo</th>
                <th className="py-2.5">Quantidade</th>
                <th className="py-2.5">Motivo</th>
                <th className="py-2.5">Operador</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161616]">
              {movements.map((m) => (
                <tr key={m.id} className="text-white">
                  <td className="py-2 text-[11px] text-[#888] font-mono">
                    {new Date(m.date).toLocaleString('pt-BR')}
                  </td>
                  <td className="py-2 font-bold">{m.productName}</td>
                  <td className="py-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                      m.quantity > 0 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                    }`}>
                      {m.type}
                    </span>
                  </td>
                  <td className={`py-2 font-bold font-mono ${m.quantity > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {m.quantity > 0 ? `+${m.quantity}` : m.quantity}
                  </td>
                  <td className="py-2 text-[11px] text-[#AAA]">{m.reason}</td>
                  <td className="py-2 text-[11px] text-[#777]">{m.user}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
