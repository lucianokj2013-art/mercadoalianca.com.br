import React, { useState, useEffect } from 'react';
import { BarChart3, Download, TrendingUp, DollarSign, Package, FileText } from 'lucide-react';
import { Order, Product } from '../../../shared/types.ts';
import { api } from '../../services/api.ts';

export const AdminReports: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [period, setPeriod] = useState<'today' | 'week' | 'month'>('month');

  useEffect(() => {
    const load = async () => {
      const [ord, prod] = await Promise.all([
        api.getOrders(),
        api.getProducts()
      ]);
      setOrders(ord);
      setProducts(prod);
    };
    load();
  }, []);

  const nonCancelled = orders.filter(o => o.status !== 'CANCELADO');
  const totalRevenue = nonCancelled.reduce((acc, o) => acc + o.total, 0);

  // Estimated gross profit (Revenue minus approximate cost)
  const estimatedCost = totalRevenue * 0.65;
  const estimatedProfit = totalRevenue - estimatedCost;
  const profitMarginPercent = totalRevenue ? Math.round((estimatedProfit / totalRevenue) * 100) : 35;

  const exportCSV = () => {
    const headers = 'ID,Data,Cliente,Itens,Total,Forma_Pagamento,Status\n';
    const rows = orders.map(o =>
      `"${o.id}","${o.createdAt}","${o.customerName}",${o.items.length},${o.total},"${o.paymentMethod}","${o.status}"`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `relatorio_alianca_${period}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E1E1E]">
        <div>
          <span className="text-xs text-[#D4AF37] font-bold uppercase tracking-wider block">
            DRE & Inteligência de Negócio
          </span>
          <h1 className="font-serif-luxury font-black text-2xl sm:text-3xl text-white uppercase tracking-wider">
            Relatórios Financeiros & Lucro Estimado
          </h1>
        </div>

        <button
          onClick={exportCSV}
          className="px-4 py-2.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-black text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
        >
          <Download className="w-4 h-4" /> Exportar Relatório (CSV)
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-2">
          <span className="text-xs text-[#777] font-bold uppercase">Faturamento Bruto</span>
          <div className="font-serif-luxury font-black text-2xl text-white">
            R$ {totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[11px] text-[#A0A0A0]">{nonCancelled.length} pedidos faturados no período</p>
        </div>

        <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-2">
          <span className="text-xs text-[#777] font-bold uppercase">Custo das Mercadorias (CMV)</span>
          <div className="font-serif-luxury font-black text-2xl text-[#888]">
            R$ {estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[11px] text-[#A0A0A0]">Custo médio de aquisição de fornecedores</p>
        </div>

        <div className="bg-[#0B0B0B] border border-[#D4AF37]/40 rounded-3xl p-6 shadow-xl space-y-2">
          <span className="text-xs text-[#F2D675] font-bold uppercase">Lucro Bruto Estimado</span>
          <div className="font-serif-luxury font-black text-2xl text-[#D4AF37]">
            R$ {estimatedProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[11px] text-emerald-400 font-semibold">Margem de Lucro: ~{profitMarginPercent}%</p>
        </div>
      </div>

      {/* Breakdown Table */}
      <div className="bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl p-6 shadow-xl space-y-4">
        <h3 className="text-white font-bold text-sm uppercase tracking-wider">
          Resumo Consolidado por Departamento
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1E1E1E] text-[#777] uppercase text-[10px]">
                <th className="py-2.5">Departamento</th>
                <th className="py-2.5">Qtd Produtos Cadastrados</th>
                <th className="py-2.5">Participação Estimada</th>
                <th className="py-2.5 text-right">Margem Média</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161616]">
              {[
                { cat: 'Mercearia', count: products.filter(p => p.category === 'Mercearia').length, share: '32%', margin: '28%' },
                { cat: 'Carnes & Cortes Nobres', count: products.filter(p => p.category === 'Carnes').length, share: '29%', margin: '35%' },
                { cat: 'Hortifrúti (Frutas/Legumes)', count: products.filter(p => p.category === 'Frutas' || p.category === 'Legumes').length, share: '18%', margin: '42%' },
                { cat: 'Bebidas & Adega', count: products.filter(p => p.category === 'Bebidas').length, share: '12%', margin: '32%' },
                { cat: 'Limpeza & Higiene', count: products.filter(p => p.category === 'Limpeza' || p.category === 'Higiene').length, share: '9%', margin: '30%' }
              ].map((row, idx) => (
                <tr key={idx} className="text-white">
                  <td className="py-3 font-bold">{row.cat}</td>
                  <td className="py-3 text-[#AAA]">{row.count} itens</td>
                  <td className="py-3 text-[#F2D675] font-semibold">{row.share}</td>
                  <td className="py-3 text-right text-emerald-400 font-bold">{row.margin}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
