import {
  Product,
  Order,
  Customer,
  DeliveryZone,
  Coupon,
  StoreSettings,
  StaffUser,
  StaffRole,
  ShoppingList
} from '../../shared/types.ts';

const BASE_URL = '/api';

export const api = {
  // Products
  async getProducts(params?: {
    category?: string;
    search?: string;
    onSale?: boolean;
    wholesale?: boolean;
    barcode?: string;
  }): Promise<Product[]> {
    const query = new URLSearchParams();
    if (params?.category) query.append('category', params.category);
    if (params?.search) query.append('search', params.search);
    if (params?.onSale) query.append('onSale', 'true');
    if (params?.wholesale) query.append('wholesale', 'true');
    if (params?.barcode) query.append('barcode', params.barcode);

    const res = await fetch(`${BASE_URL}/products?${query.toString()}`);
    if (!res.ok) throw new Error('Falha ao carregar produtos');
    return res.json();
  },

  async getProduct(id: string): Promise<Product> {
    const res = await fetch(`${BASE_URL}/products/${id}`);
    if (!res.ok) throw new Error('Produto não encontrado');
    return res.json();
  },

  async createProduct(product: Partial<Product>): Promise<Product> {
    const res = await fetch(`${BASE_URL}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
    });
    if (!res.ok) throw new Error('Falha ao cadastrar produto');
    return res.json();
  },

  async updateProduct(id: string, product: Partial<Product>): Promise<Product> {
    const res = await fetch(`${BASE_URL}/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
    });
    if (!res.ok) throw new Error('Falha ao atualizar produto');
    return res.json();
  },

  async deleteProduct(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`${BASE_URL}/products/${id}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Falha ao remover produto');
    return res.json();
  },

  // Categories
  async getCategories(): Promise<{ name: string; count: number }[]> {
    const res = await fetch(`${BASE_URL}/categories`);
    if (!res.ok) throw new Error('Falha ao carregar categorias');
    return res.json();
  },

  // Orders
  async getOrders(params?: { customerId?: string; status?: string }): Promise<Order[]> {
    const query = new URLSearchParams();
    if (params?.customerId) query.append('customerId', params.customerId);
    if (params?.status) query.append('status', params.status);

    const res = await fetch(`${BASE_URL}/orders?${query.toString()}`);
    if (!res.ok) throw new Error('Falha ao carregar pedidos');
    return res.json();
  },

  async getOrder(id: string): Promise<Order> {
    const res = await fetch(`${BASE_URL}/orders/${id}`);
    if (!res.ok) throw new Error('Pedido não encontrado');
    return res.json();
  },

  async createOrder(order: Partial<Order>): Promise<Order> {
    const res = await fetch(`${BASE_URL}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order)
    });
    if (!res.ok) throw new Error('Falha ao criar pedido');
    return res.json();
  },

  async updateOrderStatus(id: string, status: Order['status'], paymentStatus?: Order['paymentStatus']): Promise<Order> {
    const res = await fetch(`${BASE_URL}/orders/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, paymentStatus })
    });
    if (!res.ok) throw new Error('Falha ao atualizar status do pedido');
    return res.json();
  },

  // Customers
  async getCustomers(): Promise<Customer[]> {
    const res = await fetch(`${BASE_URL}/customers`);
    if (!res.ok) throw new Error('Falha ao carregar clientes');
    return res.json();
  },

  async getCustomer(id: string): Promise<Customer> {
    const res = await fetch(`${BASE_URL}/customers/${id}`);
    if (!res.ok) throw new Error('Cliente não encontrado');
    return res.json();
  },

  async saveCustomer(customer: Partial<Customer>): Promise<Customer> {
    const res = await fetch(`${BASE_URL}/customers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(customer)
    });
    if (!res.ok) throw new Error('Falha ao salvar cliente');
    return res.json();
  },

  // Inventory
  async getInventory(): Promise<any> {
    const res = await fetch(`${BASE_URL}/inventory`);
    if (!res.ok) throw new Error('Falha ao carregar estoque');
    return res.json();
  },

  async registerInventoryMovement(data: {
    productId: string;
    quantity: number;
    type: string;
    reason?: string;
    user?: string;
  }): Promise<any> {
    const res = await fetch(`${BASE_URL}/inventory/movement`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Falha ao registrar movimentação');
    return res.json();
  },

  // Delivery
  async getDeliveryZones(): Promise<DeliveryZone[]> {
    const res = await fetch(`${BASE_URL}/delivery/zones`);
    if (!res.ok) throw new Error('Falha ao carregar zonas de entrega');
    return res.json();
  },

  async saveDeliveryZone(zone: Partial<DeliveryZone>): Promise<DeliveryZone> {
    const res = await fetch(`${BASE_URL}/delivery/zones`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(zone)
    });
    if (!res.ok) throw new Error('Falha ao salvar zona');
    return res.json();
  },

  async deleteDeliveryZone(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`${BASE_URL}/delivery/zones/${id}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Falha ao remover zona de entrega');
    return res.json();
  },

  async getDeliverySlots(): Promise<any> {
    const res = await fetch(`${BASE_URL}/delivery/slots`);
    if (!res.ok) throw new Error('Falha ao carregar horários');
    return res.json();
  },

  // Coupons
  async getCoupons(): Promise<Coupon[]> {
    const res = await fetch(`${BASE_URL}/coupons`);
    if (!res.ok) throw new Error('Falha ao carregar cupons');
    return res.json();
  },

  async saveCoupon(coupon: Partial<Coupon>): Promise<Coupon> {
    const res = await fetch(`${BASE_URL}/coupons`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(coupon)
    });
    if (!res.ok) throw new Error('Falha ao salvar cupom');
    return res.json();
  },

  async validateCoupon(code: string, cartSubtotal: number): Promise<any> {
    const res = await fetch(`${BASE_URL}/coupons/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, cartSubtotal })
    });
    return res.json();
  },

  // Payments
  async getPaymentProviders(): Promise<any[]> {
    const res = await fetch(`${BASE_URL}/payments/providers`);
    if (!res.ok) throw new Error('Falha ao consultar gateways');
    return res.json();
  },

  async processPayment(payload: any): Promise<any> {
    const res = await fetch(`${BASE_URL}/payments/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error('Falha ao processar pagamento');
    return res.json();
  },

  // Settings
  async getSettings(): Promise<StoreSettings> {
    const res = await fetch(`${BASE_URL}/settings`);
    if (!res.ok) throw new Error('Falha ao carregar configurações');
    return res.json();
  },

  async updateSettings(settings: Partial<StoreSettings>): Promise<StoreSettings> {
    const res = await fetch(`${BASE_URL}/settings`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    if (!res.ok) throw new Error('Falha ao atualizar configurações');
    return res.json();
  },

  // Staff
  async getStaff(): Promise<StaffUser[]> {
    const res = await fetch(`${BASE_URL}/staff`);
    if (!res.ok) throw new Error('Falha ao carregar equipe');
    return res.json();
  },

  async createStaff(data: Partial<StaffUser>): Promise<StaffUser> {
    const res = await fetch(`${BASE_URL}/staff`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Falha ao criar colaborador' }));
      throw new Error(err.error || 'Falha ao criar colaborador');
    }
    return res.json();
  },

  async updateStaff(id: string, updates: Partial<StaffUser>): Promise<StaffUser> {
    const res = await fetch(`${BASE_URL}/staff/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Falha ao atualizar colaborador' }));
      throw new Error(err.error || 'Falha ao atualizar colaborador');
    }
    return res.json();
  },

  async deleteStaff(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`${BASE_URL}/staff/${id}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Falha ao remover colaborador');
    return res.json();
  },

  // Master Auth & Password
  async verifyAdminMaster(password: string, email?: string): Promise<{ valid: boolean; role: StaffRole; user?: any; isMaster?: boolean }> {
    const res = await fetch(`${BASE_URL}/admin/verify-master`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password, email })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Senha inválida' }));
      throw new Error(err.error || 'Senha mestre incorreta');
    }
    return res.json();
  },

  async changeMasterPassword(currentPassword: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${BASE_URL}/admin/change-master-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentPassword, newPassword })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Falha ao alterar senha' }));
      throw new Error(err.error || 'Falha ao alterar senha mestre');
    }
    return res.json();
  },

  // AI
  async chatAi(message: string, context: 'customer' | 'admin' = 'customer', history: any[] = []): Promise<any> {
    const res = await fetch(`${BASE_URL}/ai/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, context, history })
    });
    if (!res.ok) throw new Error('Erro na comunicação com a IA');
    return res.json();
  },

  async extractProductAi(prompt: string): Promise<any> {
    const res = await fetch(`${BASE_URL}/ai/extract-product`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt })
    });
    if (!res.ok) throw new Error('Falha ao extrair produto via IA');
    return res.json();
  },

  async visionProductAi(imageBase64: string, mimeType = 'image/jpeg'): Promise<any> {
    const res = await fetch(`${BASE_URL}/ai/vision-product`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageBase64, mimeType })
    });
    if (!res.ok) throw new Error('Falha na análise de imagem via IA');
    return res.json();
  }
};
