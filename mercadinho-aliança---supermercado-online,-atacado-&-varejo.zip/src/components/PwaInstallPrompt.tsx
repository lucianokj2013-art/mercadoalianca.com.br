import React, { useState, useEffect } from 'react';
import { Download, X, Smartphone } from 'lucide-react';

export const PwaInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowPrompt(true);
    };

    window.addEventListener('beforeinstallprompt', handler);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShowPrompt(false);
    }
    setDeferredPrompt(null);
  };

  if (!showPrompt) return null;

  return (
    <div className="fixed bottom-4 left-4 z-40 max-w-sm bg-[#111111] border border-[#D4AF37]/50 rounded-2xl p-4 shadow-2xl shadow-black/80 flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-5">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#050505] border border-[#D4AF37] p-1 flex items-center justify-center shrink-0">
          <Smartphone className="w-5 h-5 text-[#D4AF37]" />
        </div>
        <div>
          <h4 className="text-white font-bold text-xs">Instalar Mercadinho Aliança</h4>
          <p className="text-[10px] text-[#A0A0A0]">Adicione à tela inicial para compras ultra-rápidas.</p>
        </div>
      </div>

      <div className="flex items-center gap-1.5 shrink-0">
        <button
          onClick={handleInstall}
          className="px-3 py-1.5 bg-[#D4AF37] hover:bg-[#F2D675] text-[#050505] font-black text-xs rounded-xl flex items-center gap-1 transition-all"
        >
          <Download className="w-3.5 h-3.5" /> Instalar
        </button>
        <button
          onClick={() => setShowPrompt(false)}
          className="p-1 text-[#666666] hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
