import React, { useState } from 'react';
import {
  MessageCircle,
  Phone,
  Mail,
  MapPin,
  Clock,
  ShieldCheck,
  FileText,
  Lock,
  ExternalLink,
  ChevronRight,
  Smartphone,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { FooterConfig, FooterLink } from '../../shared/types.ts';

export const Footer: React.FC = () => {
  const { navigate, settings, showToast } = useApp();
  const [secretClicks, setSecretClicks] = useState(0);

  const isAdminSession =
    typeof window !== 'undefined' && sessionStorage.getItem('alianca_admin_session') === 'true';

  const hideAdminFromPublic = settings?.hideAdminAccessFromPublic !== false;

  const handleCopyrightClick = () => {
    const next = secretClicks + 1;
    if (next >= 3) {
      setSecretClicks(0);
      navigate('admin');
      showToast('Acesso Restrito', 'Painel Administrativo acionado.', 'info');
    } else {
      setSecretClicks(next);
      if (next === 2) {
        showToast('Atalho de Segurança', 'Mais 1 clique para acessar o painel do administrador.', 'info');
      }
      setTimeout(() => setSecretClicks(0), 3000);
    }
  };

  const cfg: FooterConfig = settings?.footerConfig || {
    atendimentoTitle: 'Atendimento',
    atendimentoLinks: [
      { id: 'at-1', label: 'Meus pedidos', action: 'orders', active: true },
      { id: 'at-2', label: 'Central de atendimento', action: 'sac', active: true },
      { id: 'at-3', label: 'Fale conosco', action: 'contact', active: true }
    ],
    institucionalTitle: 'Institucional',
    institucionalCol1Links: [
      { id: 'inst-1', label: 'Quem somos', action: 'about', active: true },
      { id: 'inst-2', label: 'Nossas lojas', action: 'stores', active: true },
      { id: 'inst-3', label: 'Folhetos', action: 'offers', active: true },
      { id: 'inst-4', label: 'WhatsApp de Ofertas', action: 'whatsapp', active: true },
      { id: 'inst-5', label: 'Trabalhe conosco', action: 'jobs', active: true },
      { id: 'inst-6', label: 'Cartão Aliança', action: 'card', active: true }
    ],
    institucionalCol2Links: [
      { id: 'inst-7', label: 'Aplicativo Meu Aliança', action: 'app', active: true },
      { id: 'inst-8', label: 'Responsabilidade Social', action: 'social', active: true },
      { id: 'inst-9', label: 'Imprensa', action: 'press', active: true },
      { id: 'inst-10', label: 'Blog Aliança', action: 'blog', active: true },
      { id: 'inst-11', label: 'Denúncias', action: 'ethics', active: true }
    ],
    politicasTitle: 'Políticas Mercadinho Aliança',
    politicasLinks: [
      { id: 'pol-1', label: 'Política de Trocas e Devoluções', action: 'refunds', active: true },
      { id: 'pol-2', label: 'Política de Entregas', action: 'delivery', active: true },
      { id: 'pol-3', label: 'Termos e Condições de Uso', action: 'terms', active: true },
      { id: 'pol-4', label: 'Políticas de Privacidade', action: 'privacy', active: true },
      { id: 'pol-5', label: 'Política de Diversidade', action: 'diversity', active: true },
      { id: 'pol-6', label: 'Outras Políticas', action: 'other_policies', active: true }
    ],
    paymentFlags: ['mastercard', 'visa', 'elo', 'hipercard', 'cartao_alianca', 'diners', 'amex', 'pix'],
    appDownloadTitle: 'Baixe o aplicativo Meu Aliança',
    googlePlayUrl: 'https://play.google.com',
    appStoreUrl: 'https://apple.com/app-store',
    socialTitle: 'Acompanhe a gente nas redes sociais',
    socialLinks: {
      facebook: 'https://facebook.com',
      instagram: 'https://instagram.com',
      x: 'https://x.com',
      youtube: 'https://youtube.com',
      linkedin: 'https://linkedin.com',
      whatsapp: 'https://wa.me/5574999598143'
    },
    legalNoticeText:
      'Racismo é crime. Denuncie. Disque 100 ou procure a Delegacia de Polícia Civil mais próxima ou o Ministério Público.',
    legalNoticeUrl: 'https://www.gov.br/mdh/pt-br/disque100'
  };

  const handleLinkClick = (link: FooterLink) => {
    if (link.url && link.url.startsWith('http')) {
      window.open(link.url, '_blank');
      return;
    }

    switch (link.action) {
      case 'orders':
        navigate('orders');
        break;
      case 'about':
        navigate('about');
        break;
      case 'offers':
        navigate('offers');
        break;
      case 'delivery':
        navigate('delivery');
        break;
      case 'terms':
        navigate('terms');
        break;
      case 'privacy':
        navigate('privacy');
        break;
      case 'whatsapp': {
        const phone = settings?.whatsapp || '5574999598143';
        window.open(`https://wa.me/${phone}?text=Olá,%20gostaria%20de%20receber%20os%20folhetos%20e%20ofertas%20do%20Mercadinho%20Aliança!`, '_blank');
        break;
      }
      case 'sac':
      case 'contact': {
        const phone = settings?.phone || '(74) 99959-8143';
        showToast('Central de Atendimento', `Horário: Seg a Sáb das 07h às 22h. Ligue ou envie mensagem: ${phone}`, 'info');
        break;
      }
      case 'stores': {
        const addr = settings?.address || 'Rua Principal, Centro, Bahia';
        showToast('Nossa Loja Física', `Mercadinho Aliança: ${addr}`, 'info');
        break;
      }
      case 'jobs':
        showToast('Trabalhe Conosco', `Envie seu currículo com o cargo pretendido para: ${settings?.email || 'contato@mercadinhoalianca.com.br'}`, 'info');
        break;
      case 'card':
        showToast('Cartão Aliança / Crediário', 'Compre com facilidades exclusivas no crediário Aliança sujeito a aprovação cadastral.', 'info');
        break;
      case 'app':
        showToast('Aplicativo Aliança', 'Em breve disponível nas lojas oficiais Google Play e Apple App Store!', 'info');
        break;
      case 'social':
        showToast('Responsabilidade Social', 'Apoiamos produtores locais e projetos comunitários da nossa região.', 'info');
        break;
      case 'press':
        showToast('Assessoria de Imprensa', `Contato para pautas e imprensa: ${settings?.email || 'contato@mercadinhoalianca.com.br'}`, 'info');
        break;
      case 'blog':
        showToast('Blog Aliança', 'Receitas selecionadas, dicas de churrasco e economia para sua família.', 'info');
        break;
      case 'ethics':
        showToast('Canal de Denúncias & Ética', 'Canal confidencial para clientes e colaboradores: disque 100 ou envie para nossa diretoria.', 'info');
        break;
      case 'refunds':
        showToast('Trocas & Devoluções', 'Trocas garantidas em até 7 dias corridos com nota fiscal do supermercado.', 'info');
        break;
      case 'diversity':
        showToast('Diversidade & Inclusão', 'Valorizamos o respeito mútuo, a equidade e a pluralidade em todos os ambientes.', 'info');
        break;
      case 'other_policies':
        showToast('Políticas Gerais', 'Consulte nossas diretrizes de segurança alimentar, sustentabilidade e compliance.', 'info');
        break;
      default:
        navigate('about');
        break;
    }
  };

  return (
    <footer className="bg-[#050505] border-t border-[#1C1C1C] text-[#E0E0E0] text-xs pt-14 pb-8 transition-colors select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* TOP SECTION: 3 COLUNAS PRINCIPAIS (ATENDIMENTO, INSTITUCIONAL, POLÍTICAS) */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 pb-12">
          {/* COLUNA 1: ATENDIMENTO (3 colunas grid) */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="font-bold text-white text-base tracking-tight font-serif-luxury uppercase border-b border-[#222222] pb-2">
              {cfg.atendimentoTitle || 'Atendimento'}
            </h4>
            <ul className="space-y-2.5">
              {cfg.atendimentoLinks
                .filter(l => l.active)
                .map(link => (
                  <li key={link.id}>
                    <button
                      onClick={() => handleLinkClick(link)}
                      className="text-[#999999] hover:text-[#D4AF37] transition-colors text-xs text-left cursor-pointer flex items-center gap-1.5 hover:translate-x-1 duration-150"
                    >
                      <span>{link.label}</span>
                    </button>
                  </li>
                ))}
            </ul>
          </div>

          {/* COLUNA 2 & 3: INSTITUCIONAL (2 sub-colunas lado a lado - 6 colunas grid) */}
          <div className="md:col-span-5 space-y-4">
            <h4 className="font-bold text-white text-base tracking-tight font-serif-luxury uppercase border-b border-[#222222] pb-2">
              {cfg.institucionalTitle || 'Institucional'}
            </h4>
            <div className="grid grid-cols-2 gap-4">
              {/* Sub-coluna 1 */}
              <ul className="space-y-2.5">
                {cfg.institucionalCol1Links
                  .filter(l => l.active)
                  .map(link => (
                    <li key={link.id}>
                      <button
                        onClick={() => handleLinkClick(link)}
                        className="text-[#999999] hover:text-[#D4AF37] transition-colors text-xs text-left cursor-pointer flex items-center gap-1.5 hover:translate-x-1 duration-150"
                      >
                        <span>{link.label}</span>
                      </button>
                    </li>
                  ))}
              </ul>

              {/* Sub-coluna 2 */}
              <ul className="space-y-2.5">
                {cfg.institucionalCol2Links
                  .filter(l => l.active)
                  .map(link => (
                    <li key={link.id}>
                      <button
                        onClick={() => handleLinkClick(link)}
                        className="text-[#999999] hover:text-[#D4AF37] transition-colors text-xs text-left cursor-pointer flex items-center gap-1.5 hover:translate-x-1 duration-150"
                      >
                        <span>{link.label}</span>
                      </button>
                    </li>
                  ))}
              </ul>
            </div>
          </div>

          {/* COLUNA 4: POLÍTICAS MERCADINHO ALIANÇA (4 colunas grid) */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="font-bold text-white text-base tracking-tight font-serif-luxury uppercase border-b border-[#222222] pb-2">
              {cfg.politicasTitle || 'Políticas Mercadinho Aliança'}
            </h4>
            <ul className="space-y-2.5">
              {cfg.politicasLinks
                .filter(l => l.active)
                .map(link => (
                  <li key={link.id}>
                    <button
                      onClick={() => handleLinkClick(link)}
                      className="text-[#999999] hover:text-[#D4AF37] transition-colors text-xs text-left cursor-pointer flex items-center gap-1.5 hover:translate-x-1 duration-150"
                    >
                      <span>{link.label}</span>
                    </button>
                  </li>
                ))}
            </ul>
          </div>
        </div>

        {/* DIVIDER HORIZONTAL */}
        <hr className="border-[#1E1E1E] my-2" />

        {/* BOTTOM SECTION: 3 BLOCOS (FORMAS DE PAGAMENTO, BAIXE O APLICATIVO, REDES SOCIAIS) */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 py-8 items-start">
          {/* BLOCO 1: FORMAS DE PAGAMENTO COM BANDEIRAS VISUAIS */}
          <div className="md:col-span-5 space-y-3">
            <h5 className="font-bold text-white text-xs uppercase tracking-wider">
              Formas de pagamento
            </h5>
            <div className="flex flex-wrap items-center gap-2 pt-1">
              {/* Mastercard */}
              {(!cfg.paymentFlags || cfg.paymentFlags.includes('mastercard')) && (
                <div
                  className="w-10 h-7 rounded bg-white flex items-center justify-center p-1 shadow-sm border border-zinc-200"
                  title="Mastercard"
                >
                  <div className="relative flex items-center justify-center">
                    <span className="w-3.5 h-3.5 rounded-full bg-[#EB001B] inline-block" />
                    <span className="w-3.5 h-3.5 rounded-full bg-[#F79E1B] inline-block -ml-1.5 opacity-90" />
                  </div>
                </div>
              )}

              {/* Visa */}
              {(!cfg.paymentFlags || cfg.paymentFlags.includes('visa')) && (
                <div
                  className="w-10 h-7 rounded bg-[#1A1F71] flex items-center justify-center p-1 shadow-sm border border-zinc-700"
                  title="Visa"
                >
                  <span className="text-[10px] font-black italic tracking-tighter text-white font-sans">
                    VISA
                  </span>
                </div>
              )}

              {/* Elo */}
              {(!cfg.paymentFlags || cfg.paymentFlags.includes('elo')) && (
                <div
                  className="w-10 h-7 rounded bg-black flex items-center justify-center p-1 shadow-sm border border-zinc-700"
                  title="Elo"
                >
                  <div className="flex items-center gap-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FF0000]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FFE600]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00A4E8]" />
                  </div>
                </div>
              )}

              {/* Hipercard */}
              {(!cfg.paymentFlags || cfg.paymentFlags.includes('hipercard')) && (
                <div
                  className="w-10 h-7 rounded bg-[#B3131B] flex items-center justify-center p-0.5 shadow-sm border border-red-800"
                  title="Hipercard"
                >
                  <span className="text-[8px] font-black italic tracking-tight text-white">
                    Hiper
                  </span>
                </div>
              )}

              {/* Cartão Aliança / Cartão da Casa */}
              {(!cfg.paymentFlags || cfg.paymentFlags.includes('cartao_alianca')) && (
                <div
                  className="w-10 h-7 rounded bg-[#F15A24] flex items-center justify-center p-1 shadow-sm border border-orange-600"
                  title="Cartão Aliança / Crediário"
                >
                  <span className="text-[11px] font-black text-white font-serif-luxury">
                    A
                  </span>
                </div>
              )}

              {/* Diners / Sodexo */}
              {(!cfg.paymentFlags || cfg.paymentFlags.includes('diners')) && (
                <div
                  className="w-10 h-7 rounded bg-[#003B6F] flex items-center justify-center p-1 shadow-sm border border-blue-900"
                  title="Diners Club / Vouchers"
                >
                  <div className="w-3.5 h-3.5 rounded-full border border-white flex items-center justify-center">
                    <span className="w-1.5 h-1.5 bg-white rounded-full" />
                  </div>
                </div>
              )}

              {/* American Express */}
              {(!cfg.paymentFlags || cfg.paymentFlags.includes('amex')) && (
                <div
                  className="w-10 h-7 rounded bg-[#007AC1] flex items-center justify-center p-0.5 shadow-sm border border-sky-700"
                  title="American Express"
                >
                  <span className="text-[7px] font-black tracking-tighter text-white uppercase">
                    AMEX
                  </span>
                </div>
              )}

              {/* PIX */}
              {(!cfg.paymentFlags || cfg.paymentFlags.includes('pix')) && (
                <div
                  className="w-10 h-7 rounded bg-[#32BCAD] flex items-center justify-center p-1 shadow-sm border border-teal-600"
                  title="PIX"
                >
                  <div className="w-3 h-3 rotate-45 border-2 border-white flex items-center justify-center">
                    <div className="w-1 h-1 bg-white" />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* BLOCO 2: BAIXE O APLICATIVO */}
          {cfg.showAppDownload !== false && (
            <div className="md:col-span-4 space-y-3">
              <h5 className="font-bold text-white text-xs uppercase tracking-wider">
                {cfg.appDownloadTitle || 'Baixe o aplicativo Meu Aliança'}
              </h5>
              <div className="flex flex-wrap items-center gap-3 pt-1">
                {/* Google Play Badge */}
                <a
                  href={cfg.googlePlayUrl || 'https://play.google.com'}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 bg-black hover:bg-[#141414] text-white px-3 py-1.5 rounded-lg border border-zinc-700 hover:border-[#D4AF37] transition-all cursor-pointer shadow-sm group"
                  title="Disponível no Google Play"
                >
                  <svg className="w-5 h-5 fill-current text-emerald-400" viewBox="0 0 24 24">
                    <path d="M3.6 1.8c-.3.3-.5.8-.5 1.4v17.6c0 .6.2 1.1.5 1.4l9.5-9.6L3.6 1.8zm11 11.2l2.6 2.6-13 7.5 10.4-10.1zm0-2L4.2.9l13 7.5-2.6 2.6zm1.1 1.1l3.5 2c1 .6 1 1.6 0 2.2l-3.5 2-2.3-2.3 2.3-3.9z"/>
                  </svg>
                  <div className="text-left leading-none">
                    <span className="text-[8px] uppercase tracking-wider block text-zinc-400 group-hover:text-white">
                      Disponível no
                    </span>
                    <span className="text-xs font-bold font-sans">
                      Google Play
                    </span>
                  </div>
                </a>

                {/* App Store Badge */}
                <a
                  href={cfg.appStoreUrl || 'https://apple.com/app-store'}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 bg-black hover:bg-[#141414] text-white px-3 py-1.5 rounded-lg border border-zinc-700 hover:border-[#D4AF37] transition-all cursor-pointer shadow-sm group"
                  title="Baixar na App Store"
                >
                  <svg className="w-5 h-5 fill-current text-white" viewBox="0 0 24 24">
                    <path d="M18.7 19.5c-.8 1.2-1.7 2.4-3 2.5-1.3.1-1.7-.8-3.2-.8-1.5 0-2 .8-3.2.8-1.3-.1-2.2-1.3-3.1-2.5-1.7-2.5-3-7-1.3-10 1-.8 2.6-1.5 4.3-1.5 1.4 0 2.7.9 3.5.9.8 0 2.4-1.1 4.1-.9 1.1.1 3 .6 4.1 2.2-3.6 2-3 6.1.6 7.5zm-4.4-14.7c.6-.8 1.1-1.9 1-3-.9.1-2 .6-2.6 1.4-.6.7-1.1 1.8-1 2.9 1 0 2-.5 2.6-1.3z"/>
                  </svg>
                  <div className="text-left leading-none">
                    <span className="text-[8px] uppercase tracking-wider block text-zinc-400 group-hover:text-white">
                      Baixar na
                    </span>
                    <span className="text-xs font-bold font-sans">
                      App Store
                    </span>
                  </div>
                </a>
              </div>
            </div>
          )}

          {/* BLOCO 3: ACOMPANHE A GENTE NAS REDES SOCIAIS */}
          <div className="md:col-span-3 space-y-3">
            <h5 className="font-bold text-white text-xs uppercase tracking-wider">
              {cfg.socialTitle || 'Acompanhe a gente nas redes sociais'}
            </h5>
            <div className="flex items-center gap-2.5 pt-1">
              {/* Facebook */}
              <a
                href={cfg.socialLinks?.facebook || 'https://facebook.com'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#E85D04] hover:bg-[#F48C06] text-white flex items-center justify-center font-bold text-sm shadow-md transition-all transform hover:scale-110 cursor-pointer"
                title="Facebook"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/>
                </svg>
              </a>

              {/* Instagram */}
              <a
                href={cfg.socialLinks?.instagram || 'https://instagram.com'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#E85D04] hover:bg-[#F48C06] text-white flex items-center justify-center font-bold text-sm shadow-md transition-all transform hover:scale-110 cursor-pointer"
                title="Instagram"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>

              {/* X (Twitter) */}
              <a
                href={cfg.socialLinks?.x || 'https://x.com'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#E85D04] hover:bg-[#F48C06] text-white flex items-center justify-center font-bold text-sm shadow-md transition-all transform hover:scale-110 cursor-pointer"
                title="X (Twitter)"
              >
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>

              {/* YouTube */}
              <a
                href={cfg.socialLinks?.youtube || 'https://youtube.com'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#E85D04] hover:bg-[#F48C06] text-white flex items-center justify-center font-bold text-sm shadow-md transition-all transform hover:scale-110 cursor-pointer"
                title="YouTube"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                </svg>
              </a>

              {/* LinkedIn / WhatsApp */}
              <a
                href={cfg.socialLinks?.whatsapp || `https://wa.me/${settings?.whatsapp || '5574999598143'}`}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#E85D04] hover:bg-[#F48C06] text-white flex items-center justify-center font-bold text-sm shadow-md transition-all transform hover:scale-110 cursor-pointer"
                title="WhatsApp / LinkedIn"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* MENSAGEM LEGAL EXCLUSIVA: RACISMO É CRIME (COMO NA IMAGEM) */}
        <div className="border-t border-[#1C1C1C] pt-6 pb-4">
          <p className="text-red-500 font-bold text-xs sm:text-sm tracking-wide leading-relaxed">
            <span className="underline decoration-red-500 font-black">Racismo é crime.</span>{' '}
            {cfg.legalNoticeText
              ? cfg.legalNoticeText.replace(/^Racismo é crime\.\s*/i, '')
              : 'Denuncie. Disque 100 ou procure a Delegacia de Polícia Civil mais próxima ou o Ministério Público.'}
          </p>
        </div>

        {/* COPYRIGHT & ACESSO RESTRITO AO ADMINISTRADOR */}
        <div className="border-t border-[#161616] pt-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-[#777777]">
          <div
            onClick={handleCopyrightClick}
            className="cursor-pointer select-none hover:text-[#999] transition-colors"
            title="Mercadinho Aliança LTDA (Toque 3 vezes para atalho seguro)"
          >
            © {new Date().getFullYear()} {settings?.storeName || 'Mercadinho Aliança'} LTDA • CNPJ:{' '}
            {settings?.cnpj || '12.345.678/0001-90'} • {settings?.address || 'Centro, Bahia'}
          </div>

          <div className="flex items-center gap-4">
            <span className="text-[#555]">Supermercado Premium & Atacado</span>

            {/* Acesso ao Painel: Exibido APENAS se estiver logado como administrador OU se configurado como visível */}
            {isAdminSession ? (
              <button
                onClick={() => navigate('admin')}
                className="text-[#D4AF37] hover:text-[#F2D675] bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 px-2.5 py-1 rounded-full border border-[#D4AF37]/40 transition-all flex items-center gap-1.5 cursor-pointer font-bold text-[11px] shadow-sm animate-pulse"
                title="Sessão Administrativa Conectada"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Painel Admin (Ativo)</span>
              </button>
            ) : !hideAdminFromPublic ? (
              <button
                onClick={() => navigate('admin')}
                className="text-[#555] hover:text-[#D4AF37] transition-colors flex items-center gap-1 cursor-pointer font-medium"
                title="Acesso exclusivo da Administração e Colaboradores com Senha"
              >
                <Lock className="w-3 h-3" />
                <span>Área do Colaborador</span>
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </footer>
  );
};
