import React, { useState } from 'react';
import {
  Plus,
  Minus,
  Heart,
  TrendingDown,
  Sparkles,
  ShoppingBag,
  Info
} from 'lucide-react';
import { Product } from '../../shared/types.ts';
import { useApp } from '../context/AppContext.tsx';

interface ProductCardProps {
  product: Product;
  onOpenDetails?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onOpenDetails }) => {
  const { cart, addToCart, updateQuantity, toggleFavorite, isFavorite } = useApp();

  const cartItem = cart.find(i => i.product.id === product.id);
  const currentQty = cartItem?.quantity || 0;

  const isFavoriteItem = isFavorite(product.id);

  // Price calculations
  const isWholesaleActive = currentQty >= product.wholesaleMinQty;
  const currentPrice = isWholesaleActive
    ? product.wholesalePrice
    : product.onSale && product.salePrice
    ? product.salePrice
    : product.retailPrice;

  const originalPrice = product.onSale && product.salePrice ? product.retailPrice : undefined;

  // Potential savings per unit in wholesale
  const savingsPerUnit = Math.max(0, product.retailPrice - product.wholesalePrice);
  const wholesaleDiscountPercent = Math.round((savingsPerUnit / product.retailPrice) * 100);

  return (
    <div className="group relative bg-[#0B0B0B] border border-[#1E1E1E] hover:border-[#D4AF37]/50 rounded-2xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-[#D4AF37]/5">
      {/* Top Badges */}
      <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1.5 items-start">
        {product.onSale && (
          <span className="bg-red-500/90 text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md shadow-md backdrop-blur-sm">
            OFERTA
          </span>
        )}
        {wholesaleDiscountPercent > 0 && (
          <span className="bg-[#D4AF37] text-[#050505] text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md shadow-md flex items-center gap-1">
            <TrendingDown className="w-3 h-3" /> -{wholesaleDiscountPercent}% Atacado
          </span>
        )}
        {product.stock <= product.minStock && product.stock > 0 && (
          <span className="bg-amber-600/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
            Últimas {product.stock} un
          </span>
        )}
      </div>

      {/* Favorite Button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          toggleFavorite(product.id);
        }}
        className={`absolute top-2.5 right-2.5 z-10 p-2 rounded-full backdrop-blur-md transition-all ${
          isFavoriteItem
            ? 'bg-red-500/20 text-red-500 border border-red-500/40'
            : 'bg-[#050505]/70 text-[#BDBDBD] hover:text-white border border-[#222222]'
        }`}
        title={isFavoriteItem ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
      >
        <Heart className={`w-4 h-4 ${isFavoriteItem ? 'fill-red-500' : ''}`} />
      </button>

      {/* Product Image */}
      <div
        className="relative w-full h-44 bg-[#141414] overflow-hidden cursor-pointer"
        onClick={() => onOpenDetails && onOpenDetails(product)}
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transform group-hover:scale-108 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B] via-transparent to-transparent opacity-80" />

        {/* Brand & Unit tag */}
        <div className="absolute bottom-2 left-3 flex items-center gap-2">
          <span className="text-[10px] text-[#A0A0A0] font-semibold uppercase tracking-wider bg-[#050505]/80 px-2 py-0.5 rounded border border-[#222222]">
            {product.brand}
          </span>
          {product.weight && (
            <span className="text-[10px] text-[#777777] font-medium bg-[#050505]/80 px-1.5 py-0.5 rounded">
              {product.weight}
            </span>
          )}
        </div>
      </div>

      {/* Details Area */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Category */}
          <div className="text-[11px] text-[#D4AF37] font-semibold mb-1 uppercase tracking-wider">
            {product.category}
          </div>

          {/* Name */}
          <h3
            className="text-white font-bold text-sm line-clamp-2 leading-snug hover:text-[#F2D675] transition-colors cursor-pointer mb-2"
            onClick={() => onOpenDetails && onOpenDetails(product)}
            title={product.name}
          >
            {product.name}
          </h3>
        </div>

        {/* Pricing Matrix: Varejo vs Atacado */}
        <div className="bg-[#121212] border border-[#222222] rounded-xl p-2.5 my-2 space-y-1.5">
          {/* Varejo Price */}
          <div className="flex items-baseline justify-between">
            <span className="text-[10px] uppercase font-bold text-[#888888] tracking-wider">
              Varejo:
            </span>
            <div className="flex items-baseline gap-1.5">
              {originalPrice && (
                <span className="text-[11px] text-[#666666] line-through">
                  R$ {originalPrice.toFixed(2)}
                </span>
              )}
              <span className={`font-black text-sm ${!isWholesaleActive ? 'text-white' : 'text-[#888888]'}`}>
                R$ {(product.onSale && product.salePrice ? product.salePrice : product.retailPrice).toFixed(2)}
              </span>
            </div>
          </div>

          {/* Wholesale Price */}
          <div className={`flex items-baseline justify-between pt-1 border-t border-[#1C1C1C] ${isWholesaleActive ? 'text-[#F2D675]' : ''}`}>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-black tracking-wider text-[#D4AF37] flex items-center gap-1">
                Atacado:
              </span>
              <span className="text-[9px] text-[#777777]">
                A partir de {product.wholesaleMinQty} {product.unit}
              </span>
            </div>
            <div className="text-right">
              <span className="text-sm font-black text-[#D4AF37]">
                R$ {product.wholesalePrice.toFixed(2)}
              </span>
              <span className="text-[9px] text-[#999999] block">
                / {product.unit}
              </span>
            </div>
          </div>

          {/* Wholesale unlocked indicator if user added enough */}
          {isWholesaleActive && (
            <div className="text-[10px] text-emerald-400 font-bold bg-emerald-950/40 border border-emerald-500/30 rounded py-0.5 px-1.5 text-center flex items-center justify-center gap-1">
              <Sparkles className="w-3 h-3" /> Preço de atacado ativado!
            </div>
          )}
        </div>

        {/* Action Button: Add or Quantity Control */}
        <div className="pt-2">
          {currentQty === 0 ? (
            <button
              onClick={() => addToCart(product, 1)}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-[#050505] font-black text-xs uppercase tracking-wider transition-all transform active:scale-98 shadow-md shadow-[#D4AF37]/10 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Adicionar
            </button>
          ) : (
            <div className="flex items-center justify-between bg-[#161616] border border-[#2D2D2D] rounded-xl p-1">
              <button
                onClick={() => updateQuantity(product.id, currentQty - 1)}
                className="w-8 h-8 rounded-lg bg-[#222222] hover:bg-[#333333] text-white flex items-center justify-center transition-colors cursor-pointer"
                title="Diminuir"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>

              <div className="text-center px-2">
                <span className="text-xs font-black text-white">{currentQty}</span>
                <span className="text-[9px] text-[#777777] block font-medium">
                  {product.unit}
                </span>
              </div>

              <button
                onClick={() => updateQuantity(product.id, currentQty + 1)}
                className="w-8 h-8 rounded-lg bg-[#D4AF37] hover:bg-[#F2D675] text-[#050505] font-bold flex items-center justify-center transition-colors cursor-pointer"
                title="Aumentar"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
