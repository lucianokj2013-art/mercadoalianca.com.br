import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  MapPin,
  User,
  Heart,
  Package,
  Menu,
  X,
  Sparkles,
  ShieldCheck,
  TrendingDown,
  Layers,
  Phone,
  MessageCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export const Header: React.FC = () => {
  const {
    currentView,
    navigate,
    cartCount,
    cartSubtotal,
    cartTotalSavings,
    setIsCartOpen,
    favorites,
    currentCustomer,
    settings
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate('products', searchQuery.trim());
      setIsMobileMenuOpen(false);
    }
  };

  const navItems = [
    { id: 'home', label: 'Início' },
    { id: 'products', label: 'Produtos' },
    { id: 'offers', label: 'Ofertas', badge: 'PROMO' },
    { id: 'wholesale', label: 'Atacado', badge: 'ECONOMIZE' },
    { id: 'categories', label: 'Categorias' },
    { id: 'delivery', label: 'Delivery' }
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0B0B0B]/95 backdrop-blur-md border-b border-[#1E1E1E]">
      {/* Top micro bar: notice, contacts, location and fast settings */}
      <div className="bg-[#050505] text-xs text-[#BDBDBD] py-1.5 px-4 border-b border-[#181818]">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1 text-[#D4AF37] font-semibold text-[11px] sm:text-xs">
              <Sparkles className="w-3.5 h-3.5" /> Supermercado Premium & Atacado
            </span>
            <span className="hidden lg:inline text-[#444]">•</span>
            <div className="hidden sm:flex items-center gap-3 text-[11px]">
              <a
                href={`https://wa.me/${settings?.whatsapp || '5574999598143'}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-[#CCCCCC] hover:text-[#D4AF37] transition-colors"
                title="WhatsApp 1"
              >
                <MessageCircle className="w-3 h-3 text-emerald-400" />
                <span className="font-mono font-medium">{settings?.phone || '(74) 99959-8143'}</span>
              </a>
              <span className="text-[#444]">|</span>
              <a
                href={`https://wa.me/${settings?.whatsapp2 || '5574998008283'}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-[#CCCCCC] hover:text-[#D4AF37] transition-colors"
                title="WhatsApp 2"
              >
                <MessageCircle className="w-3 h-3 text-emerald-400" />
                <span className="font-mono font-medium">{settings?.phone2 || '(74) 99800-8283'}</span>
              </a>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('delivery')}
              className="flex items-center gap-1.5 hover:text-[#D4AF37] transition-colors cursor-pointer text-[11px] sm:text-xs"
            >
              <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="truncate max-w-[150px] sm:max-w-xs">
                {settings?.address ? `${settings.neighborhood || 'Centro'}, ${settings.city || 'Bahia'} - ${settings.state || 'BA'}` : 'Centro, Bahia - BA'}
              </span>
            </button>

            {typeof window !== 'undefined' && sessionStorage.getItem('alianca_admin_session') === 'true' && (
              <button
                onClick={() => navigate('admin')}
                className="flex items-center gap-1 text-[#D4AF37] bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 px-2.5 py-0.5 rounded-full border border-[#D4AF37]/40 transition-all font-bold text-[11px] shadow-sm animate-pulse"
                title="Sessão de Administrador Ativa"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Painel Ativo</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* LETREIRO LUMINOSO ANIMADO - MERCADINHO ALIANÇA PASSANDO DE UM LADO PARA O OUTRO */}
      <div className="bg-gradient-to-r from-[#181204] via-[#2D2105] to-[#181204] border-y border-[#D4AF37]/50 py-1.5 overflow-hidden select-none shadow-md">
        <div className="animate-marquee whitespace-nowrap flex items-center gap-10 text-xs font-black uppercase tracking-wider text-[#F2D675]">
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-[#FFD700] font-bold">• O MELHOR PREÇO E ATENDIMENTO DA CIDADE</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-emerald-400 font-bold">• CARNES FRESCAS SELECIONADAS & HORTIFRUTI DO DIA</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-[#F2D675] font-bold">• DELIVERY RÁPIDO: (74) 99959-8143 / (74) 99800-8283</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-sky-300 font-bold">• ECONOMIA NO ATACADO & VAREJO</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-amber-300 font-bold">• PAGAMENTO NO PIX, A PRAZO E DINHEIRO NA ENTREGA</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>

          {/* Duplicate set for seamless continuous loop */}
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-[#FFD700] font-bold">• O MELHOR PREÇO E ATENDIMENTO DA CIDADE</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-emerald-400 font-bold">• CARNES FRESCAS SELECIONADAS & HORTIFRUTI DO DIA</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-[#F2D675] font-bold">• DELIVERY RÁPIDO: (74) 99959-8143 / (74) 99800-8283</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-sky-300 font-bold">• ECONOMIA NO ATACADO & VAREJO</span>
          </span>
          <span className="text-[#D4AF37]">✦</span>
          <span className="flex items-center gap-2">
            <span className="text-[#FF383D] font-black text-sm animate-pulse">★</span>
            <strong className="text-white font-serif-luxury font-black text-sm tracking-widest text-shadow">MERCADINHO ALIANÇA</strong>
            <span className="text-amber-300 font-bold">• PAGAMENTO NO PIX, A PRAZO E DINHEIRO NA ENTREGA</span>
          </span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4 flex items-center justify-between gap-4">
        {/* Brand Logo - Super Destacada */}
        <div
          onClick={() => navigate('home')}
          className="flex items-center gap-3 cursor-pointer select-none group py-0.5"
          title="Mercadinho Aliança - Ir para a Página Inicial"
        >
          <div className="logo-highlight-badge p-1.5 sm:p-2 bg-gradient-to-b from-[#1C1C1C] via-[#101010] to-[#050505] rounded-2xl border-2 border-[#D4AF37] flex items-center justify-center transition-all duration-300 group-hover:scale-105 shadow-xl">
            <img
              src={settings?.logoUrl || '/logo.png'}
              alt="Mercadinho Aliança - Logomarca Oficial"
              className="h-12 sm:h-14 md:h-16 w-auto max-w-[190px] sm:max-w-[240px] md:max-w-[270px] object-contain filter drop-shadow-[0_2px_10px_rgba(255,204,0,0.4)]"
              onError={(e) => {
                // SVG fallback
                (e.target as HTMLImageElement).src = '/logo.svg';
              }}
            />
          </div>
          <div className="hidden lg:flex flex-col">
            <span className="font-serif-luxury font-black text-base lg:text-lg text-white tracking-wider uppercase leading-tight group-hover:text-[#F2D675] transition-colors flex items-center gap-1.5">
              Mercadinho <span className="text-[#D4AF37]">Aliança</span>
            </span>
            <span className="text-[10px] text-[#A0A0A0] font-bold uppercase tracking-widest">
              Supermercado & Atacado
            </span>
          </div>
        </div>

        {/* Search Bar (Desktop) */}
        <form
          onSubmit={handleSearchSubmit}
          className="hidden md:flex flex-1 max-w-xl relative items-center"
        >
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Pesquisar arroz, carnes, bebidas, código de barras..."
            className="w-full bg-[#111111] border border-[#262626] focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37]/50 text-sm text-[#FFFFFF] rounded-xl pl-10 pr-24 py-2.5 outline-none transition-all placeholder:text-[#777777]"
          />
          <Search className="w-4 h-4 text-[#777777] absolute left-3.5 pointer-events-none" />
          <button
            type="submit"
            className="absolute right-1.5 px-4 py-1.5 text-xs font-semibold rounded-lg bg-[#D4AF37] hover:bg-[#F2D675] text-[#050505] transition-colors cursor-pointer"
          >
            Buscar
          </button>
        </form>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Favorites */}
          <button
            onClick={() => navigate('favorites')}
            className="relative p-2 rounded-lg text-[#BDBDBD] hover:text-[#FFFFFF] hover:bg-[#181818] transition-all cursor-pointer hidden sm:block"
            title="Meus Favoritos"
          >
            <Heart className="w-5 h-5" />
            {favorites.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#D4AF37] text-[#050505] font-bold text-[10px] rounded-full flex items-center justify-center">
                {favorites.length}
              </span>
            )}
          </button>

          {/* Orders */}
          <button
            onClick={() => navigate('orders')}
            className="p-2 rounded-lg text-[#BDBDBD] hover:text-[#FFFFFF] hover:bg-[#181818] transition-all cursor-pointer hidden sm:flex items-center gap-1.5 text-xs font-medium"
            title="Meus Pedidos"
          >
            <Package className="w-5 h-5 text-[#D4AF37]" />
            <span className="hidden lg:inline">Pedidos</span>
          </button>

          {/* Account */}
          <button
            onClick={() => navigate('account')}
            className="p-2 rounded-lg text-[#BDBDBD] hover:text-[#FFFFFF] hover:bg-[#181818] transition-all cursor-pointer hidden sm:flex items-center gap-1.5 text-xs font-medium"
            title="Minha Conta"
          >
            <User className="w-5 h-5 text-[#BDBDBD]" />
            <span className="hidden lg:inline">Conta</span>
          </button>

          {/* Cart Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2.5 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-[#050505] font-bold px-3.5 py-2 rounded-xl shadow-lg shadow-[#D4AF37]/20 transition-all cursor-pointer transform active:scale-95"
          >
            <div className="relative">
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#050505] text-[#F2D675] font-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center border border-[#D4AF37]">
                  {cartCount}
                </span>
              )}
            </div>
            <div className="hidden xs:flex flex-col items-start text-left leading-none">
              <span className="text-[10px] uppercase font-semibold text-[#050505]/80">Cesta</span>
              <span className="text-xs font-extrabold text-[#050505]">
                R$ {cartSubtotal.toFixed(2)}
              </span>
            </div>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-[#BDBDBD] hover:text-white md:hidden cursor-pointer"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Search Bar */}
      <div className="px-4 pb-2 md:hidden">
        <form onSubmit={handleSearchSubmit} className="relative flex items-center">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar no Mercadinho Aliança..."
            className="w-full bg-[#111111] border border-[#222222] text-sm text-[#FFFFFF] rounded-xl pl-9 pr-16 py-2 outline-none"
          />
          <Search className="w-4 h-4 text-[#777777] absolute left-3" />
          <button
            type="submit"
            className="absolute right-1 text-xs font-semibold px-3 py-1 bg-[#D4AF37] text-black rounded-lg"
          >
            OK
          </button>
        </form>
      </div>

      {/* Navigation Links Bar (Desktop) */}
      <nav className="hidden md:block bg-[#080808] border-t border-[#181818]">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => navigate(item.id)}
                  className={`relative px-4 py-2.5 text-xs font-semibold tracking-wide transition-all cursor-pointer flex items-center gap-1.5 ${
                    isActive
                      ? 'text-[#F2D675] bg-[#141414] border-b-2 border-[#D4AF37]'
                      : 'text-[#BDBDBD] hover:text-[#FFFFFF] hover:bg-[#111111]'
                  }`}
                >
                  {item.label}
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                        item.badge === 'PROMO'
                          ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                          : 'bg-[#D4AF37]/20 text-[#F2D675] border border-[#D4AF37]/30'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Wholesale Savings Banner info if customer has savings */}
          {cartTotalSavings > 0 && (
            <div className="flex items-center gap-1.5 text-xs text-[#F2D675] bg-[#D4AF37]/10 px-3 py-1 rounded-full border border-[#D4AF37]/30">
              <TrendingDown className="w-3.5 h-3.5" />
              <span>Você está economizando <strong>R$ {cartTotalSavings.toFixed(2)}</strong> no atacado!</span>
            </div>
          )}
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-[#0B0B0B] border-t border-[#222222] px-4 py-4 space-y-2 animate-fadeIn">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                navigate(item.id);
                setIsMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between text-left py-2.5 px-3 rounded-lg text-sm text-[#F5F5F5] hover:bg-[#181818] border border-transparent hover:border-[#333333]"
            >
              <span>{item.label}</span>
              {item.badge && (
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#D4AF37]/20 text-[#F2D675] border border-[#D4AF37]/30 font-bold">
                  {item.badge}
                </span>
              )}
            </button>
          ))}

          <div className="pt-3 border-t border-[#1E1E1E] grid grid-cols-2 gap-2 text-xs font-medium">
            <button
              onClick={() => {
                navigate('orders');
                setIsMobileMenuOpen(false);
              }}
              className="p-2.5 bg-[#141414] rounded-lg text-center text-[#BDBDBD] flex items-center justify-center gap-2"
            >
              <Package className="w-4 h-4 text-[#D4AF37]" /> Meus Pedidos
            </button>
            <button
              onClick={() => {
                navigate('favorites');
                setIsMobileMenuOpen(false);
              }}
              className="p-2.5 bg-[#141414] rounded-lg text-center text-[#BDBDBD] flex items-center justify-center gap-2"
            >
              <Heart className="w-4 h-4 text-red-400" /> Favoritos
            </button>
            <button
              onClick={() => {
                navigate('account');
                setIsMobileMenuOpen(false);
              }}
              className="p-2.5 bg-[#141414] rounded-lg text-center text-[#BDBDBD] flex items-center justify-center gap-2"
            >
              <User className="w-4 h-4" /> Minha Conta
            </button>
            {typeof window !== 'undefined' && sessionStorage.getItem('alianca_admin_session') === 'true' && (
              <button
                onClick={() => {
                  navigate('admin');
                  setIsMobileMenuOpen(false);
                }}
                className="p-2.5 bg-[#D4AF37]/20 border border-[#D4AF37]/40 rounded-lg text-center text-[#F2D675] font-bold flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" /> Painel Admin Ativo
              </button>
            )}
          </div>

          {/* Quick WhatsApp & Call in Mobile Menu */}
          <div className="pt-2 border-t border-[#1A1A1A] space-y-1.5 text-xs">
            <span className="text-[10px] text-[#777] uppercase font-bold tracking-wider block">
              Atendimento Mercadinho Aliança:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <a
                href={`https://wa.me/${settings?.whatsapp || '5574999598143'}`}
                target="_blank"
                rel="noreferrer"
                className="p-2 bg-[#121212] border border-[#262626] rounded-lg text-white font-medium flex items-center justify-center gap-1.5 text-[11px]"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                (74) 99959-8143
              </a>
              <a
                href={`https://wa.me/${settings?.whatsapp2 || '5574998008283'}`}
                target="_blank"
                rel="noreferrer"
                className="p-2 bg-[#121212] border border-[#262626] rounded-lg text-white font-medium flex items-center justify-center gap-1.5 text-[11px]"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                (74) 99800-8283
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
