import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  X,
  Send,
  Bot,
  User,
  ShoppingBag,
  Plus,
  Loader2,
  ChevronRight
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { api } from '../services/api.ts';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  data?: any;
}

export const AiChatWidget: React.FC = () => {
  const { addToCart, cartSubtotal, cartCount, navigate } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      role: 'assistant',
      text: 'Olá! Sou o **Aliança AI**, seu assistente inteligente no Mercadinho Aliança. Posso pesquisar produtos, calcular preços de atacado, sugerir compras para sua família ou churrasco e consultar prazos de entrega. Como posso te ajudar hoje?'
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || input;
    if (!text.trim() || isLoading) return;

    const userMsg: Message = {
      id: `u-${Date.now()}`,
      role: 'user',
      text
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // Build history
      const history = messages.slice(-6).map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        text: m.text
      }));

      const res = await api.chatAi(text, 'customer', history);

      const botMsg: Message = {
        id: `b-${Date.now()}`,
        role: 'assistant',
        text: res.reply || 'Entendido!',
        data: res.data
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          text: 'Desculpe, ocorreu uma instabilidade na conexão com o assistente. Por favor, tente novamente em instantes.'
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickPrompts = [
    'Tem arroz e feijão?',
    'Sugestão para família de 4',
    'Qual a taxa de entrega?',
    'Como funciona o atacado?'
  ];

  return (
    <>
      {/* Floating Toggle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-5 right-5 z-40 flex items-center gap-2.5 bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-[#050505] font-black text-xs uppercase tracking-wider px-4 py-3 rounded-full shadow-2xl shadow-[#D4AF37]/30 transition-all transform hover:scale-105 active:scale-95 cursor-pointer border border-[#F2D675]/40"
        >
          <Sparkles className="w-4 h-4 text-[#050505] animate-pulse" />
          <span>Fale com o Aliança AI</span>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-5 right-5 z-50 w-[92vw] sm:w-[400px] h-[560px] max-h-[85vh] bg-[#0B0B0B] border border-[#2D2D2D] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
          {/* Header */}
          <div className="p-3.5 bg-[#080808] border-b border-[#1E1E1E] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/50 flex items-center justify-center text-[#D4AF37]">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-white font-black text-xs tracking-wider flex items-center gap-1.5 uppercase">
                  Aliança AI Concierge
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                </h3>
                <span className="text-[10px] text-[#777777] block leading-none">
                  Assistente de Compras & Supermercado
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 text-[#777777] hover:text-white rounded-lg hover:bg-[#181818] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages scroll area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.role === 'assistant' && (
                  <div className="w-6 h-6 rounded-full bg-[#181818] border border-[#D4AF37]/40 text-[#D4AF37] flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}

                <div
                  className={`max-w-[82%] rounded-2xl p-3 leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-gradient-to-r from-[#D4AF37] to-[#C9A227] text-[#050505] font-semibold rounded-tr-none'
                      : 'bg-[#141414] border border-[#222222] text-[#F0F0F0] rounded-tl-none'
                  }`}
                >
                  <p className="whitespace-pre-line">{m.text}</p>

                  {/* Render products if returned by search_products function */}
                  {m.data?.products && m.data.products.length > 0 && (
                    <div className="mt-2.5 space-y-1.5 pt-2 border-t border-[#262626]">
                      <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-wider block">
                        Produtos encontrados no catálogo:
                      </span>
                      {m.data.products.map((p: any) => (
                        <div
                          key={p.id}
                          className="bg-[#0A0A0A] p-2 rounded-lg border border-[#222222] flex items-center justify-between gap-2"
                        >
                          <div className="min-w-0">
                            <span className="text-[11px] font-bold text-white block truncate">
                              {p.name}
                            </span>
                            <span className="text-[10px] text-[#A0A0A0]">
                              Varejo: R$ {p.retailPrice?.toFixed(2)} | Atacado: <strong className="text-[#D4AF37]">R$ {p.wholesalePrice?.toFixed(2)}</strong> (a partir de {p.wholesaleMinQty} {p.unit})
                            </span>
                          </div>
                          <button
                            onClick={() => {
                              addToCart(p as any, 1);
                            }}
                            className="p-1.5 bg-[#D4AF37] hover:bg-[#F2D675] text-[#050505] rounded-md font-bold shrink-0 flex items-center gap-1 text-[10px]"
                            title="Adicionar ao carrinho"
                          >
                            <Plus className="w-3 h-3" /> Add
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {m.role === 'user' && (
                  <div className="w-6 h-6 rounded-full bg-[#D4AF37] text-black flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-2.5 items-center text-xs text-[#888888] pl-2">
                <Loader2 className="w-4 h-4 animate-spin text-[#D4AF37]" />
                <span>Aliança AI está consultando o sistema...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts */}
          <div className="px-3 py-2 bg-[#090909] border-t border-[#1C1C1C] flex gap-1.5 overflow-x-auto no-scrollbar">
            {quickPrompts.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(p)}
                className="shrink-0 text-[10px] text-[#BDBDBD] hover:text-white bg-[#141414] hover:bg-[#202020] border border-[#242424] px-2.5 py-1 rounded-full transition-all cursor-pointer"
              >
                {p}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 bg-[#080808] border-t border-[#1E1E1E] flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Digite sua dúvida ou pedido..."
              className="flex-1 bg-[#121212] border border-[#262626] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs text-white outline-none"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="px-3.5 py-2 bg-[#D4AF37] hover:bg-[#F2D675] disabled:opacity-50 text-black rounded-xl font-bold flex items-center justify-center transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
