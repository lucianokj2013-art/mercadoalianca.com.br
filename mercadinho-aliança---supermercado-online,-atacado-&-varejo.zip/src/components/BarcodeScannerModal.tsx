import React, { useState, useEffect, useRef } from 'react';
import { Camera, X, Check, Search, AlertCircle, RefreshCw } from 'lucide-react';
import { api } from '../services/api.ts';
import { Product } from '../../shared/types.ts';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBarcodeDetected: (barcode: string, product?: Product) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onBarcodeDetected
}) => {
  const [manualCode, setManualCode] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [statusText, setStatusText] = useState('Aponte a câmera para o código de barras');
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    startCamera();

    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    setIsScanning(true);
    setStatusText('Iniciando câmera...');

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Câmera não suportada neste navegador.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setStatusText('Posicione o código de barras dentro da área destacada');
      }
    } catch (err: any) {
      console.warn('Camera access note:', err);
      setCameraError('Permissão da câmera necessária para escanear.');
      setIsScanning(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setIsScanning(false);
  };

  const handleLookupBarcode = async (code: string) => {
    try {
      setStatusText(`Consultando código ${code}...`);
      const results = await api.getProducts({ barcode: code });
      const foundProduct = results.length > 0 ? results[0] : undefined;
      onBarcodeDetected(code, foundProduct);
      onClose();
    } catch {
      onBarcodeDetected(code);
      onClose();
    }
  };

  // Sample quick barcodes for quick demo testing
  const demoBarcodes = [
    { label: 'Arroz 5kg', code: '7891000100012' },
    { label: 'Feijão 1kg', code: '7891000200021' },
    { label: 'Contra Filé', code: '7891001000103' },
    { label: 'Papel Neve', code: '7891002100211' }
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0E0E0E] border border-[#2A2A2A] rounded-2xl max-w-md w-full overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-[#222222] flex items-center justify-between bg-[#080808]">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37]">
              <Camera className="w-4 h-4" />
            </div>
            <h3 className="text-white font-bold text-sm">Scanner de Código de Barras</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#777777] hover:text-white rounded-lg hover:bg-[#1C1C1C]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video / Camera Viewport */}
        <div className="relative w-full h-64 bg-black flex items-center justify-center overflow-hidden">
          {cameraError ? (
            <div className="text-center p-6 text-[#888888] space-y-2">
              <AlertCircle className="w-10 h-10 text-amber-500 mx-auto" />
              <p className="text-xs text-white font-semibold">{cameraError}</p>
              <p className="text-[11px] text-[#777777]">
                Você pode digitar ou selecionar um código de barras abaixo para testar instantaneamente.
              </p>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                playsInline
                muted
              />
              {/* Laser line overlay */}
              <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
                <div className="w-56 h-36 border-2 border-[#D4AF37] rounded-xl relative shadow-[0_0_15px_rgba(212,175,55,0.4)]">
                  <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-red-500 animate-pulse shadow-[0_0_8px_#ef4444]" />
                </div>
              </div>
            </>
          )}

          {/* Status pill */}
          <div className="absolute bottom-3 left-4 right-4 text-center">
            <span className="bg-[#050505]/90 border border-[#2D2D2D] text-[11px] text-[#D4AF37] font-semibold px-3 py-1 rounded-full shadow-lg">
              {statusText}
            </span>
          </div>
        </div>

        {/* Manual Input & Simulation */}
        <div className="p-4 bg-[#121212] space-y-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (manualCode.trim()) handleLookupBarcode(manualCode.trim());
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              placeholder="Digite o código (ex: 7891000100012)"
              className="flex-1 bg-[#1A1A1A] border border-[#2F2F2F] text-xs text-white rounded-xl px-3 py-2 outline-none focus:border-[#D4AF37]"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-[#D4AF37] hover:bg-[#F2D675] text-black text-xs font-bold rounded-xl transition-colors"
            >
              Buscar
            </button>
          </form>

          {/* Quick simulation buttons */}
          <div>
            <span className="text-[10px] text-[#777777] uppercase font-bold tracking-wider block mb-1.5">
              Simular leitura de produtos em estoque:
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {demoBarcodes.map((b) => (
                <button
                  key={b.code}
                  onClick={() => handleLookupBarcode(b.code)}
                  className="text-left text-[11px] bg-[#181818] hover:bg-[#242424] hover:border-[#D4AF37] border border-[#252525] p-2 rounded-lg text-white transition-all flex items-center justify-between"
                >
                  <span className="truncate">{b.label}</span>
                  <span className="text-[9px] text-[#D4AF37] font-mono">{b.code.slice(-5)}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
