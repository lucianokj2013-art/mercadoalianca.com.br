import React from 'react';
import { Order, StoreSettings } from '../../shared/types.ts';
import { Printer, X } from 'lucide-react';

interface ThermalReceiptProps {
  order: Order;
  settings: StoreSettings | null;
  onClose?: () => void;
}

export const ThermalReceipt: React.FC<ThermalReceiptProps> = ({ order, settings, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const formattedDate = new Date(order.createdAt).toLocaleString('pt-BR');

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#111111] border border-[#2D2D2D] rounded-2xl max-w-md w-full overflow-hidden shadow-2xl flex flex-col">
        {/* Modal Controls */}
        <div className="p-4 border-b border-[#222222] flex items-center justify-between no-print">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Printer className="w-4 h-4 text-[#D4AF37]" />
            <span>Comprovante Térmico (80mm)</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-[#D4AF37] hover:bg-[#F2D675] text-black font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" /> Imprimir
            </button>
            {onClose && (
              <button
                onClick={onClose}
                className="p-1.5 text-[#777777] hover:text-white rounded-lg hover:bg-[#222222]"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Thermal Print Area */}
        <div className="p-6 bg-white text-black font-mono text-xs overflow-y-auto max-h-[75vh]" id="thermal-receipt">
          {/* Logo & Header */}
          <div className="text-center border-b border-dashed border-black pb-3 mb-3">
            <img
              src={settings?.logoUrl || '/logo.png'}
              alt="Mercadinho Aliança"
              className="h-14 w-auto max-w-[180px] mx-auto object-contain mb-1 filter grayscale contrast-200"
              onError={(e) => { (e.target as HTMLImageElement).src = '/logo.svg'; }}
            />
            <div className="font-bold text-sm tracking-wider">MERCADINHO ALIANÇA</div>
            <div className="text-[10px] text-gray-700">SUPERMERCADO PREMIUM & ATACADO</div>
            <div className="text-[10px] text-gray-700">CNPJ: {settings?.cnpj || '12.345.678/0001-90'}</div>
            <div className="text-[10px] text-gray-700">{settings?.address ? `${settings.address}${settings.streetNumber ? `, ${settings.streetNumber}` : ''} - ${settings.neighborhood || 'Centro'}, ${settings.city || 'Bahia'} - ${settings.state || 'BA'}` : 'Rua Principal, 100 - Centro, Bahia - BA'}</div>
            <div className="text-[10px] text-gray-700">TEL: {settings?.phone || '(74) 99959-8143'}{settings?.phone2 ? ` | ${settings.phone2}` : ' | (74) 99800-8283'}</div>
          </div>

          {/* Order Meta */}
          <div className="border-b border-dashed border-black pb-2 mb-2 text-[11px]">
            <div className="flex justify-between font-bold">
              <span>PEDIDO: {order.id}</span>
              <span>{order.status}</span>
            </div>
            <div>DATA: {formattedDate}</div>
            <div>CLIENTE: {order.customerName}</div>
            <div>TEL: {order.customerPhone || 'N/A'}</div>
            {order.customerCpf && <div>CPF: {order.customerCpf}</div>}
            <div className="mt-1 font-semibold uppercase">
              MODALIDADE: {order.deliveryType === 'DELIVERY' ? 'ENTREGA EM DOMICÍLIO' : 'RETIRADA NA LOJA'}
            </div>
            {order.deliveryAddress && (
              <div className="text-[10px] text-gray-800 mt-0.5">
                END: {order.deliveryAddress.street}, {order.deliveryAddress.number}
                {order.deliveryAddress.complement ? ` - ${order.deliveryAddress.complement}` : ''}
                <br />
                BAIRRO: {order.deliveryAddress.neighborhood} - {order.deliveryAddress.city}/{order.deliveryAddress.state}
              </div>
            )}
          </div>

          {/* Items Header */}
          <div className="border-b border-black pb-1 mb-1 font-bold text-[10px] flex justify-between">
            <span className="w-1/2">ITEM / DESCRIÇÃO</span>
            <span className="w-1/4 text-center">QTD x PREÇO</span>
            <span className="w-1/4 text-right">TOTAL</span>
          </div>

          {/* Item Rows */}
          <div className="space-y-1.5 border-b border-dashed border-black pb-2 mb-2 text-[10px]">
            {order.items.map((item, idx) => (
              <div key={idx} className="flex justify-between items-start">
                <div className="w-1/2 leading-tight">
                  <span className="font-semibold">{item.productName}</span>
                  {item.isWholesale && (
                    <span className="block text-[9px] text-gray-600 font-bold">[ATACADO]</span>
                  )}
                </div>
                <div className="w-1/4 text-center">
                  {item.quantity} {item.unit} x {item.unitPrice.toFixed(2)}
                </div>
                <div className="w-1/4 text-right font-bold">
                  R$ {item.subtotal.toFixed(2)}
                </div>
              </div>
            ))}
          </div>

          {/* Financial Totals */}
          <div className="space-y-1 text-[11px] border-b border-dashed border-black pb-2 mb-2">
            <div className="flex justify-between">
              <span>SUBTOTAL:</span>
              <span>R$ {order.subtotal.toFixed(2)}</span>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between font-bold">
                <span>DESCONTO:</span>
                <span>- R$ {order.discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>TAXA DE ENTREGA:</span>
              <span>{order.shippingFee === 0 ? 'GRÁTIS' : `R$ ${order.shippingFee.toFixed(2)}`}</span>
            </div>
            {order.totalSavings > 0 && (
              <div className="flex justify-between text-[10px] font-semibold text-gray-700">
                <span>ECONOMIA ATACADO:</span>
                <span>- R$ {order.totalSavings.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-sm pt-1 border-t border-black">
              <span>VALOR TOTAL:</span>
              <span>R$ {order.total.toFixed(2)}</span>
            </div>
          </div>

          {/* Payment Details */}
          <div className="border-b border-dashed border-black pb-2 mb-2 text-[10px] space-y-0.5">
            <div>
              FORMA PAGTO:{' '}
              <span className="font-bold">
                {order.paymentMethod === 'A_PRAZO'
                  ? 'A PRAZO (SUJEITO A APROVAÇÃO)'
                  : order.paymentMethod === 'CASH'
                  ? 'EM DINHEIRO NA ENTREGA'
                  : order.paymentMethod === 'BANK_TRANSFER'
                  ? 'TRANSFERÊNCIA BANCÁRIA'
                  : order.paymentMethod === 'DELIVERY_CARD'
                  ? 'CARTÃO NA MAQUININHA'
                  : order.paymentMethod === 'CREDIT_CARD'
                  ? 'CARTÃO CRÉDITO ONLINE'
                  : order.paymentMethod}
              </span>
            </div>
            <div>STATUS PAGTO: <span className="font-bold">{order.paymentStatus}</span></div>
            {order.notes && (
              <div className="text-[9px] text-gray-700 italic pt-0.5">
                OBS: {order.notes}
              </div>
            )}
          </div>

          {/* Barcode & Footer Note */}
          <div className="text-center pt-2">
            <div className="inline-block tracking-widest font-bold text-xs py-1 px-3 bg-gray-100 border border-gray-300 rounded mb-1">
              * {order.id.replace('#', '')} *
            </div>
            <div className="text-[9px] text-gray-600">
              OBRIGADO PELA PREFERÊNCIA!
              <br />
              VOLTE SEMPRE AO MERCADINHO ALIANÇA
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
