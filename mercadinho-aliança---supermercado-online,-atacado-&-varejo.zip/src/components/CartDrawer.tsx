import React, { useState } from 'react';
import {
  X,
  Plus,
  Minus,
  Trash2,
  ArrowRight,
  TrendingDown,
  Sparkles,
  ShoppingBag,
  Tag,
  Truck
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    orderItems,
    cartSubtotal,
    cartTotalSavings,
    couponDiscount,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    selectedDeliveryFee,
    cartFinalTotal,
    updateQuantity,
    removeFromCart,
    clearCart,
    navigate,
    settings
  } = useApp();

  const [couponInput, setCouponInput] = useState('');
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false);

  if (!isCartOpen) return null;

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    setIsApplyingCoupon(true);
    await applyCoupon(couponInput.trim().toUpperCase());
    setIsApplyingCoupon(false);
  };

  const freeShippingThreshold = settings?.freeShippingThreshold || 180;
  const freeShippingProgress = Math.min(100, Math.round((cartSubtotal / freeShippingThreshold) * 100));
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - cartSubtotal);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0B0B0B] border-l border-[#222222] shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-4 border-b border-[#1E1E1E] flex items-center justify-between bg-[#080808]">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-white font-black text-base uppercase tracking-wider">
                  Sua Cesta de Compras
                </h2>
                <span className="text-[11px] text-[#777777]">
                  {orderItems.length} {orderItems.length === 1 ? 'item diferente' : 'itens diferentes'}
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsCartOpen(false)}
              className="p-2 text-[#777777] hover:text-white rounded-lg hover:bg-[#181818] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Tracker */}
          <div className="px-4 py-2.5 bg-[#121212] border-b border-[#1C1C1C]">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-[#BDBDBD] flex items-center gap-1.5 font-medium">
                <Truck className="w-3.5 h-3.5 text-[#D4AF37]" />
                {remainingForFreeShipping > 0
                  ? `Adicione mais R$ ${remainingForFreeShipping.toFixed(2)} para Frete Grátis`
                  : 'Parabéns! Você ganhou Frete Grátis 🎉'}
              </span>
              <span className="font-bold text-[#F2D675]">{freeShippingProgress}%</span>
            </div>
            <div className="w-full h-1.5 bg-[#222222] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#D4AF37] to-[#F2D675] transition-all duration-500 rounded-full"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Wholesale Savings Banner */}
          {cartTotalSavings > 0 && (
            <div className="mx-4 mt-3 p-3 bg-gradient-to-r from-[#D4AF37]/20 via-[#D4AF37]/10 to-transparent border border-[#D4AF37]/40 rounded-xl flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#D4AF37] text-black">
                <TrendingDown className="w-4 h-4 font-black" />
              </div>
              <div>
                <div className="text-xs font-black text-[#F2D675]">
                  Economia no Atacado: R$ {cartTotalSavings.toFixed(2)}
                </div>
                <div className="text-[10px] text-[#A0A0A0]">
                  Você desbloqueou preços de atacado em itens da sua cesta!
                </div>
              </div>
            </div>
          )}

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {orderItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-[#777777]">
                <div className="w-16 h-16 rounded-full bg-[#141414] border border-[#222222] flex items-center justify-center mb-3 text-[#444444]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <p className="text-white font-bold text-sm mb-1">Sua cesta está vazia</p>
                <p className="text-xs text-[#888888] max-w-xs mb-4">
                  Explore nossas ofertas do dia e aproveite os preços especiais no atacado e varejo!
                </p>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    navigate('products');
                  }}
                  className="px-4 py-2 bg-[#D4AF37] hover:bg-[#F2D675] text-black text-xs font-black uppercase tracking-wider rounded-xl transition-all"
                >
                  Ver Produtos
                </button>
              </div>
            ) : (
              orderItems.map((item) => {
                const prod = cart.find(c => c.product.id === item.productId)?.product;
                const neededForWholesale = prod ? Math.max(0, prod.wholesaleMinQty - item.quantity) : 0;

                return (
                  <div
                    key={item.productId}
                    className="p-3 bg-[#111111] border border-[#1E1E1E] rounded-xl flex gap-3 relative group"
                  >
                    {/* Item Image */}
                    <img
                      src={item.image}
                      alt={item.productName}
                      className="w-16 h-16 object-cover rounded-lg bg-[#181818] shrink-0 border border-[#222222]"
                    />

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-white font-bold text-xs truncate" title={item.productName}>
                          {item.productName}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.productId)}
                          className="text-[#666666] hover:text-red-400 transition-colors p-1"
                          title="Remover produto"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Pricing Tag */}
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-bold text-[#D4AF37]">
                          R$ {item.unitPrice.toFixed(2)}
                        </span>
                        <span className="text-[10px] text-[#777777]">
                          /{item.unit}
                        </span>

                        {item.isWholesale ? (
                          <span className="text-[9px] px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded font-bold uppercase">
                            Atacado
                          </span>
                        ) : (
                          <span className="text-[9px] px-1.5 py-0.2 bg-[#222222] text-[#888888] rounded uppercase">
                            Varejo
                          </span>
                        )}
                      </div>

                      {/* Progress to Wholesale if not achieved yet */}
                      {!item.isWholesale && prod && neededForWholesale > 0 && (
                        <div className="text-[10px] text-[#A0A0A0] mt-1">
                          + {neededForWholesale} un para pagar <strong>R$ {prod.wholesalePrice.toFixed(2)}</strong> (atacado)
                        </div>
                      )}

                      {/* Quantity Selector & Subtotal */}
                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#1C1C1C]">
                        <div className="flex items-center bg-[#1A1A1A] border border-[#282828] rounded-lg p-0.5">
                          <button
                            onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                            className="w-6 h-6 flex items-center justify-center text-[#BDBDBD] hover:text-white rounded hover:bg-[#252525]"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-bold text-white px-2.5">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                            className="w-6 h-6 flex items-center justify-center text-black bg-[#D4AF37] hover:bg-[#F2D675] rounded font-bold"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="text-right">
                          <span className="text-xs font-black text-white">
                            R$ {item.subtotal.toFixed(2)}
                          </span>
                          {item.savings > 0 && (
                            <span className="text-[10px] text-emerald-400 block font-medium">
                              - R$ {item.savings.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer & Checkout button */}
          {orderItems.length > 0 && (
            <div className="p-4 border-t border-[#1E1E1E] bg-[#080808] space-y-3">
              {/* Coupon Form */}
              {appliedCoupon ? (
                <div className="flex items-center justify-between bg-[#151515] border border-emerald-500/30 px-3 py-2 rounded-xl text-xs">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <Tag className="w-3.5 h-3.5" />
                    Cupom: {appliedCoupon.code} (- R$ {couponDiscount.toFixed(2)})
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="text-[#777777] hover:text-red-400 text-xs underline cursor-pointer"
                  >
                    Remover
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      placeholder="CUPOM (ex: BEMVINDO10)"
                      className="w-full bg-[#111111] border border-[#242424] focus:border-[#D4AF37] rounded-xl px-3 py-2 text-xs uppercase text-white outline-none"
                    />
                    <Tag className="w-3.5 h-3.5 text-[#555555] absolute right-3 top-2.5 pointer-events-none" />
                  </div>
                  <button
                    type="submit"
                    disabled={isApplyingCoupon}
                    className="px-3 py-2 bg-[#222222] hover:bg-[#D4AF37] hover:text-black text-[#D4AF37] text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    {isApplyingCoupon ? '...' : 'Aplicar'}
                  </button>
                </form>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-[#BDBDBD] pt-1">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-white">R$ {cartSubtotal.toFixed(2)}</span>
                </div>

                {couponDiscount > 0 && (
                  <div className="flex justify-between text-emerald-400 font-semibold">
                    <span>Desconto do Cupom:</span>
                    <span>- R$ {couponDiscount.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Taxa de Entrega:</span>
                  <span className="font-semibold text-white">
                    {selectedDeliveryFee === 0 ? (
                      <span className="text-emerald-400 font-bold">GRÁTIS</span>
                    ) : (
                      `R$ ${selectedDeliveryFee.toFixed(2)}`
                    )}
                  </span>
                </div>

                <div className="flex justify-between text-base font-black text-white pt-2 border-t border-[#1C1C1C]">
                  <span>Total do Pedido:</span>
                  <span className="text-[#F2D675] font-serif-luxury text-lg">
                    R$ {cartFinalTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    navigate('cart');
                  }}
                  className="w-full py-2.5 rounded-xl border border-[#2D2D2D] hover:bg-[#161616] text-[#BDBDBD] hover:text-white font-bold text-xs uppercase tracking-wider transition-colors text-center cursor-pointer"
                >
                  Ver Carrinho
                </button>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    navigate('checkout');
                  }}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#C9A227] hover:from-[#F2D675] hover:to-[#D4AF37] text-[#050505] font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-[#D4AF37]/20 cursor-pointer"
                >
                  Finalizar
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
