import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  CartItem,
  OrderItem,
  Customer,
  StoreSettings,
  StaffRole,
  Coupon,
  Address
} from '../../shared/types.ts';
import { api } from '../services/api.ts';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info' | 'wholesale';
  title: string;
  message: string;
}

interface AppContextType {
  // Navigation
  currentView: string;
  navigate: (view: string, param?: string) => void;
  viewParam?: string;

  // Cart
  cart: CartItem[];
  cartCount: number;
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;

  // Cart Calculations
  orderItems: OrderItem[];
  cartSubtotal: number;
  cartTotalSavings: number;
  appliedCoupon: Coupon | null;
  couponDiscount: number;
  applyCoupon: (code: string) => Promise<{ success: boolean; message: string }>;
  removeCoupon: () => void;
  selectedDeliveryFee: number;
  setSelectedDeliveryFee: (fee: number) => void;
  cartFinalTotal: number;

  // Customer & Auth
  currentCustomer: Customer;
  updateCustomerProfile: (data: Partial<Customer>) => void;
  saveNewAddress: (addr: Address) => void;

  // Staff & Admin
  currentStaffRole: StaffRole;
  setCurrentStaffRole: (role: StaffRole) => void;

  // Favorites
  favorites: string[]; // productIds
  toggleFavorite: (productId: string) => void;
  isFavorite: (productId: string) => boolean;

  // Settings
  settings: StoreSettings | null;
  refreshSettings: () => Promise<void>;

  // Toasts
  toasts: Toast[];
  showToast: (title: string, message: string, type?: Toast['type']) => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const defaultDemoCustomer: Customer = {
  id: 'cust-demo',
  name: 'Cliente Aliança VIP',
  cpf: '111.222.333-44',
  phone: '(74) 99959-8143',
  whatsapp: '5574999598143',
  email: 'cliente@alianca.com.br',
  birthDate: '1990-05-15',
  addresses: [
    {
      id: 'addr-demo-1',
      street: 'Rua Principal',
      number: '100',
      complement: 'Casa 02',
      neighborhood: 'Centro',
      city: 'Bahia',
      state: 'BA',
      cep: '48900-000',
      reference: 'Próximo à Praça Central',
      isDefault: true
    }
  ],
  createdAt: '2026-01-10T10:00:00Z'
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<string>('home');
  const [viewParam, setViewParam] = useState<string | undefined>(undefined);

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('alianca_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponDiscount, setCouponDiscount] = useState<number>(0);
  const [selectedDeliveryFee, setSelectedDeliveryFee] = useState<number>(5.00);

  const [currentCustomer, setCurrentCustomer] = useState<Customer>(() => {
    try {
      const saved = localStorage.getItem('alianca_customer');
      return saved ? JSON.parse(saved) : defaultDemoCustomer;
    } catch {
      return defaultDemoCustomer;
    }
  });

  const [currentStaffRole, setCurrentStaffRole] = useState<StaffRole>('ADMIN');

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('alianca_favorites');
      return saved ? JSON.parse(saved) : ['prod-001', 'prod-010', 'prod-008'];
    } catch {
      return ['prod-001', 'prod-010', 'prod-008'];
    }
  });

  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Load Settings
  const refreshSettings = async () => {
    try {
      const data = await api.getSettings();
      setSettings(data);
    } catch (err) {
      console.warn('Failed to load store settings:', err);
    }
  };

  useEffect(() => {
    refreshSettings();
  }, []);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('alianca_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('alianca_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('alianca_customer', JSON.stringify(currentCustomer));
  }, [currentCustomer]);

  // Navigate helper
  const navigate = (view: string, param?: string) => {
    setCurrentView(view);
    setViewParam(param);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Toast notifications
  const showToast = (title: string, message: string, type: Toast['type'] = 'info') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      dismissToast(id);
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Add to cart with wholesale trigger detection
  const addToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      const newQty = existing ? existing.quantity + quantity : quantity;

      // Check if product hit wholesale threshold
      const reachedWholesaleNow = newQty >= product.wholesaleMinQty && (!existing || existing.quantity < product.wholesaleMinQty);

      if (reachedWholesaleNow) {
        showToast(
          '🎉 Você atingiu o preço de atacado!',
          `${product.name} agora sai por R$ ${product.wholesalePrice.toFixed(2)} cada!`,
          'wholesale'
        );
      } else {
        showToast('Produto adicionado', `${product.name} foi adicionado ao carrinho.`, 'success');
      }

      if (existing) {
        return prev.map(item =>
          item.product.id === product.id ? { ...item, quantity: newQty } : item
        );
      }
      return [...prev, { product, quantity: newQty }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
    showToast('Item removido', 'Produto retirado do carrinho.', 'info');
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }

    setCart(prev => {
      const item = prev.find(i => i.product.id === productId);
      if (item) {
        const hitWholesale = quantity >= item.product.wholesaleMinQty && item.quantity < item.product.wholesaleMinQty;
        if (hitWholesale) {
          showToast(
            '🎉 Você atingiu o preço de atacado!',
            `${item.product.name} com desconto de atacado ativado!`,
            'wholesale'
          );
        }
      }
      return prev.map(i => (i.product.id === productId ? { ...i, quantity } : i));
    });
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
    setCouponDiscount(0);
  };

  // Order Items with Wholesale logic
  const orderItems: OrderItem[] = cart.map(({ product, quantity }) => {
    const isWholesale = quantity >= product.wholesaleMinQty;
    const baseRetail = product.onSale && product.salePrice ? product.salePrice : product.retailPrice;
    const effectiveUnitPrice = isWholesale ? product.wholesalePrice : baseRetail;
    const subtotal = Number((effectiveUnitPrice * quantity).toFixed(2));
    const originalSubtotal = Number((product.retailPrice * quantity).toFixed(2));
    const savings = Math.max(0, Number((originalSubtotal - subtotal).toFixed(2)));

    return {
      productId: product.id,
      productName: product.name,
      image: product.image,
      unit: product.unit,
      quantity,
      unitPrice: effectiveUnitPrice,
      isWholesale,
      subtotal,
      originalSubtotal,
      savings
    };
  });

  const cartSubtotal = Number(orderItems.reduce((acc, item) => acc + item.subtotal, 0).toFixed(2));
  const cartTotalSavings = Number(orderItems.reduce((acc, item) => acc + item.savings, 0).toFixed(2));
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Apply Coupon
  const applyCoupon = async (code: string) => {
    try {
      const res = await api.validateCoupon(code, cartSubtotal);
      if (res.valid) {
        setAppliedCoupon(res.coupon);
        setCouponDiscount(res.discountAmount);
        showToast('Cupom aplicado', res.message, 'success');
        return { success: true, message: res.message };
      } else {
        showToast('Cupom inválido', res.message, 'error');
        return { success: false, message: res.message };
      }
    } catch (err: any) {
      showToast('Erro no cupom', 'Falha ao validar cupom.', 'error');
      return { success: false, message: 'Erro ao validar cupom.' };
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponDiscount(0);
    showToast('Cupom removido', 'O desconto foi desfeito.', 'info');
  };

  // Check free shipping threshold
  const freeShipping = settings?.freeShippingThreshold ? cartSubtotal >= settings.freeShippingThreshold : false;
  const effectiveDeliveryFee = freeShipping ? 0 : selectedDeliveryFee;

  const cartFinalTotal = Number(
    Math.max(0, cartSubtotal - couponDiscount + effectiveDeliveryFee).toFixed(2)
  );

  // Favorites
  const toggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Favoritos', 'Item removido dos seus favoritos.', 'info');
        return prev.filter(id => id !== productId);
      } else {
        showToast('Favoritos', 'Item salvo na sua lista de favoritos!', 'success');
        return [...prev, productId];
      }
    });
  };

  const isFavorite = (productId: string) => favorites.includes(productId);

  // Customer Profile
  const updateCustomerProfile = (data: Partial<Customer>) => {
    setCurrentCustomer(prev => ({ ...prev, ...data }));
    showToast('Conta atualizada', 'Seus dados foram salvos com sucesso.', 'success');
  };

  const saveNewAddress = (addr: Address) => {
    setCurrentCustomer(prev => {
      const updatedAddresses = addr.isDefault
        ? prev.addresses.map(a => ({ ...a, isDefault: false }))
        : [...prev.addresses];

      const existsIdx = updatedAddresses.findIndex(a => a.id === addr.id);
      if (existsIdx >= 0) {
        updatedAddresses[existsIdx] = addr;
      } else {
        updatedAddresses.push({ ...addr, id: addr.id || `addr-${Date.now()}` });
      }

      return { ...prev, addresses: updatedAddresses };
    });
    showToast('Endereço salvo', 'Novo endereço cadastrado para entregas.', 'success');
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        navigate,
        viewParam,
        cart,
        cartCount,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        orderItems,
        cartSubtotal,
        cartTotalSavings,
        appliedCoupon,
        couponDiscount,
        applyCoupon,
        removeCoupon,
        selectedDeliveryFee: effectiveDeliveryFee,
        setSelectedDeliveryFee,
        cartFinalTotal,
        currentCustomer,
        updateCustomerProfile,
        saveNewAddress,
        currentStaffRole,
        setCurrentStaffRole,
        favorites,
        toggleFavorite,
        isFavorite,
        settings,
        refreshSettings,
        toasts,
        showToast,
        dismissToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
