import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Header } from './components/Header.tsx';
import { Footer } from './components/Footer.tsx';
import { CartDrawer } from './components/CartDrawer.tsx';
import { AiChatWidget } from './components/AiChatWidget.tsx';
import { PwaInstallPrompt } from './components/PwaInstallPrompt.tsx';

// Client Pages
import { Home } from './pages/Home.tsx';
import { ProductsPage } from './pages/ProductsPage.tsx';
import { OffersPage } from './pages/OffersPage.tsx';
import { WholesalePage } from './pages/WholesalePage.tsx';
import { CheckoutPage } from './pages/CheckoutPage.tsx';
import { OrdersPage } from './pages/OrdersPage.tsx';
import { DeliveryPage } from './pages/DeliveryPage.tsx';
import { FavoritesPage } from './pages/FavoritesPage.tsx';
import { ShoppingListsPage } from './pages/ShoppingListsPage.tsx';
import { AccountPage } from './pages/AccountPage.tsx';
import { AboutTermsPages } from './pages/AboutTermsPages.tsx';

// Admin Pages
import { AdminLayout } from './pages/admin/AdminLayout.tsx';
import { AdminDashboard } from './pages/admin/AdminDashboard.tsx';
import { AdminProducts } from './pages/admin/AdminProducts.tsx';
import { AdminInventory } from './pages/admin/AdminInventory.tsx';
import { AdminOrders } from './pages/admin/AdminOrders.tsx';
import { AdminAiManager } from './pages/admin/AdminAiManager.tsx';
import { AdminPayments } from './pages/admin/AdminPayments.tsx';
import { AdminPromotions } from './pages/admin/AdminPromotions.tsx';
import { AdminReports } from './pages/admin/AdminReports.tsx';
import { AdminSettings } from './pages/admin/AdminSettings.tsx';
import { AdminUsers } from './pages/admin/AdminUsers.tsx';
import { AdminDelivery } from './pages/admin/AdminDelivery.tsx';
import { AdminFooter } from './pages/admin/AdminFooter.tsx';

const MainContent: React.FC = () => {
  const { currentView, navigate, toasts, dismissToast } = useApp();
  const [adminTab, setAdminTab] = useState('dashboard');

  const isAdmin = currentView === 'admin';

  // Global secret shortcut for administrator: Ctrl + Shift + A (or Cmd + Shift + A)
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        navigate('admin');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [navigate]);

  return (
    <div className="flex flex-col min-h-screen bg-[#050505] text-[#F5F5F5] selection:bg-[#D4AF37]/30 selection:text-[#F2D675]">
      {/* Toast Notifications */}
      <div className="fixed top-5 right-5 z-50 flex flex-col gap-2 pointer-events-none max-w-sm w-full">
        {toasts.map((t) => (
          <div
            key={t.id}
            onClick={() => dismissToast(t.id)}
            className={`pointer-events-auto p-4 rounded-2xl border shadow-2xl backdrop-blur-md cursor-pointer transition-all duration-300 animate-in fade-in slide-in-from-top-3 ${
              t.type === 'wholesale'
                ? 'bg-[#181508]/95 border-[#D4AF37] text-white'
                : t.type === 'success'
                ? 'bg-[#0A160F]/95 border-emerald-500/40 text-white'
                : t.type === 'error'
                ? 'bg-[#1A0A0A]/95 border-red-500/40 text-white'
                : 'bg-[#111111]/95 border-[#2A2A2A] text-white'
            }`}
          >
            <div className="font-bold text-xs flex items-center justify-between">
              <span className={t.type === 'wholesale' ? 'text-[#F2D675]' : ''}>{t.title}</span>
              <span className="text-[10px] text-[#666]">fechar</span>
            </div>
            <div className="text-xs text-[#BDBDBD] mt-0.5 leading-snug">{t.message}</div>
          </div>
        ))}
      </div>

      {/* Render Customer Header if not in Admin */}
      {!isAdmin && <Header />}

      {/* Views Router */}
      <main className="flex-1">
        {isAdmin ? (
          <AdminLayout activeTab={adminTab} setActiveTab={setAdminTab}>
            {adminTab === 'dashboard' && <AdminDashboard onNavigateToTab={setAdminTab} />}
            {adminTab === 'products' && <AdminProducts />}
            {adminTab === 'inventory' && <AdminInventory />}
            {adminTab === 'orders' && <AdminOrders />}
            {adminTab === 'ai' && <AdminAiManager />}
            {adminTab === 'payments' && <AdminPayments />}
            {adminTab === 'promotions' && <AdminPromotions />}
            {adminTab === 'reports' && <AdminReports />}
            {adminTab === 'settings' && <AdminSettings />}
            {adminTab === 'footer' && <AdminFooter />}
            {adminTab === 'users' && <AdminUsers />}
            {adminTab === 'customers' && (
              <div className="p-6 bg-[#0B0B0B] border border-[#1E1E1E] rounded-3xl space-y-4">
                <h2 className="text-white font-serif-luxury font-black text-xl uppercase">Base de Clientes</h2>
                <p className="text-xs text-[#888]">Visualização e controle de contas de clientes cadastrados.</p>
                <div className="p-4 bg-[#141414] rounded-2xl text-xs text-white">
                  <strong>Cliente Aliança VIP:</strong> cliente@alianca.com.br • (74) 99959-8143 • CPF 111.222.333-44
                </div>
              </div>
            )}
            {adminTab === 'delivery' && <AdminDelivery />}
          </AdminLayout>
        ) : (
          <>
            {currentView === 'home' && <Home />}
            {currentView === 'products' && <ProductsPage />}
            {currentView === 'categories' && <ProductsPage />}
            {currentView === 'offers' && <OffersPage />}
            {currentView === 'wholesale' && <WholesalePage />}
            {currentView === 'cart' && <CheckoutPage />}
            {currentView === 'checkout' && <CheckoutPage />}
            {currentView === 'orders' && <OrdersPage />}
            {currentView === 'delivery' && <DeliveryPage />}
            {currentView === 'favorites' && <FavoritesPage />}
            {currentView === 'lists' && <ShoppingListsPage />}
            {currentView === 'account' && <AccountPage />}
            {currentView === 'about' && <AboutTermsPages view="about" />}
            {currentView === 'terms' && <AboutTermsPages view="terms" />}
            {currentView === 'privacy' && <AboutTermsPages view="privacy" />}
          </>
        )}
      </main>

      {/* Customer Footer, Cart Drawer & PWA prompt */}
      {!isAdmin && <Footer />}
      <CartDrawer />
      <AiChatWidget />
      <PwaInstallPrompt />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
