export type ProductCategory =
  | 'Mercearia'
  | 'Bebidas'
  | 'Carnes'
  | 'Frutas'
  | 'Verduras'
  | 'Legumes'
  | 'Laticínios'
  | 'Frios'
  | 'Padaria'
  | 'Congelados'
  | 'Higiene'
  | 'Limpeza'
  | 'Bebês'
  | 'Pet'
  | 'Utilidades'
  | 'Outros';

export interface Product {
  id: string;
  name: string;
  sku: string;
  ean: string;
  barcode: string;
  category: ProductCategory;
  brand: string;
  description: string;
  image: string;
  weight?: string;
  unit: string; // 'un', 'kg', 'g', 'L', 'ml', 'pct', 'cx'
  stock: number;
  minStock: number;
  costPrice: number;
  retailPrice: number;
  wholesalePrice: number;
  wholesaleMinQty: number;
  status: 'ACTIVE' | 'INACTIVE';
  onSale: boolean;
  salePrice?: number;
  saleStartDate?: string;
  saleEndDate?: string;
  featured?: boolean;
}

export interface OrderItem {
  productId: string;
  productName: string;
  image: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  isWholesale: boolean;
  subtotal: number;
  originalSubtotal: number;
  savings: number;
}

export type OrderStatus =
  | 'NOVO'
  | 'PAGAMENTO_PENDENTE'
  | 'PAGO'
  | 'SEPARANDO'
  | 'EM_PREPARACAO'
  | 'SAIU_PARA_ENTREGA'
  | 'ENTREGUE'
  | 'CANCELADO';

export type PaymentMethod =
  | 'PIX'
  | 'CREDIT_CARD'
  | 'DEBIT_CARD'
  | 'BOLETO'
  | 'CASH'
  | 'DELIVERY_CARD'
  | 'A_PRAZO'
  | 'BANK_TRANSFER'
  | 'OTHER';

export type DeliveryType = 'DELIVERY' | 'PICKUP';

export interface Address {
  id: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  cep: string;
  reference?: string;
  isDefault?: boolean;
}

export interface Customer {
  id: string;
  name: string;
  cpf: string;
  phone: string;
  whatsapp: string;
  email: string;
  birthDate?: string;
  addresses: Address[];
  createdAt: string;
}

export interface Order {
  id: string; // e.g. #ALN-000001
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerCpf: string;
  customerEmail: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  total: number;
  totalSavings: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  deliveryType: DeliveryType;
  deliveryAddress?: Address;
  deliveryZoneId?: string;
  estimatedDelivery?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  pixCode?: string;
  pixQrCodeBase64?: string;
}

export interface InventoryMovement {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  type: 'IN' | 'OUT' | 'ADJUST' | 'SALE' | 'CANCEL';
  reason: string;
  date: string;
  user: string;
}

export interface DeliveryZone {
  id: string;
  name: string;
  neighborhoods: string[];
  distanceKm: number;
  fee: number;
  estimatedTimeMin: number;
  active: boolean;
}

export interface Coupon {
  id: string;
  code: string;
  type: 'PERCENTAGE' | 'FIXED';
  value: number;
  minOrderValue: number;
  maxUses: number;
  usedCount: number;
  startDate: string;
  endDate: string;
  active: boolean;
}

export interface ShoppingList {
  id: string;
  name: string;
  customerId: string;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    image: string;
    unitPrice: number;
  }[];
  createdAt: string;
}

export type StaffRole =
  | 'ADMIN'
  | 'GERENTE'
  | 'ESTOQUE'
  | 'CAIXA'
  | 'ENTREGA'
  | 'ATENDIMENTO';

export interface StaffUser {
  id: string;
  name: string;
  email: string;
  role: StaffRole;
  password?: string;
  phone?: string;
  active: boolean;
  createdAt?: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  agency: string;
  account: string;
  accountType: 'CORRENTE' | 'POUPANCA';
  holderName: string;
  document: string;
  pixKey?: string;
  active: boolean;
}

export interface PaymentMethodConfig {
  id: string;
  name: string;
  category: 'PIX' | 'A_PRAZO' | 'CASH' | 'DELIVERY_CARD' | 'BANK_TRANSFER' | 'CREDIT_CARD_ONLINE' | 'CUSTOM';
  active: boolean;
  description: string;
  badgeText?: string;
  requiresApproval?: boolean;
  instructions?: string;
  discountPercent?: number;
  customFields?: string[];
}

export interface FooterLink {
  id: string;
  label: string;
  url?: string;
  action?: string;
  active: boolean;
}

export interface FooterConfig {
  atendimentoTitle: string;
  atendimentoLinks: FooterLink[];
  institucionalTitle: string;
  institucionalCol1Links: FooterLink[];
  institucionalCol2Links: FooterLink[];
  politicasTitle: string;
  politicasLinks: FooterLink[];
  paymentFlags: string[];
  appDownloadTitle: string;
  googlePlayUrl: string;
  appStoreUrl: string;
  showAppDownload?: boolean;
  socialTitle: string;
  socialLinks: {
    facebook?: string;
    instagram?: string;
    x?: string;
    youtube?: string;
    linkedin?: string;
    whatsapp?: string;
  };
  legalNoticeText: string;
  legalNoticeUrl?: string;
}

export interface StoreSettings {
  storeName: string;
  masterPassword?: string;
  cnpj?: string;
  phone: string;
  phone2?: string;
  whatsapp: string;
  whatsapp2?: string;
  email: string;
  address: string;
  streetNumber?: string;
  neighborhood?: string;
  city?: string;
  state?: string;
  cep?: string;
  complement?: string;
  reference?: string;
  businessHours: string;
  pixKey: string;
  pixKeyType: 'CNPJ' | 'CPF' | 'EMAIL' | 'PHONE' | 'RANDOM';
  pixReceiver: string;
  mercadoPagoAccessToken?: string;
  mercadoPagoPublicKey?: string;
  mercadoPagoConnected: boolean;
  stripeSecretKey?: string;
  stripePublishableKey?: string;
  stripeConnected: boolean;
  geminiApiKey?: string;
  logoUrl?: string;
  demoMode: boolean;
  freeShippingThreshold: number;
  defaultDeliveryFee?: number;
  deliveryActive?: boolean;
  pickupActive?: boolean;
  deliveryHours?: string;
  deliveryTimeEstimate?: string;
  creditTermsText?: string;
  cashTermsText?: string;
  paymentMethods?: PaymentMethodConfig[];
  bankAccounts?: BankAccount[];
  footerConfig?: FooterConfig;
  wholesaleDefaultMinQty?: number;
  aiHelpEnabled: boolean;
  hideAdminAccessFromPublic?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
