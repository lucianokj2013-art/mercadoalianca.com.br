import { IPaymentProvider, PaymentRequest, PaymentResult, generatePixPayload, generatePixQrCode } from './types.ts';
import { db } from '../database/db.ts';

export class StripeProvider implements IPaymentProvider {
  name = 'Stripe';

  private getApiKey(): string | undefined {
    const fromSettings = db.getSettings().stripeSecretKey?.trim();
    if (fromSettings && fromSettings.startsWith('sk_')) return fromSettings;
    return process.env.STRIPE_SECRET_KEY?.trim();
  }

  isConfigured(): boolean {
    const key = this.getApiKey();
    return Boolean(key && key.startsWith('sk_'));
  }

  async processPayment(req: PaymentRequest): Promise<PaymentResult> {
    const isConfigured = this.isConfigured();
    const apiKey = this.getApiKey();

    if (isConfigured && apiKey) {
      try {
        const body = new URLSearchParams();
        body.append('amount', String(Math.round(req.amount * 100)));
        body.append('currency', 'brl');
        body.append('description', `Pedido ${req.orderId} - Mercadinho Aliança`);
        body.append('metadata[orderId]', req.orderId);
        if (req.customer.email) {
          body.append('receipt_email', req.customer.email);
        }

        const res = await fetch('https://api.stripe.com/v1/payment_intents', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: body.toString()
        });

        const data = await res.json();
        if (res.ok) {
          return {
            success: true,
            status: data.status === 'succeeded' ? 'APPROVED' : 'PENDING',
            transactionId: data.id,
            provider: this.name,
            mode: 'PRODUCAO'
          };
        }
      } catch (err) {
        console.error('[Stripe Provider Error]:', err);
      }
    }

    // Fallback demo mode
    return {
      success: true,
      status: 'APPROVED',
      transactionId: `ST-DEMO-${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
      provider: this.name,
      mode: 'DEMO',
      errorMessage: 'Modo Demonstração: Configure STRIPE_SECRET_KEY para pagamentos em produção.'
    };
  }

  async handleWebhook(payload: any): Promise<{ orderId: string; status: 'APPROVED' | 'REJECTED' | 'PENDING' } | null> {
    if (payload.type === 'payment_intent.succeeded') {
      const orderId = payload.data?.object?.metadata?.orderId;
      if (orderId) {
        return { orderId, status: 'APPROVED' };
      }
    }
    return null;
  }
}
