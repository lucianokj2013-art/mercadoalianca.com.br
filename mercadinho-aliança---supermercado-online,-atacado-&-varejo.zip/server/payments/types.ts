import QRCode from 'qrcode';

export interface PaymentRequest {
  orderId: string;
  amount: number;
  customer: {
    name: string;
    email: string;
    cpf?: string;
    phone?: string;
  };
  method: 'PIX' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'BOLETO' | 'CASH';
  cardToken?: string;
  installments?: number;
}

export interface PaymentResult {
  success: boolean;
  status: 'APPROVED' | 'PENDING' | 'REJECTED';
  transactionId: string;
  provider: string;
  mode: 'DEMO' | 'PRODUCAO';
  qrCode?: string;
  qrCodeBase64?: string;
  ticketUrl?: string;
  errorMessage?: string;
}

export interface IPaymentProvider {
  name: string;
  isConfigured(): boolean;
  processPayment(req: PaymentRequest): Promise<PaymentResult>;
  handleWebhook(payload: any, signature?: string): Promise<{ orderId: string; status: 'APPROVED' | 'REJECTED' | 'PENDING' } | null>;
}

// Helper to generate a realistic Brazilian Central Bank BR Code / PIX payload
export function generatePixPayload(key: string, receiver: string, city: string, amount: number, txid: string): string {
  const cleanTxid = txid.replace(/[^a-zA-Z0-9]/g, '').slice(0, 25) || 'ALIANCA01';
  const formattedAmount = amount.toFixed(2);
  
  // Format standard PIX payload string
  return `00020126580014BR.GOV.BCB.PIX0136${key}520400005303986540${formattedAmount.length.toString().padStart(2, '0')}${formattedAmount}5802BR59${receiver.length.toString().padStart(2, '0')}${receiver}60${city.length.toString().padStart(2, '0')}${city}62070503${cleanTxid}6304`;
}

export async function generatePixQrCode(pixCode: string): Promise<string> {
  return await QRCode.toDataURL(pixCode, {
    margin: 2,
    width: 320,
    color: {
      dark: '#000000',
      light: '#ffffff'
    }
  });
}
