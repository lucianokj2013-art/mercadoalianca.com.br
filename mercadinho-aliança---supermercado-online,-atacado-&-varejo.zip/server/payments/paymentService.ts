import { IPaymentProvider, PaymentRequest, PaymentResult } from './types.ts';
import { MercadoPagoProvider } from './MercadoPagoProvider.ts';
import { StripeProvider } from './StripeProvider.ts';
import { db } from '../database/db.ts';

class PaymentService {
  private providers: Map<string, IPaymentProvider> = new Map();
  private activeProviderName: string = 'Mercado Pago';

  constructor() {
    const mp = new MercadoPagoProvider();
    const stripe = new StripeProvider();
    this.providers.set('Mercado Pago', mp);
    this.providers.set('Stripe', stripe);
  }

  getProvidersStatus() {
    return Array.from(this.providers.entries()).map(([name, provider]) => ({
      name,
      configured: provider.isConfigured(),
      active: name === this.activeProviderName
    }));
  }

  setActiveProvider(name: string) {
    if (this.providers.has(name)) {
      this.activeProviderName = name;
    }
  }

  async processPayment(req: PaymentRequest): Promise<PaymentResult> {
    const provider = this.providers.get(this.activeProviderName) || this.providers.get('Mercado Pago')!;
    const result = await provider.processPayment(req);

    // Update order status if payment approved or pending
    const order = db.getOrderById(req.orderId);
    if (order) {
      if (result.status === 'APPROVED') {
        db.updateOrderStatus(order.id, 'PAGO', 'APPROVED');
      } else if (result.status === 'PENDING') {
        db.updateOrderStatus(order.id, 'PAGAMENTO_PENDENTE', 'PENDING');
      }
    }

    return result;
  }

  async handleWebhook(providerName: string, payload: any, signature?: string) {
    const provider = this.providers.get(providerName) || this.providers.get('Mercado Pago')!;
    const event = await provider.handleWebhook(payload, signature);
    if (event) {
      if (event.status === 'APPROVED') {
        db.updateOrderStatus(event.orderId, 'PAGO', 'APPROVED');
      } else if (event.status === 'REJECTED') {
        db.updateOrderStatus(event.orderId, 'CANCELADO', 'REJECTED');
      }
    }
    return event;
  }
}

export const paymentService = new PaymentService();
