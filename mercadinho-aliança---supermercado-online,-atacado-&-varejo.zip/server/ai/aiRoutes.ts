import { Router } from 'express';
import {
  handleAiChat,
  handleAiExtractProduct,
  handleAiVisionProduct,
  handleDirectToolExecution
} from './aiController.ts';

const router = Router();

router.post('/chat', handleAiChat);
router.post('/extract-product', handleAiExtractProduct);
router.post('/vision-product', handleAiVisionProduct);
router.post('/execute-tool', handleDirectToolExecution);

export default router;
