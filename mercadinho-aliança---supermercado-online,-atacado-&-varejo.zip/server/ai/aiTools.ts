import { FunctionDeclaration, Type } from '@google/genai';
import { db } from '../database/db.ts';
import { Product, ProductCategory } from '../../shared/types.ts';

export const aiFunctionDeclarations: FunctionDeclaration[] = [
  {
    name: 'search_products',
    description: 'Pesquisa produtos no catálogo do supermercado por nome, categoria, marca ou código de barras.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: {
          type: Type.STRING,
          description: 'Termo de busca (ex: arroz, feijão, leite, refrigerante, carnes).'
        },
        category: {
          type: Type.STRING,
          description: 'Categoria opcional do produto.'
        },
        onlyOnSale: {
          type: Type.BOOLEAN,
          description: 'Filtrar apenas itens em promoção.'
        }
      },
      required: ['query']
    }
  },
  {
    name: 'get_product',
    description: 'Obtém detalhes completos de um produto específico através do ID ou código de barras.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        productId: {
          type: Type.STRING,
          description: 'ID ou código de barras do produto.'
        }
      },
      required: ['productId']
    }
  },
  {
    name: 'create_product',
    description: 'Cadastra um novo produto no catálogo do Mercadinho Aliança.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: 'Nome completo do produto.' },
        category: { type: Type.STRING, description: 'Categoria do supermercado.' },
        brand: { type: Type.STRING, description: 'Marca do produto.' },
        costPrice: { type: Type.NUMBER, description: 'Preço de custo em R$.' },
        retailPrice: { type: Type.NUMBER, description: 'Preço de venda varejo em R$.' },
        wholesalePrice: { type: Type.NUMBER, description: 'Preço atacado em R$.' },
        wholesaleMinQty: { type: Type.INTEGER, description: 'Quantidade mínima para atacado.' },
        stock: { type: Type.INTEGER, description: 'Estoque inicial.' },
        unit: { type: Type.STRING, description: 'Unidade (ex: un, kg, L, pct).' },
        description: { type: Type.STRING, description: 'Descrição detalhada do produto.' }
      },
      required: ['name', 'category', 'retailPrice']
    }
  },
  {
    name: 'update_product',
    description: 'Atualiza informações de um produto existente.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        productId: { type: Type.STRING, description: 'ID do produto a ser atualizado.' },
        retailPrice: { type: Type.NUMBER, description: 'Novo preço de varejo.' },
        wholesalePrice: { type: Type.NUMBER, description: 'Novo preço de atacado.' },
        stock: { type: Type.INTEGER, description: 'Novo estoque.' },
        status: { type: Type.STRING, description: 'ACTIVE ou INACTIVE' }
      },
      required: ['productId']
    }
  },
  {
    name: 'search_orders',
    description: 'Pesquisa pedidos por status, nome do cliente ou data.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        status: {
          type: Type.STRING,
          description: 'Status do pedido (NOVO, PAGO, EM_PREPARACAO, SAIU_PARA_ENTREGA, ENTREGUE).'
        },
        customerName: {
          type: Type.STRING,
          description: 'Nome do cliente.'
        }
      }
    }
  },
  {
    name: 'get_order',
    description: 'Busca um pedido específico pelo código (ex: #ALN-000001).',
    parameters: {
      type: Type.OBJECT,
      properties: {
        orderId: {
          type: Type.STRING,
          description: 'Código do pedido formatado com #ALN-...'
        }
      },
      required: ['orderId']
    }
  },
  {
    name: 'update_order_status',
    description: 'Altera o status de um pedido no sistema de entregas ou separação.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        orderId: { type: Type.STRING, description: 'Código do pedido.' },
        status: {
          type: Type.STRING,
          description: 'Novo status (ex: PAGO, SEPARANDO, EM_PREPARACAO, SAIU_PARA_ENTREGA, ENTREGUE).'
        }
      },
      required: ['orderId', 'status']
    }
  },
  {
    name: 'get_inventory',
    description: 'Obtém visão geral do estoque e movimentações recentes.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        filter: {
          type: Type.STRING,
          description: 'all, low_stock, ou recent_movements'
        }
      }
    }
  },
  {
    name: 'get_low_stock',
    description: 'Retorna a lista de produtos com estoque igual ou abaixo do estoque mínimo de segurança.',
    parameters: {
      type: Type.OBJECT,
      properties: {}
    }
  },
  {
    name: 'get_sales_report',
    description: 'Gera relatório de vendas resumido com faturamento, ticket médio, atacado vs varejo.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        period: {
          type: Type.STRING,
          description: 'today, week, ou month'
        }
      }
    }
  },
  {
    name: 'create_coupon',
    description: 'Cria um novo cupom de desconto para a loja.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        code: { type: Type.STRING, description: 'Código do cupom (ex: PROMO10).' },
        type: { type: Type.STRING, description: 'PERCENTAGE ou FIXED' },
        value: { type: Type.NUMBER, description: 'Valor do desconto.' },
        minOrderValue: { type: Type.NUMBER, description: 'Valor mínimo do pedido.' }
      },
      required: ['code', 'type', 'value']
    }
  },
  {
    name: 'calculate_cart',
    description: 'Calcula o subtotal, descontos de atacado acumulados, economia total e frete para uma lista de produtos.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        items: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              productId: { type: Type.STRING },
              quantity: { type: Type.INTEGER }
            },
            required: ['productId', 'quantity']
          }
        },
        deliveryZoneId: { type: Type.STRING }
      },
      required: ['items']
    }
  },
  {
    name: 'get_delivery_zones',
    description: 'Lista as zonas de entrega atendidas pelo Mercadinho Aliança com taxas e tempos de entrega.',
    parameters: {
      type: Type.OBJECT,
      properties: {}
    }
  },
  {
    name: 'get_delivery_slots',
    description: 'Consulta horários e previsões disponíveis para entrega ou retirada na loja.',
    parameters: {
      type: Type.OBJECT,
      properties: {}
    }
  }
];

// Execution engine for function calls
export async function executeAiFunction(name: string, args: any): Promise<any> {
  switch (name) {
    case 'search_products': {
      const q = (args.query || '').toLowerCase();
      let results = db.getProducts().filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.barcode.includes(q)
      );
      if (args.category) {
        results = results.filter(p => p.category.toLowerCase() === args.category.toLowerCase());
      }
      if (args.onlyOnSale) {
        results = results.filter(p => p.onSale);
      }
      return {
        count: results.length,
        products: results.slice(0, 8).map(p => ({
          id: p.id,
          name: p.name,
          category: p.category,
          retailPrice: p.retailPrice,
          wholesalePrice: p.wholesalePrice,
          wholesaleMinQty: p.wholesaleMinQty,
          onSale: p.onSale,
          salePrice: p.salePrice,
          stock: p.stock,
          unit: p.unit
        }))
      };
    }

    case 'get_product': {
      const p = db.getProductById(args.productId) || db.getProductByBarcode(args.productId);
      if (!p) return { error: 'Produto não encontrado.' };
      return { product: p };
    }

    case 'get_low_stock': {
      const lowStockItems = db.getProducts().filter(p => p.stock <= p.minStock);
      return {
        count: lowStockItems.length,
        items: lowStockItems.map(p => ({
          id: p.id,
          name: p.name,
          stock: p.stock,
          minStock: p.minStock,
          category: p.category
        }))
      };
    }

    case 'search_orders': {
      let orders = db.getOrders();
      if (args.status) {
        orders = orders.filter(o => o.status.toLowerCase() === args.status.toLowerCase());
      }
      if (args.customerName) {
        orders = orders.filter(o => o.customerName.toLowerCase().includes(args.customerName.toLowerCase()));
      }
      return {
        count: orders.length,
        orders: orders.slice(0, 5).map(o => ({
          id: o.id,
          customerName: o.customerName,
          status: o.status,
          total: o.total,
          itemsCount: o.items.length,
          paymentMethod: o.paymentMethod,
          createdAt: o.createdAt
        }))
      };
    }

    case 'get_order': {
      const order = db.getOrderById(args.orderId);
      if (!order) return { error: `Pedido ${args.orderId} não encontrado.` };
      return { order };
    }

    case 'get_inventory': {
      const all = db.getProducts();
      const low = all.filter(p => p.stock <= p.minStock);
      const totalUnits = all.reduce((acc, p) => acc + p.stock, 0);
      return {
        totalProductsCatalog: all.length,
        totalUnitsInStock: totalUnits,
        lowStockAlertCount: low.length,
        recentMovements: db.getMovements().slice(0, 5)
      };
    }

    case 'get_sales_report': {
      const orders = db.getOrders().filter(o => o.status !== 'CANCELADO');
      const totalRevenue = orders.reduce((acc, o) => acc + o.total, 0);
      const totalSavingsGiven = orders.reduce((acc, o) => acc + o.totalSavings, 0);
      const ticketMedio = orders.length ? totalRevenue / orders.length : 0;
      return {
        period: args.period || 'all',
        totalOrders: orders.length,
        totalRevenue: Number(totalRevenue.toFixed(2)),
        ticketMedio: Number(ticketMedio.toFixed(2)),
        totalWholesaleSavingsDistributed: Number(totalSavingsGiven.toFixed(2))
      };
    }

    case 'calculate_cart': {
      const items = args.items || [];
      let subtotal = 0;
      let totalSavings = 0;
      const computedItems = [];

      for (const item of items) {
        const prod = db.getProductById(item.productId);
        if (prod) {
          const qty = item.quantity;
          const isWholesale = qty >= prod.wholesaleMinQty;
          const price = isWholesale ? prod.wholesalePrice : (prod.onSale && prod.salePrice ? prod.salePrice : prod.retailPrice);
          const originalSub = prod.retailPrice * qty;
          const itemSub = price * qty;
          const itemSavings = Math.max(0, originalSub - itemSub);

          subtotal += itemSub;
          totalSavings += itemSavings;

          computedItems.push({
            productId: prod.id,
            name: prod.name,
            quantity: qty,
            unitPrice: price,
            isWholesale,
            subtotal: itemSub,
            savings: itemSavings
          });
        }
      }

      let shipping = 0;
      if (args.deliveryZoneId) {
        const zone = db.getDeliveryZones().find(z => z.id === args.deliveryZoneId);
        if (zone) shipping = zone.fee;
      }

      return {
        items: computedItems,
        subtotal: Number(subtotal.toFixed(2)),
        shippingFee: shipping,
        totalSavings: Number(totalSavings.toFixed(2)),
        total: Number((subtotal + shipping).toFixed(2))
      };
    }

    case 'get_delivery_zones': {
      return { zones: db.getDeliveryZones() };
    }

    case 'get_delivery_slots': {
      return {
        express: 'Entrega imediata em até 45 minutos (motoboy próprio)',
        agendada: [
          'Hoje 14h - 16h',
          'Hoje 16h - 18h',
          'Hoje 18h - 20h',
          'Amanhã 09h - 11h'
        ],
        retirada: 'Disponível para retirada em 30 minutos na loja física.'
      };
    }

    case 'create_coupon': {
      const newCoupon = db.saveCoupon({
        id: `coup-${Date.now()}`,
        code: args.code.toUpperCase(),
        type: args.type === 'PERCENTAGE' ? 'PERCENTAGE' : 'FIXED',
        value: Number(args.value),
        minOrderValue: Number(args.minOrderValue || 0),
        maxUses: 100,
        usedCount: 0,
        startDate: new Date().toISOString().split('T')[0],
        endDate: '2026-12-31',
        active: true
      });
      return { success: true, coupon: newCoupon };
    }

    case 'update_order_status': {
      const updated = db.updateOrderStatus(args.orderId, args.status);
      if (!updated) return { error: `Pedido ${args.orderId} não encontrado.` };
      return { success: true, order: updated };
    }

    case 'create_product': {
      const newProduct: Product = {
        id: `prod-${Date.now()}`,
        name: args.name,
        sku: `ALN-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
        ean: `789${Math.floor(1000000000 + Math.random() * 9000000000)}`,
        barcode: `789${Math.floor(1000000000 + Math.random() * 9000000000)}`,
        category: (args.category as ProductCategory) || 'Mercearia',
        brand: args.brand || 'Marca Própria',
        description: args.description || args.name,
        image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
        unit: args.unit || 'un',
        stock: args.stock || 20,
        minStock: 5,
        costPrice: args.costPrice || args.retailPrice * 0.7,
        retailPrice: args.retailPrice,
        wholesalePrice: args.wholesalePrice || args.retailPrice * 0.9,
        wholesaleMinQty: args.wholesaleMinQty || 5,
        status: 'ACTIVE',
        onSale: false,
        featured: false
      };
      db.saveProduct(newProduct);
      return { success: true, product: newProduct };
    }

    default:
      return { error: `Função ${name} não suportada.` };
  }
}
