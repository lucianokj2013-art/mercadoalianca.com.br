import { GoogleGenAI, Type } from '@google/genai';
import { aiFunctionDeclarations, executeAiFunction } from './aiTools.ts';
import { db } from '../database/db.ts';

class GeminiService {
  private modelName = 'gemini-3.8-flash';

  private getAiClient(): GoogleGenAI | null {
    const settings = db.getSettings();
    const apiKey = settings.geminiApiKey?.trim() || process.env.GEMINI_API_KEY?.trim();
    if (apiKey && apiKey !== '' && apiKey !== 'MY_GEMINI_API_KEY') {
      try {
        return new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build'
            }
          }
        });
      } catch (err) {
        console.warn('[Gemini Init Warning]:', err);
      }
    }
    return null;
  }

  isConfigured(): boolean {
    return this.getAiClient() !== null;
  }

  /**
   * Main customer and admin chat agent with Function Calling
   */
  async chatWithAgent(message: string, context: 'customer' | 'admin' = 'customer', history: any[] = []): Promise<{
    reply: string;
    actionTaken?: string;
    data?: any;
  }> {
    const ai = this.getAiClient();
    const storeInfo = db.getSettings();
    // If Gemini API is configured
    if (ai) {
      try {
        const systemPrompt = context === 'admin'
          ? `Você é o "Aliança AI Manager", assistente inteligente do supermercado "Mercadinho Aliança".
             Dados da loja:
             - Endereço: ${storeInfo.address}, ${storeInfo.streetNumber || '100'} - ${storeInfo.neighborhood || 'Centro'}, ${storeInfo.city || 'Bahia'} - ${storeInfo.state || 'BA'}
             - Telefones Oficiais: ${storeInfo.phone} | ${storeInfo.phone2 || '(74) 99800-8283'}
             - WhatsApp: ${storeInfo.whatsapp}
             Você ajuda o administrador com:
             - Análise de vendas, faturamento e relatórios
             - Consulta de estoque e alerta de produtos com estoque baixo
             - Criação de cupons e promoções
             - Gerenciamento de pedidos e clientes
             Você possui ferramentas (function calling) conectadas ao banco de dados em tempo real.
             SEMPRE utilize as ferramentas quando solicitarem dados sobre produtos, pedidos, estoque ou relatórios.
             Responda de forma executiva, polida, profissional e objetiva em Português do Brasil.
             ATENÇÃO: Nunca invente números financeiros ou de estoque; sempre consulte o sistema via tools.`
          : `Você é o "Aliança AI", concierge e assistente virtual exclusivo do supermercado premium "Mercadinho Aliança".
             Dados da loja física:
             - Endereço: ${storeInfo.address}, ${storeInfo.streetNumber || '100'} - ${storeInfo.neighborhood || 'Centro'}, ${storeInfo.city || 'Bahia'} - ${storeInfo.state || 'BA'}
             - Telefones Oficiais de Atendimento: ${storeInfo.phone} e ${storeInfo.phone2 || '(74) 99800-8283'}
             - Horário: ${storeInfo.businessHours}
             Você ajuda os clientes a:
             - Encontrar produtos no catálogo, preços de varejo e promoções
             - Explicar descontos de atacado (ex: "comprando 5 unidades você economiza X")
             - Montar cestas de compras para famílias, churrascos, festas ou compras do mês
             - Consultar status de pedidos e prazos de entrega / delivery
             - Ajudar a escolher itens para adicionar ao carrinho
             Você tem ferramentas conectadas ao catálogo real do Mercadinho Aliança.
             Seja cordial, acolhedor, rápido e prestativo em Português do Brasil.`;

        // 1. Initial request with tools
        const response = await ai.models.generateContent({
          model: this.modelName,
          contents: [
            ...history.map(h => ({
              role: h.role === 'user' ? 'user' : 'model',
              parts: [{ text: h.text }]
            })),
            { role: 'user', parts: [{ text: message }] }
          ],
          config: {
            systemInstruction: systemPrompt,
            tools: [{ functionDeclarations: aiFunctionDeclarations }]
          }
        });

        // Check if the model triggered a function call
        const functionCalls = response.functionCalls;
        if (functionCalls && functionCalls.length > 0) {
          const call = functionCalls[0];
          if (call.name) {
            console.log(`[Gemini Function Call]: ${call.name}`, call.args);
            const toolResult = await executeAiFunction(call.name, call.args);

            // Second round: send the function execution result back to Gemini
            const followUp = await ai.models.generateContent({
              model: this.modelName,
              contents: [
                { role: 'user', parts: [{ text: message }] },
                {
                  role: 'model',
                  parts: [{
                    functionCall: {
                      name: call.name,
                      args: call.args
                    }
                  }]
                },
                {
                  role: 'user',
                  parts: [{
                    functionResponse: {
                      name: call.name,
                      response: toolResult
                    }
                  }]
                }
              ],
              config: {
                systemInstruction: systemPrompt
              }
            });

            return {
              reply: followUp.text || 'Operação realizada com sucesso no sistema.',
              actionTaken: call.name,
              data: toolResult
            };
          }
        }

        return {
          reply: response.text || 'Olá! Como posso ajudar você no Mercadinho Aliança hoje?'
        };
      } catch (err: any) {
        console.error('[Gemini Chat Error]:', err);
      }
    }

    // Graceful smart local agent fallback if GEMINI_API_KEY is not configured
    return await this.fallbackLocalAgent(message, context);
  }

  /**
   * Product extraction from raw description prompt (Cadastrar com IA)
   */
  async extractProductFromText(promptText: string): Promise<any> {
    const ai = this.getAiClient();
    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: this.modelName,
          contents: `Analise a seguinte descrição em linguagem natural para cadastro de produto de supermercado e extraia os campos em formato JSON estrito:
          "${promptText}"`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                category: { type: Type.STRING },
                brand: { type: Type.STRING },
                unit: { type: Type.STRING },
                weight: { type: Type.STRING },
                costPrice: { type: Type.NUMBER },
                retailPrice: { type: Type.NUMBER },
                wholesalePrice: { type: Type.NUMBER },
                wholesaleMinQty: { type: Type.INTEGER },
                stock: { type: Type.INTEGER },
                description: { type: Type.STRING }
              },
              required: ['name', 'category', 'retailPrice']
            }
          }
        });

        if (response.text) {
          return JSON.parse(response.text);
        }
      } catch (e) {
        console.error('[Gemini Product Extraction Error]:', e);
      }
    }

    // Smart regex parser fallback for standard supermarket inputs
    const lower = promptText.toLowerCase();
    const costMatch = lower.match(/custo\s*:?\s*r?\$?\s*([0-9]+[.,]?[0-9]*)/);
    const retailMatch = lower.match(/(?:venda|preco|preço|varejo)\s*:?\s*r?\$?\s*([0-9]+[.,]?[0-9]*)/);
    const wholesaleMatch = lower.match(/atacado\s*:?\s*r?\$?\s*([0-9]+[.,]?[0-9]*)/);
    const minQtyMatch = lower.match(/(?:a partir de|minimo|qtd)\s*([0-9]+)/);
    const weightMatch = lower.match(/([0-9]+(?:\.[0-9]+)?\s*(?:kg|g|l|ml))/);

    let cat = 'Mercearia';
    if (lower.includes('carne') || lower.includes('frango') || lower.includes('bovino')) cat = 'Carnes';
    else if (lower.includes('refrigerante') || lower.includes('cerveja') || lower.includes('suco')) cat = 'Bebidas';
    else if (lower.includes('leite') || lower.includes('queijo') || lower.includes('iogurte')) cat = 'Laticínios';
    else if (lower.includes('detergente') || lower.includes('sabao') || lower.includes('amaciante')) cat = 'Limpeza';

    const parseNum = (m: RegExpMatchArray | null, def = 0) => m ? parseFloat(m[1].replace(',', '.')) : def;

    return {
      name: promptText.split(',')[0].replace(/cadastre\s+/i, '').trim(),
      category: cat,
      brand: 'Marca Identificada',
      unit: weightMatch ? (weightMatch[1].includes('kg') ? 'kg' : 'un') : 'un',
      weight: weightMatch ? weightMatch[1] : undefined,
      costPrice: parseNum(costMatch, 15.00),
      retailPrice: parseNum(retailMatch, 24.90),
      wholesalePrice: parseNum(wholesaleMatch, 21.90),
      wholesaleMinQty: minQtyMatch ? parseInt(minQtyMatch[1], 10) : 5,
      stock: 24,
      description: `Produto cadastrado via Inteligência Artificial Aliança: ${promptText}`
    };
  }

  /**
   * Product identification from Image
   * Never invents price - price must be entered by admin!
   */
  async identifyProductFromImage(base64Image: string, mimeType = 'image/jpeg'): Promise<any> {
    const ai = this.getAiClient();
    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: this.modelName,
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType,
                  data: base64Image.replace(/^data:image\/[a-z]+;base64,/, '')
                }
              },
              {
                text: `Identifique o produto de supermercado nesta foto. 
                Retorne um JSON com: name, category, brand, package, unit, description.
                IMPORTANTE: NUNCA invente preço. Não preencha retailPrice ou costPrice.`
              }
            ]
          },
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                category: { type: Type.STRING },
                brand: { type: Type.STRING },
                package: { type: Type.STRING },
                unit: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ['name', 'category', 'brand']
            }
          }
        });

        if (response.text) {
          return JSON.parse(response.text);
        }
      } catch (err) {
        console.error('[Gemini Vision Error]:', err);
      }
    }

    // Default structured mock recognition for image demo
    return {
      name: 'Produto Reconhecido pela Câmera',
      category: 'Mercearia',
      brand: 'Marca Identificada',
      unit: 'un',
      package: 'Embalagem Padrão',
      description: 'Identificado via IA com base na imagem do rótulo.'
    };
  }

  private async fallbackLocalAgent(message: string, context: string): Promise<any> {
    const q = message.toLowerCase();

    if (q.includes('arroz') || q.includes('feijao') || q.includes('leite') || q.includes('carne') || q.includes('preco') || q.includes('preço') || q.includes('quanto custa')) {
      const searchRes = await executeAiFunction('search_products', { query: q.replace(/quanto|custa|tem|preco|preço|o|a/g, '').trim() || 'arroz' });
      if (searchRes.products && searchRes.products.length > 0) {
        const p = searchRes.products[0];
        const promo = p.onSale ? ` (Promoção: R$ ${p.salePrice.toFixed(2)})` : '';
        return {
          reply: `Temos sim! O **${p.name}** está saindo por **R$ ${p.retailPrice.toFixed(2)}** no varejo${promo}. E no atacado sai por apenas **R$ ${p.wholesalePrice.toFixed(2)}** a partir de ${p.wholesaleMinQty} unidades! Deseja adicionar à sua cesta?`,
          actionTaken: 'search_products',
          data: searchRes
        };
      }
    }

    if (q.includes('estoque') || q.includes('baixo') || q.includes('acabando')) {
      const low = await executeAiFunction('get_low_stock', {});
      return {
        reply: `Identifiquei ${low.count} item(s) com estoque baixo ou crítico no momento: ${low.items.map((i: any) => `${i.name} (apenas ${i.stock} un)`).join(', ')}. Deseja abrir a tela de reposição?`,
        actionTaken: 'get_low_stock',
        data: low
      };
    }

    if (q.includes('vendas') || q.includes('faturamento') || q.includes('relatorio')) {
      const rep = await executeAiFunction('get_sales_report', { period: 'all' });
      return {
        reply: `Relatório de Vendas Atual: Total de ${rep.totalOrders} pedidos realizados, faturamento bruto de R$ ${rep.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}, ticket médio de R$ ${rep.ticketMedio.toFixed(2)}, e R$ ${rep.totalWholesaleSavingsDistributed.toFixed(2)} em descontos de atacado concedidos aos clientes!`,
        actionTaken: 'get_sales_report',
        data: rep
      };
    }

    if (q.includes('entrega') || q.includes('taxa') || q.includes('frete') || q.includes('zona')) {
      const zones = await executeAiFunction('get_delivery_zones', {});
      return {
        reply: `Entregamos em toda a região com equipe própria! Zona 1 (Centro/Próximos) taxa de R$ 5,00 (35 min); Zona 2 (Bairros Médios) taxa de R$ 8,00 (50 min); Zona 3 (Região Metropolitana) R$ 12,00. E compras acima de R$ 180,00 possuem Frete Grátis!`,
        actionTaken: 'get_delivery_zones',
        data: zones
      };
    }

    if (q.includes('familia') || q.includes('família') || q.includes('cesta') || q.includes('sugestao') || q.includes('churrasco')) {
      return {
        reply: `Excelente escolha! Para uma família de 4 pessoas ou um churrasco completo, recomendo: Arroz 5kg, Feijão 1kg, Óleo de Soja, Café Pilão 500g, Contra Filé Premium 2kg, Costela em Tiras, Refrigerante 2L e Cerveja/Sucos. Comprando no atacado você economiza mais de 15% na compra total! Deseja que eu prepare os itens no seu carrinho?`
      };
    }

    return {
      reply: context === 'admin'
        ? 'Olá! Sou o Aliança AI Manager. Posso verificar estoque baixo, relatórios de vendas, sugerir promoções, criar cupons ou auxiliar no cadastro de produtos. Como posso ajudar agora?'
        : 'Olá! Bem-vindo ao Mercadinho Aliança! Posso consultar produtos, verificar se temos estoque, calcular descontos de atacado, informar prazos de entrega ou tirar dúvidas sobre o seu pedido. Em que posso te ajudar?'
    };
  }
}

export const geminiService = new GeminiService();
