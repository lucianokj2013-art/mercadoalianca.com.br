import { Request, Response } from 'express';
import { geminiService } from './geminiService.ts';
import { executeAiFunction } from './aiTools.ts';

export const handleAiChat = async (req: Request, res: Response) => {
  try {
    const { message, context = 'customer', history = [] } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Mensagem é obrigatória.' });
    }

    const result = await geminiService.chatWithAgent(message, context, history);
    return res.json(result);
  } catch (error: any) {
    console.error('AI Chat Controller Error:', error);
    return res.status(500).json({ error: 'Erro ao processar conversa com a IA.' });
  }
};

export const handleAiExtractProduct = async (req: Request, res: Response) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt é obrigatório.' });
    }

    const productData = await geminiService.extractProductFromText(prompt);
    return res.json(productData);
  } catch (error: any) {
    console.error('AI Extract Product Error:', error);
    return res.status(500).json({ error: 'Erro ao extrair produto com a IA.' });
  }
};

export const handleAiVisionProduct = async (req: Request, res: Response) => {
  try {
    const { imageBase64, mimeType } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'Imagem base64 é obrigatória.' });
    }

    const productData = await geminiService.identifyProductFromImage(imageBase64, mimeType);
    return res.json(productData);
  } catch (error: any) {
    console.error('AI Vision Product Error:', error);
    return res.status(500).json({ error: 'Erro ao analisar imagem com a IA.' });
  }
};

export const handleDirectToolExecution = async (req: Request, res: Response) => {
  try {
    const { toolName, args } = req.body;
    if (!toolName) {
      return res.status(400).json({ error: 'toolName é obrigatório.' });
    }
    const result = await executeAiFunction(toolName, args || {});
    return res.json(result);
  } catch (error: any) {
    console.error('Direct tool execution error:', error);
    return res.status(500).json({ error: 'Falha ao executar ferramenta da IA.' });
  }
};
