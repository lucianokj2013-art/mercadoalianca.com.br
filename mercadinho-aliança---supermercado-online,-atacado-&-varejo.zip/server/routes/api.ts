import { Router, Request, Response } from 'express';
import { db } from '../database/db.ts';
import { paymentService } from '../payments/paymentService.ts';
import aiRoutes from '../ai/aiRoutes.ts';
import { ProductCategory } from '../../shared/types.ts';

const router = Router();

// Mount AI routes
router.use('/ai', aiRoutes);

// ========================
// PRODUCTS
// ========================
router.get('/products', (req: Request, res: Response) => {
  let products = db.getProducts();
  const { category, search, onSale, wholesale, barcode } = req.query;

  if (barcode) {
    const found = db.getProductByBarcode(String(barcode));
    return res.json(found ? [found] : []);
  }

  if (category && category !== 'Todas') {
    products = products.filter(p => p.category.toLowerCase() === String(category).toLowerCase());
  }

  if (search) {
    const q = String(search).toLowerCase();
    products = products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.sku.toLowerCase().includes(q) ||
      p.barcode.includes(q)
    );
  }

  if (onSale === 'true') {
    products = products.filter(p => p.onSale);
  }

  if (wholesale === 'true') {
    products = products.filter(p => p.wholesalePrice < p.retailPrice);
  }

  res.json(products);
});

router.get('/products/:id', (req: Request, res: Response) => {
  const product = db.getProductById(req.params.id) || db.getProductByBarcode(req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Produto não encontrado.' });
  }
  res.json(product);
});

router.post('/products', (req: Request, res: Response) => {
  try {
    const newProduct = db.saveProduct(req.body);
    // register initial inventory movement if stock > 0
    if (newProduct.stock > 0) {
      db.addMovement({
        productId: newProduct.id,
        productName: newProduct.name,
        quantity: newProduct.stock,
        type: 'IN',
        reason: 'Cadastro inicial de produto',
        user: 'Admin'
      });
    }
    res.status(201).json(newProduct);
  } catch (err: any) {
    res.status(400).json({ error: 'Erro ao cadastrar produto.' });
  }
});

router.put('/products/:id', (req: Request, res: Response) => {
  const existing = db.getProductById(req.params.id);
  if (!existing) {
    return res.status(404).json({ error: 'Produto não encontrado.' });
  }
  const updated = db.saveProduct({ ...existing, ...req.body, id: req.params.id });
  res.json(updated);
});

router.delete('/products/:id', (req: Request, res: Response) => {
  const deleted = db.deleteProduct(req.params.id);
  if (!deleted) {
    return res.status(404).json({ error: 'Produto não encontrado.' });
  }
  res.json({ success: true, message: 'Produto removido com sucesso.' });
});

// ========================
// CATEGORIES
// ========================
const defaultCategories: ProductCategory[] = [
  'Mercearia', 'Bebidas', 'Carnes', 'Frutas', 'Verduras', 'Legumes',
  'Laticínios', 'Frios', 'Padaria', 'Congelados', 'Higiene', 'Limpeza',
  'Bebês', 'Pet', 'Utilidades', 'Outros'
];

router.get('/categories', (req: Request, res: Response) => {
  const products = db.getProducts();
  const categoriesWithCounts = defaultCategories.map(cat => ({
    name: cat,
    count: products.filter(p => p.category === cat).length
  }));
  res.json(categoriesWithCounts);
});

// ========================
// ORDERS
// ========================
router.get('/orders', (req: Request, res: Response) => {
  const { customerId, status } = req.query;
  let orders = db.getOrders();
  if (customerId) {
    orders = orders.filter(o => o.customerId === customerId);
  }
  if (status) {
    orders = orders.filter(o => o.status === status);
  }
  res.json(orders);
});

router.get('/orders/:id', (req: Request, res: Response) => {
  const order = db.getOrderById(req.params.id);
  if (!order) {
    return res.status(404).json({ error: 'Pedido não encontrado.' });
  }
  res.json(order);
});

router.post('/orders', async (req: Request, res: Response) => {
  try {
    const orderData = req.body;
    const order = db.createOrder(orderData);

    // If order payment is PIX, automatically prepare PIX payment payload and QR code
    if (order.paymentMethod === 'PIX') {
      const paymentResult = await paymentService.processPayment({
        orderId: order.id,
        amount: order.total,
        customer: {
          name: order.customerName,
          email: order.customerEmail,
          phone: order.customerPhone,
          cpf: order.customerCpf
        },
        method: 'PIX'
      });

      order.pixCode = paymentResult.qrCode;
      order.pixQrCodeBase64 = paymentResult.qrCodeBase64;
    }

    res.status(201).json(order);
  } catch (err: any) {
    console.error('Order creation error:', err);
    res.status(400).json({ error: 'Erro ao gerar pedido.' });
  }
});

router.put('/orders/:id/status', (req: Request, res: Response) => {
  const { status, paymentStatus } = req.body;
  const updated = db.updateOrderStatus(req.params.id, status, paymentStatus);
  if (!updated) {
    return res.status(404).json({ error: 'Pedido não encontrado.' });
  }
  res.json(updated);
});

// ========================
// CUSTOMERS
// ========================
router.get('/customers', (req: Request, res: Response) => {
  res.json(db.getCustomers());
});

router.get('/customers/:id', (req: Request, res: Response) => {
  const customer = db.getCustomerById(req.params.id);
  if (!customer) {
    return res.status(404).json({ error: 'Cliente não encontrado.' });
  }
  res.json(customer);
});

router.post('/customers', (req: Request, res: Response) => {
  const saved = db.saveCustomer(req.body);
  res.status(201).json(saved);
});

// ========================
// INVENTORY
// ========================
router.get('/inventory', (req: Request, res: Response) => {
  const allProducts = db.getProducts();
  const lowStock = allProducts.filter(p => p.stock <= p.minStock);
  const movements = db.getMovements();

  res.json({
    totalItems: allProducts.length,
    lowStockCount: lowStock.length,
    lowStockItems: lowStock,
    movements: movements.slice(0, 50)
  });
});

router.post('/inventory/movement', (req: Request, res: Response) => {
  try {
    const { productId, quantity, type, reason, user } = req.body;
    const prod = db.getProductById(productId);
    if (!prod) {
      return res.status(404).json({ error: 'Produto não encontrado.' });
    }

    const movement = db.addMovement({
      productId,
      productName: prod.name,
      quantity: Number(quantity),
      type: type || 'ADJUST',
      reason: reason || 'Ajuste manual de estoque',
      user: user || 'Administrador'
    });

    res.status(201).json({ movement, currentStock: prod.stock });
  } catch (err: any) {
    res.status(400).json({ error: 'Falha ao registrar movimentação de estoque.' });
  }
});

// ========================
// PAYMENTS
// ========================
router.get('/payments/providers', (req: Request, res: Response) => {
  res.json(paymentService.getProvidersStatus());
});

router.post('/payments/create', async (req: Request, res: Response) => {
  try {
    const result = await paymentService.processPayment(req.body);
    res.json(result);
  } catch (err: any) {
    console.error('Payment process error:', err);
    res.status(500).json({ error: 'Falha no processamento de pagamento.' });
  }
});

router.post('/payments/webhook', async (req: Request, res: Response) => {
  try {
    const provider = String(req.query.provider || 'Mercado Pago');
    const signature = req.headers['x-signature'] as string;
    const event = await paymentService.handleWebhook(provider, req.body, signature);
    res.json({ received: true, event });
  } catch (err: any) {
    res.status(400).json({ error: 'Erro ao processar webhook de pagamento.' });
  }
});

// ========================
// DELIVERY
// ========================
router.get('/delivery/zones', (req: Request, res: Response) => {
  res.json(db.getDeliveryZones());
});

router.post('/delivery/zones', (req: Request, res: Response) => {
  const saved = db.saveDeliveryZone(req.body);
  res.status(201).json(saved);
});

router.put('/delivery/zones/:id', (req: Request, res: Response) => {
  const saved = db.saveDeliveryZone({ ...req.body, id: req.params.id });
  res.json(saved);
});

router.delete('/delivery/zones/:id', (req: Request, res: Response) => {
  const success = db.deleteDeliveryZone(req.params.id);
  res.json({ success });
});

router.get('/delivery/slots', (req: Request, res: Response) => {
  res.json({
    immediate: {
      label: 'Entrega Imediata (Aliança Express)',
      time: '35 a 55 minutos',
      available: true
    },
    slots: [
      { id: 'slot-1', date: 'Hoje', time: '14:00 - 16:00', feeBonus: 0 },
      { id: 'slot-2', date: 'Hoje', time: '16:00 - 18:00', feeBonus: 0 },
      { id: 'slot-3', date: 'Hoje', time: '18:00 - 20:00', feeBonus: 0 },
      { id: 'slot-4', date: 'Amanhã', time: '09:00 - 11:00', feeBonus: 0 },
      { id: 'slot-5', date: 'Amanhã', time: '14:00 - 16:00', feeBonus: 0 }
    ],
    pickup: {
      label: 'Retirada Expressa na Loja (Drive-thru / Balcão)',
      time: 'Pronto em 30 minutos',
      fee: 0
    }
  });
});

// ========================
// COUPONS
// ========================
router.get('/coupons', (req: Request, res: Response) => {
  res.json(db.getCoupons());
});

router.post('/coupons', (req: Request, res: Response) => {
  const saved = db.saveCoupon(req.body);
  res.status(201).json(saved);
});

router.post('/coupons/validate', (req: Request, res: Response) => {
  const { code, cartSubtotal = 0 } = req.body;
  if (!code) {
    return res.status(400).json({ valid: false, message: 'Código de cupom obrigatório.' });
  }
  const coupon = db.getCouponByCode(code);
  if (!coupon) {
    return res.status(404).json({ valid: false, message: 'Cupom inválido ou expirado.' });
  }
  if (cartSubtotal < coupon.minOrderValue) {
    return res.status(400).json({
      valid: false,
      message: `Este cupom exige compra mínima de R$ ${coupon.minOrderValue.toFixed(2)}.`
    });
  }
  const discount = coupon.type === 'PERCENTAGE'
    ? (cartSubtotal * coupon.value) / 100
    : coupon.value;

  res.json({
    valid: true,
    coupon,
    discountAmount: Math.min(cartSubtotal, discount),
    message: `Cupom ${coupon.code} aplicado com sucesso!`
  });
});

// ========================
// SETTINGS
// ========================
router.get('/settings', (req: Request, res: Response) => {
  res.json(db.getSettings());
});

router.put('/settings', (req: Request, res: Response) => {
  const updated = db.updateSettings(req.body);
  res.json(updated);
});

// ========================
// STAFF USERS & MASTER AUTH
// ========================
router.get('/staff', (req: Request, res: Response) => {
  res.json(db.getStaff());
});

router.post('/staff', (req: Request, res: Response) => {
  try {
    const { name, email, role, password, phone, active } = req.body;
    if (!name || !email || !role) {
      return res.status(400).json({ error: 'Nome, e-mail e cargo são obrigatórios.' });
    }
    const newUser = db.addStaff({
      name,
      email,
      role,
      password: password || '12345',
      phone: phone || '',
      active: active !== undefined ? active : true
    });
    res.status(201).json(newUser);
  } catch (err: any) {
    res.status(500).json({ error: 'Erro ao cadastrar colaborador.' });
  }
});

router.put('/staff/:id', (req: Request, res: Response) => {
  try {
    const updated = db.updateStaff(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Colaborador não encontrado.' });
    }
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: 'Erro ao atualizar colaborador.' });
  }
});

router.delete('/staff/:id', (req: Request, res: Response) => {
  try {
    const success = db.deleteStaff(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'Colaborador não encontrado.' });
    }
    res.json({ success: true, message: 'Colaborador removido com sucesso.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Erro ao remover colaborador.' });
  }
});

// Verify Master Password or Staff Login
router.post('/admin/verify-master', (req: Request, res: Response) => {
  const { password, email } = req.body;
  
  if (password && db.verifyMasterPassword(password)) {
    return res.json({
      valid: true,
      role: 'ADMIN',
      user: { id: 'master', name: 'Administrador Master', role: 'ADMIN' },
      isMaster: true
    });
  }

  // Also check if it's a collaborator with matching email/password
  if (email && password) {
    const staffUser = db.verifyStaffLogin(email, password);
    if (staffUser) {
      return res.json({
        valid: true,
        role: staffUser.role,
        user: staffUser,
        isMaster: false
      });
    }
  }

  res.status(401).json({ valid: false, error: 'Senha mestre ou credenciais incorretas.' });
});

// Change Master Password
router.post('/admin/change-master-password', (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'Senha atual e nova senha são obrigatórias.' });
  }

  if (!db.verifyMasterPassword(currentPassword)) {
    return res.status(401).json({ error: 'Senha mestre atual incorreta.' });
  }

  db.updateMasterPassword(newPassword);
  res.json({ success: true, message: 'Senha mestre atualizada com sucesso!' });
});

// ========================
// SHOPPING LISTS
// ========================
router.get('/lists/:customerId', (req: Request, res: Response) => {
  res.json(db.getShoppingLists(req.params.customerId));
});

router.post('/lists', (req: Request, res: Response) => {
  const saved = db.saveShoppingList(req.body);
  res.status(201).json(saved);
});

export default router;
