import {
  Product,
  Order,
  Customer,
  InventoryMovement,
  DeliveryZone,
  Coupon,
  StoreSettings,
  StaffUser,
  ShoppingList
} from '../../shared/types.ts';

// Initial realistic demo products with high quality supermarket images
const initialProducts: Product[] = [
  {
    id: 'prod-001',
    name: 'Arroz Branco Nobre Tipo 1 5kg',
    sku: 'ALN-ARR-001',
    ean: '7891000100012',
    barcode: '7891000100012',
    category: 'Mercearia',
    brand: 'Tio João',
    description: 'Arroz branco tipo 1 grãos nobres selecionados, rende mais e fica sempre soltinho. Embalagem com 5kg.',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80',
    weight: '5kg',
    unit: 'un',
    stock: 48,
    minStock: 15,
    costPrice: 20.50,
    retailPrice: 29.90,
    wholesalePrice: 27.90,
    wholesaleMinQty: 5,
    status: 'ACTIVE',
    onSale: true,
    salePrice: 28.50,
    featured: true
  },
  {
    id: 'prod-002',
    name: 'Feijão Carioca Especial 1kg',
    sku: 'ALN-FEI-002',
    ean: '7891000200021',
    barcode: '7891000200021',
    category: 'Mercearia',
    brand: 'Camil',
    description: 'Feijão carioca selecionado de caldo grosso e cozimento rápido.',
    image: 'https://images.unsplash.com/photo-1551462147-ff29053fad31?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'un',
    stock: 65,
    minStock: 20,
    costPrice: 5.80,
    retailPrice: 8.90,
    wholesalePrice: 7.79,
    wholesaleMinQty: 6,
    status: 'ACTIVE',
    onSale: false,
    featured: true
  },
  {
    id: 'prod-003',
    name: 'Açúcar Cristal Refinado 1kg',
    sku: 'ALN-ACU-003',
    ean: '7891000300030',
    barcode: '7891000300030',
    category: 'Mercearia',
    brand: 'União',
    description: 'Açúcar cristal puro e branquinho para adoçar suas receitas.',
    image: 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'un',
    stock: 40,
    minStock: 15,
    costPrice: 3.10,
    retailPrice: 4.89,
    wholesalePrice: 4.19,
    wholesaleMinQty: 10,
    status: 'ACTIVE',
    onSale: false,
    featured: false
  },
  {
    id: 'prod-004',
    name: 'Café Tradicional Torrado e Moído 500g',
    sku: 'ALN-CAF-004',
    ean: '7891000400049',
    barcode: '7891000400049',
    category: 'Mercearia',
    brand: 'Pilão',
    description: 'O café forte do Brasil. Ponto de torra intenso e aroma marcante.',
    image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=800&auto=format&fit=crop&q=80',
    weight: '500g',
    unit: 'un',
    stock: 35,
    minStock: 10,
    costPrice: 14.50,
    retailPrice: 21.90,
    wholesalePrice: 19.50,
    wholesaleMinQty: 4,
    status: 'ACTIVE',
    onSale: true,
    salePrice: 19.90,
    featured: true
  },
  {
    id: 'prod-005',
    name: 'Óleo de Soja Refinado 900ml',
    sku: 'ALN-OLE-005',
    ean: '7891000500058',
    barcode: '7891000500058',
    category: 'Mercearia',
    brand: 'Soya',
    description: 'Óleo de soja 100% vegetal com 5 etapas de purificação.',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800&auto=format&fit=crop&q=80',
    weight: '900ml',
    unit: 'un',
    stock: 80,
    minStock: 25,
    costPrice: 4.20,
    retailPrice: 6.99,
    wholesalePrice: 6.19,
    wholesaleMinQty: 12,
    status: 'ACTIVE',
    onSale: false,
    featured: false
  },
  {
    id: 'prod-006',
    name: 'Macarrão Espaguete com Ovos 500g',
    sku: 'ALN-MAC-006',
    ean: '7891000600067',
    barcode: '7891000600067',
    category: 'Mercearia',
    brand: 'Barilla',
    description: 'Espaguete tradicional produzido com ovos frescos e sêmola especial.',
    image: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?w=800&auto=format&fit=crop&q=80',
    weight: '500g',
    unit: 'un',
    stock: 55,
    minStock: 15,
    costPrice: 3.20,
    retailPrice: 5.49,
    wholesalePrice: 4.69,
    wholesaleMinQty: 8,
    status: 'ACTIVE',
    onSale: false,
    featured: false
  },
  {
    id: 'prod-007',
    name: 'Leite Integral UHT 1L',
    sku: 'ALN-LEI-007',
    ean: '7891000700076',
    barcode: '7891000700076',
    category: 'Laticínios',
    brand: 'Piracanjuba',
    description: 'Leite integral homogeneizado de alta qualidade, rico em cálcio.',
    image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=800&auto=format&fit=crop&q=80',
    weight: '1L',
    unit: 'un',
    stock: 90,
    minStock: 30,
    costPrice: 3.60,
    retailPrice: 5.79,
    wholesalePrice: 4.99,
    wholesaleMinQty: 12,
    status: 'ACTIVE',
    onSale: true,
    salePrice: 5.19,
    featured: true
  },
  {
    id: 'prod-008',
    name: 'Refrigerante Coca-Cola Original 2L',
    sku: 'ALN-BEB-008',
    ean: '7891000800085',
    barcode: '7891000800085',
    category: 'Bebidas',
    brand: 'Coca-Cola',
    description: 'O clássico refrigerante de cola, ideal para refeições em família.',
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=800&auto=format&fit=crop&q=80',
    weight: '2L',
    unit: 'un',
    stock: 45,
    minStock: 20,
    costPrice: 7.50,
    retailPrice: 11.90,
    wholesalePrice: 10.49,
    wholesaleMinQty: 6,
    status: 'ACTIVE',
    onSale: false,
    featured: true
  },
  {
    id: 'prod-009',
    name: 'Filé de Peito de Frango Congelado 1kg',
    sku: 'ALN-FRA-009',
    ean: '7891000900094',
    barcode: '7891000900094',
    category: 'Carnes',
    brand: 'Sadia',
    description: 'Filé de frango limpo, sem osso e sem pele, congelado individualmente.',
    image: 'https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'kg',
    stock: 28,
    minStock: 10,
    costPrice: 14.80,
    retailPrice: 22.90,
    wholesalePrice: 20.90,
    wholesaleMinQty: 5,
    status: 'ACTIVE',
    onSale: true,
    salePrice: 21.50,
    featured: true
  },
  {
    id: 'prod-010',
    name: 'Contra Filé Bovino Premium kg',
    sku: 'ALN-CAR-010',
    ean: '7891001000103',
    barcode: '7891001000103',
    category: 'Carnes',
    brand: 'Friboi Black',
    description: 'Corte nobre com capa de gordura perfeita para grelha ou frigideira.',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'kg',
    stock: 18,
    minStock: 8,
    costPrice: 38.00,
    retailPrice: 54.90,
    wholesalePrice: 49.90,
    wholesaleMinQty: 5,
    status: 'ACTIVE',
    onSale: false,
    featured: true
  },
  {
    id: 'prod-011',
    name: 'Patinho Bovino Moído Fresco kg',
    sku: 'ALN-CAR-011',
    ean: '7891001100112',
    barcode: '7891001100112',
    category: 'Carnes',
    brand: 'Açougue Aliança',
    description: 'Carne bovina magra e selecionada, moída na hora.',
    image: 'https://images.unsplash.com/photo-1588168333986-5078d3ae3976?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'kg',
    stock: 22,
    minStock: 8,
    costPrice: 28.50,
    retailPrice: 39.90,
    wholesalePrice: 36.90,
    wholesaleMinQty: 4,
    status: 'ACTIVE',
    onSale: false,
    featured: false
  },
  {
    id: 'prod-012',
    name: 'Costela Bovina em Tiras para Churrasco kg',
    sku: 'ALN-CAR-012',
    ean: '7891001200121',
    barcode: '7891001200121',
    category: 'Carnes',
    brand: 'Açougue Aliança',
    description: 'Costela em tiras com marmoreio ideal para um churrasco inesquecível.',
    image: 'https://images.unsplash.com/photo-1558030006-450675393462?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'kg',
    stock: 14,
    minStock: 6,
    costPrice: 22.00,
    retailPrice: 32.90,
    wholesalePrice: 29.90,
    wholesaleMinQty: 5,
    status: 'ACTIVE',
    onSale: true,
    salePrice: 29.90,
    featured: true
  },
  {
    id: 'prod-013',
    name: 'Banana Prata Selecionada kg',
    sku: 'ALN-HOR-013',
    ean: '7891001300130',
    barcode: '7891001300130',
    category: 'Frutas',
    brand: 'Hortifrúti Aliança',
    description: 'Bananas doces e frescas colhidas diretamente do produtor.',
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'kg',
    stock: 40,
    minStock: 15,
    costPrice: 3.50,
    retailPrice: 6.99,
    wholesalePrice: 5.49,
    wholesaleMinQty: 8,
    status: 'ACTIVE',
    onSale: false,
    featured: false
  },
  {
    id: 'prod-014',
    name: 'Tomate Italiano Especial kg',
    sku: 'ALN-HOR-014',
    ean: '7891001400149',
    barcode: '7891001400149',
    category: 'Legumes',
    brand: 'Hortifrúti Aliança',
    description: 'Tomates maduros e firmes, perfeitos para saladas e molhos artesanais.',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'kg',
    stock: 35,
    minStock: 12,
    costPrice: 4.80,
    retailPrice: 8.90,
    wholesalePrice: 7.20,
    wholesaleMinQty: 6,
    status: 'ACTIVE',
    onSale: true,
    salePrice: 7.90,
    featured: false
  },
  {
    id: 'prod-015',
    name: 'Batata Inglesa Lavada kg',
    sku: 'ALN-HOR-015',
    ean: '7891001500158',
    barcode: '7891001500158',
    category: 'Legumes',
    brand: 'Hortifrúti Aliança',
    description: 'Batata lisa de primeira qualidade, ideal para purês e frituras.',
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'kg',
    stock: 50,
    minStock: 15,
    costPrice: 3.20,
    retailPrice: 5.99,
    wholesalePrice: 4.90,
    wholesaleMinQty: 10,
    status: 'ACTIVE',
    onSale: false,
    featured: false
  },
  {
    id: 'prod-016',
    name: 'Cebola Amarela Nacional kg',
    sku: 'ALN-HOR-016',
    ean: '7891001600167',
    barcode: '7891001600167',
    category: 'Legumes',
    brand: 'Hortifrúti Aliança',
    description: 'Cebolas graúdas e aromáticas para o melhor tempero do seu dia a dia.',
    image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=800&auto=format&fit=crop&q=80',
    weight: '1kg',
    unit: 'kg',
    stock: 45,
    minStock: 15,
    costPrice: 2.80,
    retailPrice: 5.49,
    wholesalePrice: 4.49,
    wholesaleMinQty: 10,
    status: 'ACTIVE',
    onSale: false,
    featured: false
  },
  {
    id: 'prod-017',
    name: 'Queijo Mussarela Fatiado 500g',
    sku: 'ALN-FRI-017',
    ean: '7891001700176',
    barcode: '7891001700176',
    category: 'Frios',
    brand: 'Scala',
    description: 'Mussarela suave, fatiada fininha com derretimento impecável.',
    image: 'https://images.unsplash.com/photo-1631379578550-7038263db699?w=800&auto=format&fit=crop&q=80',
    weight: '500g',
    unit: 'un',
    stock: 25,
    minStock: 8,
    costPrice: 17.00,
    retailPrice: 26.90,
    wholesalePrice: 23.90,
    wholesaleMinQty: 4,
    status: 'ACTIVE',
    onSale: false,
    featured: true
  },
  {
    id: 'prod-018',
    name: 'Presunto Cozido Magro Fatiado 500g',
    sku: 'ALN-FRI-018',
    ean: '7891001800185',
    barcode: '7891001800185',
    category: 'Frios',
    brand: 'Seara',
    description: 'Presunto cozido magro com baixo teor de gordura e fatiado na hora.',
    image: 'https://images.unsplash.com/photo-1524438418049-ab2acb7aa48f?w=800&auto=format&fit=crop&q=80',
    weight: '500g',
    unit: 'un',
    stock: 20,
    minStock: 8,
    costPrice: 12.00,
    retailPrice: 18.90,
    wholesalePrice: 16.50,
    wholesaleMinQty: 4,
    status: 'ACTIVE',
    onSale: false,
    featured: false
  },
  {
    id: 'prod-019',
    name: 'Detergente Líquido Neutro 500ml',
    sku: 'ALN-LIM-019',
    ean: '7891001900194',
    barcode: '7891001900194',
    category: 'Limpeza',
    brand: 'Ypê',
    description: 'O detergente líder em rendimento. Alto poder desengordurante.',
    image: 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=800&auto=format&fit=crop&q=80',
    weight: '500ml',
    unit: 'un',
    stock: 110,
    minStock: 30,
    costPrice: 1.60,
    retailPrice: 2.79,
    wholesalePrice: 2.29,
    wholesaleMinQty: 12,
    status: 'ACTIVE',
    onSale: true,
    salePrice: 2.49,
    featured: true
  },
  {
    id: 'prod-020',
    name: 'Sabão em Pó Concentrado Lavagem Perfeita 1.6kg',
    sku: 'ALN-LIM-020',
    ean: '7891002000202',
    barcode: '7891002000202',
    category: 'Limpeza',
    brand: 'OMO',
    description: 'Remove manchas de primeira, cuidando das cores e dos tecidos.',
    image: 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=800&auto=format&fit=crop&q=80',
    weight: '1.6kg',
    unit: 'un',
    stock: 30,
    minStock: 10,
    costPrice: 19.50,
    retailPrice: 28.90,
    wholesalePrice: 25.90,
    wholesaleMinQty: 3,
    status: 'ACTIVE',
    onSale: false,
    featured: true
  },
  {
    id: 'prod-021',
    name: 'Papel Higiênico Folha Dupla 12 Rolos',
    sku: 'ALN-HIG-021',
    ean: '7891002100211',
    barcode: '7891002100211',
    category: 'Higiene',
    brand: 'Neve',
    description: 'Toque da seda, maciez insuperável e alta absorção folha dupla.',
    image: 'https://images.unsplash.com/photo-1584556812952-905ffd0c611a?w=800&auto=format&fit=crop&q=80',
    weight: '12 rolos',
    unit: 'pct',
    stock: 4, // Intentionally low stock to showcase admin alerts!
    minStock: 10,
    costPrice: 16.00,
    retailPrice: 24.90,
    wholesalePrice: 22.00,
    wholesaleMinQty: 4,
    status: 'ACTIVE',
    onSale: true,
    salePrice: 22.90,
    featured: true
  }
];

const initialDeliveryZones: DeliveryZone[] = [
  {
    id: 'zone-1',
    name: 'Zona 1 - Centro & Bairros Próximos',
    neighborhoods: ['Centro', 'Jardim Aliança', 'Bela Vista', 'Vila Nova'],
    distanceKm: 3,
    fee: 5.00,
    estimatedTimeMin: 35,
    active: true
  },
  {
    id: 'zone-2',
    name: 'Zona 2 - Bairros Médios',
    neighborhoods: ['Parque das Flores', 'Jardim América', 'Planalto', 'São José'],
    distanceKm: 7,
    fee: 8.00,
    estimatedTimeMin: 50,
    active: true
  },
  {
    id: 'zone-3',
    name: 'Zona 3 - Região Metropolitana e Periferia',
    neighborhoods: ['Industrial', 'Residencial Esperança', 'Colina Verde', 'Novo Horizonte'],
    distanceKm: 15,
    fee: 12.00,
    estimatedTimeMin: 75,
    active: true
  }
];

const initialCoupons: Coupon[] = [
  {
    id: 'coup-1',
    code: 'BEMVINDO10',
    type: 'PERCENTAGE',
    value: 10,
    minOrderValue: 80,
    maxUses: 1000,
    usedCount: 42,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    active: true
  },
  {
    id: 'coup-2',
    code: 'ALIANCA15',
    type: 'FIXED',
    value: 15,
    minOrderValue: 120,
    maxUses: 500,
    usedCount: 18,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    active: true
  },
  {
    id: 'coup-3',
    code: 'FRETEGRATIS',
    type: 'FIXED',
    value: 8,
    minOrderValue: 150,
    maxUses: 300,
    usedCount: 10,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    active: true
  }
];

const initialStaff: StaffUser[] = [
  { id: 'usr-1', name: 'Administrador Geral', email: 'admin@mercadinhoalianca.com.br', role: 'ADMIN', password: '12345', phone: '(74) 99959-8143', active: true, createdAt: '2026-01-01' },
  { id: 'usr-2', name: 'Mariana Santos', email: 'gerente@mercadinhoalianca.com.br', role: 'GERENTE', password: 'gerente123', phone: '(74) 99800-8283', active: true, createdAt: '2026-01-02' },
  { id: 'usr-3', name: 'Carlos Estoquista', email: 'estoque@mercadinhoalianca.com.br', role: 'ESTOQUE', password: 'estoque123', phone: '(74) 99911-2233', active: true, createdAt: '2026-01-03' },
  { id: 'usr-4', name: 'Patrícia Caixa', email: 'caixa@mercadinhoalianca.com.br', role: 'CAIXA', password: 'caixa123', phone: '(74) 99922-3344', active: true, createdAt: '2026-01-04' },
  { id: 'usr-5', name: 'Lucas Motoboy', email: 'entrega@mercadinhoalianca.com.br', role: 'ENTREGA', password: 'entrega123', phone: '(74) 99933-4455', active: true, createdAt: '2026-01-05' },
  { id: 'usr-6', name: 'Fernanda Atendimento', email: 'suporte@mercadinhoalianca.com.br', role: 'ATENDIMENTO', password: 'suporte123', phone: '(74) 99944-5566', active: true, createdAt: '2026-01-06' }
];

const initialSettings: StoreSettings = {
  storeName: 'Mercadinho Aliança',
  masterPassword: '12345',
  cnpj: '12.345.678/0001-90',
  phone: '(74) 99959-8143',
  phone2: '(74) 99800-8283',
  whatsapp: '5574999598143',
  whatsapp2: '5574998008283',
  email: 'contato@mercadinhoalianca.com.br',
  address: 'Rua Principal',
  streetNumber: '100',
  neighborhood: 'Centro',
  city: 'Bahia',
  state: 'BA',
  cep: '48900-000',
  complement: 'Em frente à Praça Central',
  reference: 'Ao lado da Farmácia Central',
  businessHours: 'Segunda a Sábado: 07h às 22h | Domingos e Feriados: 08h às 20h',
  pixKey: '74999598143',
  pixKeyType: 'PHONE',
  pixReceiver: 'Mercadinho Aliança',
  mercadoPagoAccessToken: process.env.MERCADOPAGO_ACCESS_TOKEN || '',
  mercadoPagoPublicKey: process.env.MERCADOPAGO_PUBLIC_KEY || '',
  mercadoPagoConnected: Boolean(process.env.MERCADOPAGO_ACCESS_TOKEN),
  stripeSecretKey: process.env.STRIPE_SECRET_KEY || '',
  stripePublishableKey: process.env.STRIPE_PUBLISHABLE_KEY || '',
  stripeConnected: Boolean(process.env.STRIPE_SECRET_KEY),
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  logoUrl: '/logo.png',
  demoMode: true,
  freeShippingThreshold: 180.00,
  defaultDeliveryFee: 5.00,
  deliveryActive: true,
  pickupActive: true,
  deliveryHours: 'Segunda a Sábado: 07h às 21h | Domingos: 08h às 14h',
  deliveryTimeEstimate: '35 a 55 minutos',
  creditTermsText: 'Sujeito a aprovação cadastral e análise de limite financeiro pelo Mercadinho Aliança.',
  cashTermsText: 'Pagamento em espécie no ato da entrega, sujeito a conferência de troco e validação prévia.',
  wholesaleDefaultMinQty: 5,
  aiHelpEnabled: true,
  hideAdminAccessFromPublic: true,
  paymentMethods: [
    {
      id: 'pix',
      name: 'PIX Dinâmico e Chave Oficial',
      category: 'PIX',
      active: true,
      badgeText: 'Instantâneo',
      description: 'Pagamento instantâneo via QR Code ou Copia e Cola com baixa automática.',
      instructions: 'Escaneie o QR Code ou utilize o código Copia e Cola em seu app bancário favorito.'
    },
    {
      id: 'a_prazo',
      name: 'A Prazo (Sujeito a Aprovação)',
      category: 'A_PRAZO',
      active: true,
      requiresApproval: true,
      badgeText: 'Sujeito a Aprovação',
      description: 'Crediário Aliança / Carnê da casa para clientes cadastrados com limite pré-aprovado.',
      instructions: '⚠️ Pedido sujeito a análise cadastral e aprovação de crédito pela administração do Mercadinho Aliança.'
    },
    {
      id: 'cash_delivery',
      name: 'Em Dinheiro no Ato da Entrega (Sujeito a Aprovação)',
      category: 'CASH',
      active: true,
      requiresApproval: true,
      badgeText: 'Sujeito a Aprovação',
      description: 'Pagamento em notas/moedas na entrega das compras com troco conferido pelo motoboy.',
      instructions: '⚠️ Sujeito a aprovação e conferência. Por favor informe o valor para troco.'
    },
    {
      id: 'bank_transfer',
      name: 'Outros Bancos (Transferência / TED / DOC / Pix)',
      category: 'BANK_TRANSFER',
      active: true,
      badgeText: 'Contas Bancárias',
      description: 'Transferência direta para nossas contas no Banco do Brasil, Bradesco, Caixa, Itaú ou Nubank.',
      instructions: 'Transfira o valor para uma de nossas contas bancárias e envie o comprovante pelo WhatsApp.'
    },
    {
      id: 'delivery_card',
      name: 'Cartão na Maquininha (Entrega)',
      category: 'DELIVERY_CARD',
      active: true,
      badgeText: 'Maquininha Móvel',
      description: 'Pague no ato da entrega em cartão de crédito, débito ou voucher na maquininha sem fio.',
      instructions: 'O entregador levará a máquina sem fio até o seu endereço.'
    },
    {
      id: 'credit_card_online',
      name: 'Cartão de Crédito Online',
      category: 'CREDIT_CARD_ONLINE',
      active: true,
      badgeText: 'Pagamento Digital',
      description: 'Pague online em ambiente 100% seguro via gateway integrado Mercado Pago ou Stripe.',
      instructions: 'Seus dados são criptografados com certificado de alta segurança.'
    }
  ],
  bankAccounts: [
    {
      id: 'bank-bb',
      bankName: 'Banco do Brasil (001)',
      agency: '1234-5',
      account: '98765-4',
      accountType: 'CORRENTE',
      holderName: 'Mercadinho Aliança LTDA',
      document: '12.345.678/0001-90',
      pixKey: '12.345.678/0001-90',
      active: true
    },
    {
      id: 'bank-bradesco',
      bankName: 'Bradesco (237)',
      agency: '0456',
      account: '12345-6',
      accountType: 'CORRENTE',
      holderName: 'Mercadinho Aliança LTDA',
      document: '12.345.678/0001-90',
      pixKey: 'contato@mercadinhoalianca.com.br',
      active: true
    },
    {
      id: 'bank-caixa',
      bankName: 'Caixa Econômica Federal (104)',
      agency: '0890',
      account: '003.00054321-0',
      accountType: 'CORRENTE',
      holderName: 'Mercadinho Aliança LTDA',
      document: '12.345.678/0001-90',
      pixKey: '74999598143',
      active: true
    },
    {
      id: 'bank-nubank',
      bankName: 'Nubank (260)',
      agency: '0001',
      account: '8765432-1',
      accountType: 'CORRENTE',
      holderName: 'Mercadinho Aliança LTDA',
      document: '12.345.678/0001-90',
      pixKey: '74998008283',
      active: true
    }
  ],
  footerConfig: {
    atendimentoTitle: 'Atendimento',
    atendimentoLinks: [
      { id: 'at-1', label: 'Meus pedidos', action: 'orders', active: true },
      { id: 'at-2', label: 'Central de atendimento', action: 'sac', active: true },
      { id: 'at-3', label: 'Fale conosco', action: 'contact', active: true }
    ],
    institucionalTitle: 'Institucional',
    institucionalCol1Links: [
      { id: 'inst-1', label: 'Quem somos', action: 'about', active: true },
      { id: 'inst-2', label: 'Nossas lojas', action: 'stores', active: true },
      { id: 'inst-3', label: 'Folhetos', action: 'offers', active: true },
      { id: 'inst-4', label: 'WhatsApp de Ofertas', action: 'whatsapp', active: true },
      { id: 'inst-5', label: 'Trabalhe conosco', action: 'jobs', active: true },
      { id: 'inst-6', label: 'Cartão Aliança', action: 'card', active: true }
    ],
    institucionalCol2Links: [
      { id: 'inst-7', label: 'Aplicativo Meu Aliança', action: 'app', active: true },
      { id: 'inst-8', label: 'Responsabilidade Social', action: 'social', active: true },
      { id: 'inst-9', label: 'Imprensa', action: 'press', active: true },
      { id: 'inst-10', label: 'Blog Aliança', action: 'blog', active: true },
      { id: 'inst-11', label: 'Denúncias', action: 'ethics', active: true }
    ],
    politicasTitle: 'Políticas Mercadinho Aliança',
    politicasLinks: [
      { id: 'pol-1', label: 'Política de Trocas e Devoluções', action: 'refunds', active: true },
      { id: 'pol-2', label: 'Política de Entregas', action: 'delivery', active: true },
      { id: 'pol-3', label: 'Termos e Condições de Uso', action: 'terms', active: true },
      { id: 'pol-4', label: 'Políticas de Privacidade', action: 'privacy', active: true },
      { id: 'pol-5', label: 'Política de Diversidade', action: 'diversity', active: true },
      { id: 'pol-6', label: 'Outras Políticas', action: 'other_policies', active: true }
    ],
    paymentFlags: ['mastercard', 'visa', 'elo', 'hipercard', 'cartao_alianca', 'diners', 'amex', 'pix'],
    appDownloadTitle: 'Baixe o aplicativo Meu Aliança',
    googlePlayUrl: 'https://play.google.com',
    appStoreUrl: 'https://apple.com/app-store',
    socialTitle: 'Acompanhe a gente nas redes sociais',
    socialLinks: {
      facebook: 'https://facebook.com',
      instagram: 'https://instagram.com',
      x: 'https://x.com',
      youtube: 'https://youtube.com',
      linkedin: 'https://linkedin.com',
      whatsapp: 'https://wa.me/5574999598143'
    },
    legalNoticeText: 'Racismo é crime. Denuncie. Disque 100 ou procure a Delegacia de Polícia Civil mais próxima ou o Ministério Público.',
    legalNoticeUrl: 'https://www.gov.br/mdh/pt-br/disque100'
  }
};

const initialOrders: Order[] = [
  {
    id: '#ALN-000001',
    customerId: 'cust-01',
    customerName: 'Roberto Lima',
    customerPhone: '(11) 98765-4321',
    customerCpf: '123.456.789-00',
    customerEmail: 'roberto.lima@gmail.com',
    items: [
      {
        productId: 'prod-001',
        productName: 'Arroz Branco Nobre Tipo 1 5kg',
        image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80',
        unit: 'un',
        quantity: 5,
        unitPrice: 27.90,
        isWholesale: true,
        subtotal: 139.50,
        originalSubtotal: 149.50,
        savings: 10.00
      },
      {
        productId: 'prod-002',
        productName: 'Feijão Carioca Especial 1kg',
        image: 'https://images.unsplash.com/photo-1551462147-ff29053fad31?w=800&auto=format&fit=crop&q=80',
        unit: 'un',
        quantity: 3,
        unitPrice: 8.90,
        isWholesale: false,
        subtotal: 26.70,
        originalSubtotal: 26.70,
        savings: 0
      },
      {
        productId: 'prod-010',
        productName: 'Contra Filé Bovino Premium kg',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80',
        unit: 'kg',
        quantity: 2,
        unitPrice: 54.90,
        isWholesale: false,
        subtotal: 109.80,
        originalSubtotal: 109.80,
        savings: 0
      }
    ],
    subtotal: 276.00,
    discount: 15.00,
    shippingFee: 5.00,
    total: 266.00,
    totalSavings: 25.00,
    status: 'EM_PREPARACAO',
    paymentMethod: 'PIX',
    paymentStatus: 'APPROVED',
    deliveryType: 'DELIVERY',
    deliveryAddress: {
      id: 'addr-1',
      street: 'Rua das Palmeiras',
      number: '340',
      complement: 'Apt 42',
      neighborhood: 'Jardim Aliança',
      city: 'São Paulo',
      state: 'SP',
      cep: '01311-000',
      reference: 'Próximo à padaria central'
    },
    deliveryZoneId: 'zone-1',
    estimatedDelivery: 'Hoje entre 14h30 e 15h30',
    createdAt: new Date(Date.now() - 3600 * 1000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 3600 * 1000 * 1).toISOString()
  },
  {
    id: '#ALN-000002',
    customerId: 'cust-02',
    customerName: 'Juliana Mendes',
    customerPhone: '(11) 97711-2233',
    customerCpf: '987.654.321-11',
    customerEmail: 'juliana.mendes@hotmail.com',
    items: [
      {
        productId: 'prod-007',
        productName: 'Leite Integral UHT 1L',
        image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=800&auto=format&fit=crop&q=80',
        unit: 'un',
        quantity: 12,
        unitPrice: 4.99,
        isWholesale: true,
        subtotal: 59.88,
        originalSubtotal: 69.48,
        savings: 9.60
      },
      {
        productId: 'prod-017',
        productName: 'Queijo Mussarela Fatiado 500g',
        image: 'https://images.unsplash.com/photo-1631379578550-7038263db699?w=800&auto=format&fit=crop&q=80',
        unit: 'un',
        quantity: 1,
        unitPrice: 26.90,
        isWholesale: false,
        subtotal: 26.90,
        originalSubtotal: 26.90,
        savings: 0
      }
    ],
    subtotal: 86.78,
    discount: 0,
    shippingFee: 0,
    total: 86.78,
    totalSavings: 9.60,
    status: 'PAGO',
    paymentMethod: 'CREDIT_CARD',
    paymentStatus: 'APPROVED',
    deliveryType: 'PICKUP',
    createdAt: new Date(Date.now() - 3600 * 1000 * 1).toISOString(),
    updatedAt: new Date(Date.now() - 3600 * 1000 * 0.5).toISOString()
  }
];

class Database {
  private products: Map<string, Product> = new Map();
  private orders: Map<string, Order> = new Map();
  private customers: Map<string, Customer> = new Map();
  private movements: InventoryMovement[] = [];
  private deliveryZones: DeliveryZone[] = [];
  private coupons: Coupon[] = [];
  private settings: StoreSettings = initialSettings;
  private staff: StaffUser[] = [];
  private shoppingLists: Map<string, ShoppingList> = new Map();

  constructor() {
    this.seed();
  }

  private seed() {
    initialProducts.forEach(p => this.products.set(p.id, p));
    initialOrders.forEach(o => this.orders.set(o.id, o));
    this.deliveryZones = [...initialDeliveryZones];
    this.coupons = [...initialCoupons];
    this.staff = [...initialStaff];

    // Demo customer
    const demoCust: Customer = {
      id: 'cust-demo',
      name: 'Cliente Aliança VIP',
      cpf: '111.222.333-44',
      phone: '(74) 99959-8143',
      whatsapp: '5574999598143',
      email: 'cliente@alianca.com.br',
      birthDate: '1990-05-15',
      addresses: [
        {
          id: 'addr-demo-1',
          street: 'Rua Principal',
          number: '100',
          complement: 'Casa 02',
          neighborhood: 'Centro',
          city: 'Bahia',
          state: 'BA',
          cep: '48900-000',
          reference: 'Próximo à Praça Central',
          isDefault: true
        }
      ],
      createdAt: '2026-01-10T10:00:00Z'
    };
    this.customers.set(demoCust.id, demoCust);

    // Initial inventory movement logs
    this.movements.push(
      {
        id: 'mov-1',
        productId: 'prod-001',
        productName: 'Arroz Branco Nobre Tipo 1 5kg',
        quantity: 50,
        type: 'IN',
        reason: 'Entrada nota fiscal NF-4821',
        date: new Date(Date.now() - 3600 * 1000 * 24 * 2).toISOString(),
        user: 'Carlos Estoquista'
      },
      {
        id: 'mov-2',
        productId: 'prod-021',
        productName: 'Papel Higiênico Folha Dupla 12 Rolos',
        quantity: -6,
        type: 'SALE',
        reason: 'Venda balcão / pedidos',
        date: new Date(Date.now() - 3600 * 1000 * 5).toISOString(),
        user: 'Sistema'
      }
    );
  }

  // Products
  getProducts(): Product[] {
    return Array.from(this.products.values());
  }

  getProductById(id: string): Product | undefined {
    return this.products.get(id);
  }

  getProductByBarcode(barcode: string): Product | undefined {
    return Array.from(this.products.values()).find(
      p => p.barcode === barcode || p.ean === barcode || p.sku.toLowerCase() === barcode.toLowerCase()
    );
  }

  saveProduct(product: Product): Product {
    if (!product.id) {
      product.id = `prod-${Date.now()}`;
    }
    this.products.set(product.id, product);
    return product;
  }

  deleteProduct(id: string): boolean {
    return this.products.delete(id);
  }

  // Orders
  getOrders(): Order[] {
    return Array.from(this.orders.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  getOrderById(id: string): Order | undefined {
    return this.orders.get(id);
  }

  createOrder(orderData: Partial<Order>): Order {
    const count = this.orders.size + 1;
    const formattedId = `#ALN-${String(count).padStart(6, '0')}`;
    const now = new Date().toISOString();

    const order: Order = {
      id: formattedId,
      customerId: orderData.customerId || 'cust-guest',
      customerName: orderData.customerName || 'Cliente Visitante',
      customerPhone: orderData.customerPhone || '',
      customerCpf: orderData.customerCpf || '',
      customerEmail: orderData.customerEmail || '',
      items: orderData.items || [],
      subtotal: orderData.subtotal || 0,
      discount: orderData.discount || 0,
      shippingFee: orderData.shippingFee || 0,
      total: orderData.total || 0,
      totalSavings: orderData.totalSavings || 0,
      status: orderData.status || (orderData.paymentMethod === 'PIX' ? 'PAGAMENTO_PENDENTE' : 'NOVO'),
      paymentMethod: orderData.paymentMethod || 'PIX',
      paymentStatus: orderData.paymentStatus || 'PENDING',
      deliveryType: orderData.deliveryType || 'DELIVERY',
      deliveryAddress: orderData.deliveryAddress,
      deliveryZoneId: orderData.deliveryZoneId,
      estimatedDelivery: orderData.estimatedDelivery || 'Hoje em até 60 minutos',
      notes: orderData.notes,
      createdAt: now,
      updatedAt: now,
      pixCode: orderData.pixCode,
      pixQrCodeBase64: orderData.pixQrCodeBase64
    };

    // Deduct stock and register inventory movement
    order.items.forEach(item => {
      const prod = this.products.get(item.productId);
      if (prod) {
        prod.stock = Math.max(0, prod.stock - item.quantity);
        this.movements.unshift({
          id: `mov-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          productId: prod.id,
          productName: prod.name,
          quantity: -item.quantity,
          type: 'SALE',
          reason: `Venda Pedido ${order.id}`,
          date: now,
          user: 'E-commerce'
        });
      }
    });

    this.orders.set(order.id, order);
    return order;
  }

  updateOrderStatus(orderId: string, status: Order['status'], paymentStatus?: Order['paymentStatus']): Order | null {
    const order = this.orders.get(orderId);
    if (!order) return null;
    order.status = status;
    if (paymentStatus) {
      order.paymentStatus = paymentStatus;
    }
    order.updatedAt = new Date().toISOString();
    this.orders.set(orderId, order);
    return order;
  }

  // Customers
  getCustomers(): Customer[] {
    return Array.from(this.customers.values());
  }

  getCustomerById(id: string): Customer | undefined {
    return this.customers.get(id);
  }

  saveCustomer(customer: Customer): Customer {
    if (!customer.id) {
      customer.id = `cust-${Date.now()}`;
    }
    this.customers.set(customer.id, customer);
    return customer;
  }

  // Inventory Movements
  getMovements(): InventoryMovement[] {
    return this.movements;
  }

  addMovement(mov: Omit<InventoryMovement, 'id' | 'date'>): InventoryMovement {
    const newMov: InventoryMovement = {
      ...mov,
      id: `mov-${Date.now()}`,
      date: new Date().toISOString()
    };
    this.movements.unshift(newMov);

    const prod = this.products.get(mov.productId);
    if (prod) {
      prod.stock += mov.quantity;
    }
    return newMov;
  }

  // Delivery Zones
  getDeliveryZones(): DeliveryZone[] {
    return this.deliveryZones;
  }

  saveDeliveryZone(zone: DeliveryZone): DeliveryZone {
    const index = this.deliveryZones.findIndex(z => z.id === zone.id);
    if (index >= 0) {
      this.deliveryZones[index] = zone;
    } else {
      zone.id = zone.id || `zone-${Date.now()}`;
      this.deliveryZones.push(zone);
    }
    return zone;
  }

  deleteDeliveryZone(id: string): boolean {
    const initialLen = this.deliveryZones.length;
    this.deliveryZones = this.deliveryZones.filter(z => z.id !== id);
    return this.deliveryZones.length < initialLen;
  }

  // Coupons
  getCoupons(): Coupon[] {
    return this.coupons;
  }

  getCouponByCode(code: string): Coupon | undefined {
    return this.coupons.find(c => c.code.toUpperCase() === code.toUpperCase() && c.active);
  }

  saveCoupon(coupon: Coupon): Coupon {
    const index = this.coupons.findIndex(c => c.id === coupon.id);
    if (index >= 0) {
      this.coupons[index] = coupon;
    } else {
      coupon.id = coupon.id || `coup-${Date.now()}`;
      this.coupons.push(coupon);
    }
    return coupon;
  }

  // Settings
  getSettings(): StoreSettings {
    return this.settings;
  }

  updateSettings(updates: Partial<StoreSettings>): StoreSettings {
    this.settings = { ...this.settings, ...updates };
    return this.settings;
  }

  // Staff Management
  getStaff(): StaffUser[] {
    return this.staff;
  }

  addStaff(data: Omit<StaffUser, 'id'>): StaffUser {
    const newUser: StaffUser = {
      ...data,
      id: `usr-${Date.now()}`,
      active: data.active !== undefined ? data.active : true,
      createdAt: new Date().toISOString()
    };
    this.staff.push(newUser);
    return newUser;
  }

  updateStaff(id: string, updates: Partial<StaffUser>): StaffUser | null {
    const index = this.staff.findIndex(u => u.id === id);
    if (index === -1) return null;
    this.staff[index] = { ...this.staff[index], ...updates };
    return this.staff[index];
  }

  deleteStaff(id: string): boolean {
    const initialLen = this.staff.length;
    this.staff = this.staff.filter(u => u.id !== id);
    return this.staff.length < initialLen;
  }

  // Master Password Authentication
  getMasterPassword(): string {
    return this.settings.masterPassword || '12345';
  }

  updateMasterPassword(newPassword: string): boolean {
    this.settings.masterPassword = newPassword;
    return true;
  }

  verifyMasterPassword(password: string): boolean {
    const current = this.getMasterPassword();
    return password === current;
  }

  verifyStaffLogin(email: string, pass: string): StaffUser | null {
    const user = this.staff.find(u => u.email.toLowerCase() === email.toLowerCase() && u.active);
    if (!user) return null;
    if (user.password === pass || pass === this.getMasterPassword()) {
      return user;
    }
    return null;
  }

  // Shopping Lists
  getShoppingLists(customerId: string): ShoppingList[] {
    return Array.from(this.shoppingLists.values()).filter(l => l.customerId === customerId);
  }

  saveShoppingList(list: ShoppingList): ShoppingList {
    if (!list.id) list.id = `list-${Date.now()}`;
    this.shoppingLists.set(list.id, list);
    return list;
  }
}

export const db = new Database();
